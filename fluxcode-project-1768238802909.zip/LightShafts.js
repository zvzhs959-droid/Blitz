(function() {
    window.flux = window.flux || {};

    class LightShafts {
        constructor(scene) {
            this.scene = scene;
            this.mesh = null;
            this.uniforms = {
                uTime: { value: 0 },
                tNoise: { value: null }
            };

            this._init();
        }

_init() {
            // Geometry: A cluster of cones/cylinders
            // We use a single geometry with instancing or merged geometry for performance,
            // but for simplicity and aesthetic control, let's use a few large planes or a cylinder.
            // A large cylinder with open ends works well for a "pool" shaft effect.
            
            // Increased length to 90 to accommodate tilt without clipping top/bottom
            const geometry = new THREE.CylinderGeometry(30, 20, 90, 32, 1, true);
            
            // Shader
            const vert = `
                varying vec2 vUv;
                varying vec3 vPos;
                void main() {
                    vUv = uv;
                    vPos = position;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `;

            const frag = `
                uniform float uTime;
                uniform sampler2D tNoise;
                varying vec2 vUv;
                varying vec3 vPos;

                void main() {
                    // Vertical fade (Soft top and bottom)
                    float alpha = smoothstep(0.0, 0.3, vUv.y) * smoothstep(1.0, 0.6, vUv.y);

                    // Scrolling Rays
                    // Layer 1: Slow, broad rays
                    float n1 = texture2D(tNoise, vec2(vUv.x * 2.0 + uTime * 0.02, vUv.y * 0.5 - uTime * 0.05)).r;
                    
                    // Layer 2: Fast, interference rays
                    float n2 = texture2D(tNoise, vec2(vUv.x * 3.0 - uTime * 0.03, vUv.y * 0.5 - uTime * 0.1)).r;

                    float rays = n1 * n2;
                    // Boost intensity significantly (Removed pow to prevent crushing)
                    rays = rays * 3.0; 

                    // Glistening Sparkles (High frequency noise)
                    float sparkle = texture2D(tNoise, vUv * vec2(8.0, 2.0) + vec2(uTime * 0.1, uTime * 0.3)).r;
                    sparkle = pow(sparkle, 5.0) * 10.0; // Sharp points

                    // Color: Cyan/Blue/White (Brighter base)
                    vec3 color = vec3(0.6, 0.9, 1.0);
                    
                    // Combine (Higher multipliers)
                    float finalAlpha = (rays * 0.8 + sparkle * 0.4) * alpha;
                    
                    // Distance fade (optional, handled by fog usually but we want additive)
                    gl_FragColor = vec4(color, finalAlpha);
                }
            `;

            const material = new THREE.ShaderMaterial({
                uniforms: this.uniforms,
                vertexShader: vert,
                fragmentShader: frag,
                transparent: true,
                blending: THREE.AdditiveBlending,
                depthWrite: false,
                side: THREE.DoubleSide
            });

            // Container for the angle (Realistic Light Source)
            this.container = new THREE.Group();
            // Angle: Coming from top-left (simulating surface sun penetrating deep water)
            this.container.rotation.z = Math.PI / 5; // ~36 degrees tilt
            this.container.rotation.x = Math.PI / 10; // ~18 degrees forward
            this.container.position.set(12, 8, 0); // Offset source to hit arena center
            this.scene.add(this.container);

            this.mesh = new THREE.Mesh(geometry, material);
            this.mesh.renderOrder = 100; 
            this.mesh.position.set(0, 0, 0);
            this.container.add(this.mesh);

            // Add a second layer for core intensity
            const coreGeo = new THREE.CylinderGeometry(12, 8, 90, 16, 1, true);
            this.coreMesh = new THREE.Mesh(coreGeo, material);
            this.coreMesh.renderOrder = 100;
            this.container.add(this.coreMesh);
        }

        update(dt) {
            this.uniforms.uTime.value += dt;
            
            // Lazy load texture
            if (!this.uniforms.tNoise.value && window.flux.noiseTexture) {
                this.uniforms.tNoise.value = window.flux.noiseTexture;
                // Ensure wrapping is correct for the cylinder UVs
                window.flux.noiseTexture.wrapS = THREE.RepeatWrapping;
                window.flux.noiseTexture.wrapT = THREE.RepeatWrapping;
            }

            // Slowly rotate shafts for dynamic feel
            if (this.mesh) this.mesh.rotation.y += dt * 0.02;
            if (this.coreMesh) this.coreMesh.rotation.y -= dt * 0.03;
        }
    }

    window.flux.LightShafts = LightShafts;
})();