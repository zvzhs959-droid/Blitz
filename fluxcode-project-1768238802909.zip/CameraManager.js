(function() {
    window.flux = window.flux || {};

    // Reusable vectors to avoid Garbage Collection
    const _idealPos = new THREE.Vector3();
    const _idealLook = new THREE.Vector3();
    const _currentPos = new THREE.Vector3();
    const _currentLook = new THREE.Vector3();
    const _velocity = new THREE.Vector3();
    const _targetWorldPos = new THREE.Vector3();
    const _camOffset = new THREE.Vector3();
    const _lookAhead = new THREE.Vector3();
    const _goalPos = new THREE.Vector3();
    const _camFwd = new THREE.Vector3();
    const _camRight = new THREE.Vector3();

    class CameraManager {
        constructor(camera, scene) {
            this.camera = camera;
            this.scene = scene;

            // --- IMPROVED CONFIGURATION ---
// --- IMPROVED CONFIGURATION ---
            this.config = {
                // FIXED PERSPECTIVE SETTINGS
                baseDistance: 20.0,   // Slightly closer for immersion
                baseHeight: 12.0,     // Lower angle for chase feel

                // IMPROVED: Faster, more responsive smoothing
                followSpeed: 6.0,     // Snappier follow
                lookSpeed: 4.0,       // Responsive look-at

                // Dynamic FOV
                fovBase: 50,
                fovMax: 70,           // Higher max for speed sensation

                // IMPROVED: Look-ahead settings
                lookAheadDistance: 10.0, // Look further ahead
                lookAheadSmoothing: 4.0,

                // Smart framing
                ballTrackWeight: 0.15, 
                threatAwareness: true
            };

            // State
            this.target = null;
            this.ball = null; // Direct ball reference for smart framing
            this.targetVel = new THREE.Vector3();
            this.targetInput = new THREE.Vector3();
            this.smoothedInput = new THREE.Vector3();
            this.smoothedLookAhead = new THREE.Vector3();

            // Camera State
            this.pos = camera.position.clone();
            this.lookAt = new THREE.Vector3(0, 0, 0);

            // Orbit State
            this.currentYaw = Math.PI;
            this.targetYaw = Math.PI;

            // IMPROVED: Manual orbit from touch (right side of screen)
            this.manualOrbitYaw = 0;
            this.manualOrbitPitch = 0;
            this.orbitSensitivity = 0.004;
            this.autoRecenterTimer = 0;
            this.autoRecenterDelay = 3.0;

// Shake
            this.shakeIntensity = 0;
            this.shakeRoll = 0; // NEW: Rotational shake
this.shakeOffset = new THREE.Vector3();
            this.fovImpulse = 0;
            this.rollImpulse = 0; // NEW: Dynamic tilt for curves

            // Cinematic State
            this.isCinematic = false;
            this.cinematicTimer = 0;
            this.cinematicDuration = 0;
            this.cinematicType = 'default';
            this.cinematicStartPos = new THREE.Vector3();
            this.cinematicStartLook = new THREE.Vector3();
            this.cinematicEndPos = new THREE.Vector3();

            // IMPROVED: Dynamic pull-back based on action
            this.currentPullBack = 0;
            this.maxPullBack = 8;
        }

        // NEW: Set ball reference for smart framing
        setBall(ball) {
            this.ball = ball;
        }

        // IMPROVED: Get camera-relative input transformation
        getCameraRelativeInput(inputX, inputZ) {
            this.camera.getWorldDirection(_camFwd);
            _camFwd.y = 0;

            if (_camFwd.lengthSq() < 0.001) {
                _camFwd.set(0, 0, -1);
            } else {
                _camFwd.normalize();
            }

            _camRight.crossVectors(new THREE.Vector3(0, 1, 0), _camFwd).normalize();

            // Transform input to world space
            const worldX = (inputX * _camRight.x) + (inputZ * _camFwd.x);
            const worldZ = (inputX * _camRight.z) + (inputZ * _camFwd.z);

            return { x: worldX, z: worldZ };
        }

        // NEW: Manual orbit input from touch
        handleOrbitInput(dx, dy) {
            this.manualOrbitYaw += dx * this.orbitSensitivity;
            this.manualOrbitPitch += dy * this.orbitSensitivity * 0.5;

            // Clamp pitch
            this.manualOrbitPitch = Math.max(-0.3, Math.min(0.5, this.manualOrbitPitch));

            // Reset auto-recenter timer
            this.autoRecenterTimer = 0;
        }

        // NEW: Recenter camera
        recenter() {
            this.manualOrbitYaw = 0;
            this.manualOrbitPitch = 0;
        }

        playCinematic(type, target, duration = 1.5) {
            this.isCinematic = true;
            this.cinematicTimer = 0;
            this.cinematicDuration = duration;
            this.target = target;
            this.cinematicType = type;

            this.cinematicStartPos.copy(this.pos);
            this.cinematicStartLook.copy(this.lookAt);

            this.addFovImpulse(-15);
        }

        _updateCinematic(dt) {
            this.cinematicTimer += dt;
            const progress = Math.min(1.0, this.cinematicTimer / this.cinematicDuration);

            const t = 1 - Math.pow(1 - progress, 3);

            let activeTarget = this.target;
            let isBallTracking = false;
            const ball = window.flux.gameInstance ? window.flux.gameInstance.entities.ball : null;

            if (ball && ball.mesh && ball.state === 'free' && ball.velocity.lengthSq() > 2.0) {
                activeTarget = ball.mesh;
                isBallTracking = true;
            }

            if (!activeTarget) {
                this.isCinematic = false;
                return;
            }

            activeTarget.getWorldPosition(_targetWorldPos);

            const endLook = _targetWorldPos.clone();
            let fwd = new THREE.Vector3();
            let right = new THREE.Vector3();

            if (isBallTracking) {
                endLook.addScaledVector(ball.velocity, 0.3);

                fwd.copy(ball.velocity).normalize();
                fwd.y = 0;
                if (fwd.lengthSq() < 0.01) fwd.set(0,0,1);
                fwd.normalize();

                right.crossVectors(new THREE.Vector3(0,1,0), fwd).normalize();
            } else {
                endLook.y += 1.5;
                fwd.set(0, 0, 1).applyQuaternion(activeTarget.quaternion);
                right.set(1, 0, 0).applyQuaternion(activeTarget.quaternion);
            }

            const endPos = _targetWorldPos.clone();

            if (this.cinematicType === 'jecht') {
                const dist = isBallTracking ? 14.0 : 10.0;
                const offset = fwd.clone().multiplyScalar(-dist).add(right.clone().multiplyScalar(3.0));
                endPos.add(offset);
                endPos.y += 6.0;
            } else if (this.cinematicType === 'sphere') {
                const dist = isBallTracking ? 16.0 : 12.0;
                const offset = fwd.clone().multiplyScalar(-dist);
                endPos.add(offset);
                endPos.y += 10.0;
            } else if (this.cinematicType === 'invisible') {
                const dist = 12.0;
                const offset = fwd.clone().multiplyScalar(-dist * 0.5).add(right.clone().multiplyScalar(dist));
                endPos.add(offset);
                endPos.y += 5.0;
            } else {
                const dist = isBallTracking ? 14.0 : 10.0;
                const offset = fwd.clone().multiplyScalar(-dist);
                endPos.add(offset);
                endPos.y += 5.0;
            }

            this.pos.lerp(endPos, dt * 4.0);
            this.lookAt.lerp(endLook, dt * 6.0);

            this.camera.position.copy(this.pos);
            this.camera.lookAt(this.lookAt);

            if (this.cinematicTimer >= this.cinematicDuration) {
                this.isCinematic = false;
            }
        }

setTarget(mesh, velocity, input, isAiming = false) {
            this.target = mesh;
            if (velocity) this.targetVel.copy(velocity);
            if (input) this.targetInput.copy(input);
            else this.targetInput.set(0, 0, 0);
            this.isAiming = isAiming;
        }

        // Keep for compatibility
        handleInput(dx, dy) {
            this.handleOrbitInput(dx, dy);
        }

        getYaw() { return this.currentYaw; }

        addShake(amount) {

            this.shakeIntensity = Math.min(this.shakeIntensity + amount, 4.0); // Increased cap
            this.shakeRoll = Math.min(this.shakeRoll + amount * 0.2, 0.8); // Add roll
        }
        addFovImpulse(amount) {
            this.fovImpulse = Math.min(this.fovImpulse + amount, 30);

        }
        addRollImpulse(amount) {
            this.rollImpulse += amount;
            // Clamp
            this.rollImpulse = Math.max(-0.5, Math.min(0.5, this.rollImpulse));
}

        snapToTarget() {
            if (!this.target) return;
            this.target.getWorldPosition(_targetWorldPos);

            this._calculateIdealState(0);

            this.pos.copy(_idealPos);
            this.lookAt.copy(_idealLook);
            this.currentYaw = this.targetYaw;

            this.camera.position.copy(this.pos);
            this.camera.lookAt(this.lookAt);

            this.smoothedInput.set(0, 0, 0);
            this.smoothedLookAhead.set(0, 0, 0);
        }

        update(dt) {
            if (this.isCinematic) {
                this._updateCinematic(dt);
                return;
            }

            if (!this.target) return;

            const safeDt = Math.min(dt, 0.05);

            // IMPROVED: Auto-recenter logic (Only if not aiming)
            if (!this.isAiming) {
                this.autoRecenterTimer += safeDt;
                if (this.autoRecenterTimer > this.autoRecenterDelay) {
                    const recenterSpeed = 2.0 * safeDt;
                    this.manualOrbitYaw *= (1.0 - recenterSpeed);
                    this.manualOrbitPitch *= (1.0 - recenterSpeed);
                }
            }

            // IMPROVED: Smart pull-back based on ball speed
            if (this.ball && this.ball.velocity) {
                const ballSpeed = this.ball.velocity.length();
                const targetPullBack = Math.min(this.maxPullBack, ballSpeed * 0.3);
                this.currentPullBack += (targetPullBack - this.currentPullBack) * safeDt * 3.0;
            } else {
                this.currentPullBack *= (1.0 - safeDt * 2.0);
            }

            // 1. Update Target Info
            this.target.getWorldPosition(_targetWorldPos);

            // 2. Calculate Ideal State
            this._calculateIdealState(safeDt);

            // 3. IMPROVED: Faster, more responsive smoothing
// 3. IMPROVED: Faster, more responsive smoothing
            // Dynamic follow speed based on distance error (Catch-up logic)
            const distError = this.pos.distanceTo(_idealPos);
            const dynamicFollow = this.config.followSpeed + (distError * 0.2);
            
            const speedMult = this.isAiming ? 2.0 : 1.0;
            const lookFactor = 1.0 - Math.exp(-this.config.lookSpeed * speedMult * safeDt);
            const posFactor = 1.0 - Math.exp(-dynamicFollow * speedMult * safeDt);

            this.pos.lerp(_idealPos, posFactor);
            this.pos.lerp(_idealPos, posFactor);
            this.lookAt.lerp(_idealLook, lookFactor);

            // 4. Screen Shake (Position & Rotation)
            if (this.shakeIntensity > 0) {
                const decay = 8.0 * safeDt; // Fast decay for snappy feel
                this.shakeIntensity -= decay;
                if (this.shakeIntensity < 0) this.shakeIntensity = 0;

                const shakeMag = this.shakeIntensity * 0.5;
                this.shakeOffset.set(
                    (Math.random() - 0.5) * shakeMag,
                    (Math.random() - 0.5) * shakeMag,
                    (Math.random() - 0.5) * shakeMag
                );
            } else {
                this.shakeOffset.set(0, 0, 0);
            }

            // Roll Shake
            if (this.shakeRoll > 0) {
                this.shakeRoll -= 5.0 * safeDt;
                if (this.shakeRoll < 0) this.shakeRoll = 0;
                this.camera.rotation.z = (Math.random() - 0.5) * this.shakeRoll;
} else {
                this.camera.rotation.z = 0;
            }
            
            // Apply Curve Tilt (Roll Impulse)
            if (Math.abs(this.rollImpulse) > 0.001) {
                this.camera.rotation.z += this.rollImpulse;
                this.rollImpulse *= (1.0 - 4.0 * safeDt); // Decay
            }

            // 5. Dynamic FOV
// 5. Dynamic FOV
            const speed = this.targetVel.length();
            const speedRatio = Math.min(speed / 25.0, 1.0);
            const warp = speedRatio * speedRatio;

            // Zoom in slightly when aiming
            const aimZoom = this.isAiming ? -10 : 0;
            const targetFov = this.config.fovBase + (this.config.fovMax - this.config.fovBase) * warp + this.fovImpulse + aimZoom;

            this.fovImpulse *= Math.max(0, 1.0 - (6.0 * safeDt));

            this.camera.fov += (targetFov - this.camera.fov) * 4.0 * safeDt;
            this.camera.updateProjectionMatrix();

            // 6. Apply to Camera
            this.camera.position.copy(this.pos).add(this.shakeOffset);
            this.camera.lookAt(this.lookAt);
        }

_calculateIdealState(dt) {
            const tPos = _targetWorldPos;

            // --- AIM MODE OVERRIDE ---
            if (this.isAiming) {
                // Relaxed Aim Mode: Zoom in but maintain orientation
                const aimDist = 14.0; 
                const aimHeight = 6.0;
                
                // Use Manual Orbit Logic (Consistent with Standard Mode)
                const effectiveDistance = aimDist;
                const effectiveHeight = aimHeight + this.manualOrbitPitch * 10;
                
                // Base Z offset (Camera defaults to +Z)
                const camZ = effectiveDistance;
                
                // Apply Orbit Rotation
                const finalX = camZ * Math.sin(this.manualOrbitYaw);
                const finalZ = camZ * Math.cos(this.manualOrbitYaw);
                
                _idealPos.set(tPos.x + finalX, tPos.y + effectiveHeight, tPos.z + finalZ);
                
                _idealLook.copy(tPos);
                _idealLook.y += 1.0; // Look at player center
                
                // Disable look-ahead to keep framing stable while aiming
                this.smoothedLookAhead.set(0,0,0);
                
                return;
            }

            // --- STANDARD MODE ---

            // 0. Threat Assessment (Dynamic Pull-back)
            let threatPullback = 0;
            if (this.config.threatAwareness) {
                const threat = this._calculateThreatLevel(tPos);
                threatPullback = threat * 6.0; // Pull back up to 6 units
            }

            // IMPROVED: Apply manual orbit
            // 1. Calculate Ideal Position with pull-back
            const effectiveDistance = this.config.baseDistance + this.currentPullBack + threatPullback;
            const effectiveHeight = this.config.baseHeight + this.currentPullBack * 0.3 + threatPullback * 0.5 + this.manualOrbitPitch * 10;

            // Base offset (Camera usually sits at +Z relative to target)
            const camZ = effectiveDistance;

            // Apply Orbit Rotation
            const finalCamX = camZ * Math.sin(this.manualOrbitYaw);
            const finalCamZ = camZ * Math.cos(this.manualOrbitYaw);

            _idealPos.set(tPos.x + finalCamX, tPos.y + effectiveHeight, tPos.z + finalCamZ);

            // Clamp to arena bounds (roughly) to prevent clipping through walls
            if (_idealPos.z > 48.0) _idealPos.z = 48.0;
            if (_idealPos.z < -48.0) _idealPos.z = -48.0;

            // 2. Calculate Ideal LookAt with IMPROVED look-ahead
            _idealLook.copy(tPos);

            // IMPROVED: Velocity-based look-ahead
            if (this.targetVel.lengthSq() > 0.5) {
                const speed = this.targetVel.length();
                const lookAheadFactor = Math.min(1.0, speed / 15.0) * this.config.lookAheadDistance;

                const velDir = this.targetVel.clone().normalize();
                _lookAhead.copy(velDir).multiplyScalar(lookAheadFactor);

                // Smooth the look-ahead
                this.smoothedLookAhead.lerp(_lookAhead, dt * this.config.lookAheadSmoothing);
                _idealLook.add(this.smoothedLookAhead);
            } else {
                this.smoothedLookAhead.multiplyScalar(1.0 - dt * 3.0);
                _idealLook.add(this.smoothedLookAhead);
            }

            _idealLook.y *= 0.5; // Look slightly lower than actual target height

            // IMPROVED: Include ball in framing when nearby
            if (this.ball && this.ball.mesh && this.config.ballTrackWeight > 0) {
                const ballPos = this.ball.mesh.position;
                const distToBall = tPos.distanceTo(ballPos);

                if (distToBall < 25 && distToBall > 2) {
                    const ballWeight = Math.max(0, 1 - distToBall / 25) * this.config.ballTrackWeight;
                    _idealLook.lerp(ballPos, ballWeight);
                }
            }

            // 3. Input Anticipation (Smoothed)
            this.smoothedInput.lerp(this.targetInput, dt * 3.0);

            if (this.smoothedInput.lengthSq() > 0.01) {
                _idealLook.x += this.smoothedInput.x * 4.0;
                _idealLook.z += this.smoothedInput.z * 4.0;
            }
        }

        _calculateThreatLevel(centerPos) {
            if (!window.flux.gameInstance) return 0;
            const game = window.flux.gameInstance;
            
            let density = 0;
            const checkTeam = (team) => {
                if (!team) return;
                for (let i = 0; i < team.players.length; i++) {
                    const p = team.players[i];
                    if (p.mesh && p.mesh !== this.target) {
                        const dSq = p.mesh.position.distanceToSquared(centerPos);
                        if (dSq < 64.0) { // 8m radius
                            density += 1.0;
                        }
                    }
                }
            };
            checkTeam(game.teams.home);
            checkTeam(game.teams.away);
            
            return Math.min(1.0, density / 4.0); // Cap at 4 players
        }

        // NEW: Get forward direction for UI reference
        getForwardDirection() {
            this.camera.getWorldDirection(_camFwd);
            _camFwd.y = 0;
            if (_camFwd.lengthSq() < 0.001) {
                _camFwd.set(0, 0, -1);
            } else {
                _camFwd.normalize();
            }
            return _camFwd.clone();
        }

        // NEW: Get right direction
        getRightDirection() {
            const fwd = this.getForwardDirection();
            _camRight.crossVectors(new THREE.Vector3(0, 1, 0), fwd).normalize();
            return _camRight.clone();
        }
    }

    window.flux.CameraManager = CameraManager;
})();
