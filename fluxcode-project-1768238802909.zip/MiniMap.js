(function() {
    window.flux = window.flux || {};

    class MiniMap {
        constructor() {
            this.container = document.getElementById('minimap');
            this.dots = new Map(); // Map entity to DOM element
            this.width = 100; // Matches CSS width
            this.height = 100; // Matches CSS height
            this.worldRadius = 30; // Arena radius
        }

        register(entity, type) {
            if (!this.container) return;
            
            const dot = document.createElement('div');
            dot.className = `map-dot ${type}`;
            this.container.appendChild(dot);
            
            this.dots.set(entity, dot);
        }

        init(homeTeam, awayTeam, ball) {
            if (!this.container) return;
            this.container.innerHTML = ''; // Clear existing
            this.dots.clear();

            // Register Home Team
            homeTeam.players.forEach(p => this.register(p, 'home'));
            
            // Register Away Team
            awayTeam.players.forEach(p => this.register(p, 'away'));
            
            // Register Ball
            this.register(ball, 'ball');
        }

        update() {
            if (!this.container) return;

            const halfW = this.width / 2;
            const halfH = this.height / 2;
            // Scale: Map Radius (50px) / World Radius (30 units)
            const scale = halfW / this.worldRadius; 

for (const [entity, dot] of this.dots) {
                if (!entity.mesh) continue;

                // Invisible Ball Logic
                if (entity.isInvisible) {
                    dot.style.display = 'none';
                    continue;
                } else {
                    dot.style.display = 'block';
                }
                if (!entity.mesh) continue;

                const pos = entity.mesh.position;
                
                // Map Logic:
                // World Z is Up/Down. -Z is Top (Attack Direction for Home), +Z is Bottom.
                // World X is Left/Right.
                
                // Calculate raw position relative to center
                let dx = pos.x * scale;
                let dy = pos.z * scale;

                // Clamp to circle (keep dots inside the map)
                const dist = Math.sqrt(dx*dx + dy*dy);
                const maxDist = halfW - 2; // -2 for dot radius padding
                
                if (dist > maxDist) {
                    const angle = Math.atan2(dy, dx);
                    dx = Math.cos(angle) * maxDist;
                    dy = Math.sin(angle) * maxDist;
                }

                // Convert to CSS coordinates (0,0 is Top-Left)
                // Center is (50, 50)
                const cssX = halfW + dx;
                const cssY = halfH + dy;

                dot.style.transform = `translate(${cssX}px, ${cssY}px)`;
                
// Status Updates
                if (entity.status) {
                    // Nap (Sleep) turns dot dark/black
                    if (entity.status.nap > 0) {
                        if (!dot.classList.contains('nap')) dot.classList.add('nap');
                    } else {
                        if (dot.classList.contains('nap')) dot.classList.remove('nap');
                    }
                }

                // Active Player Marker (Green)
// Active Player Marker (Green)
                const game = window.flux.gameInstance;
                const isActive = (game && game.teams.home && game.teams.home.activePlayer === entity);
                
                if (isActive) {
                    if (!dot.classList.contains('active-player')) dot.classList.add('active-player');
                } else {
                    if (dot.classList.contains('active-player')) dot.classList.remove('active-player');
                }

                // Ball Carrier Marker (Glow)
                if (entity.hasBall) {
                    if (!dot.classList.contains('ball-carrier')) dot.classList.add('ball-carrier');
                } else {
                    if (dot.classList.contains('ball-carrier')) dot.classList.remove('ball-carrier');
                }
            }
        }
    }
            

    

    window.flux.MiniMap = MiniMap;
})();