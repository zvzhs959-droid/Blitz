(function() {
    window.flux = window.flux || {};

// Tooltip Descriptions for Long-Press
    const TOOLTIP_DESCRIPTIONS = {
        'SUBSTEPS': "Physics iterations per frame. Higher = more stable, more CPU.",
        'STOP_SPEED': "Velocity threshold below which the ball snaps to a halt.",
        'WATER_DRAG_LINEAR': "Base water resistance. Slows ball linearly.",
        'WATER_DRAG_QUAD': "Quadratic drag. Slows high-speed balls significantly.",
        'SPIN_DRAG': "How fast the ball's spin decays over time.",
        'MAGNUS_ENABLED': "Enables the Magnus effect (curve from spin).",
        'MAGNUS_COEFF': "Strength of the curve force relative to spin/speed.",
        'MAGNUS_CAP': "Maximum curve force allowed (prevents physics explosions).",
        'DEPTH_TARGET_Y': "Ideal Y height the ball tries to float at.",
        'DEPTH_SPRING': "Strength of the force pulling ball to Target Y.",
        'DEPTH_DAMP': "Damping on vertical movement to prevent oscillation.",
        'BOUNDARY_RADIUS': "Radius of the circular arena wall.",
        'BOUNDARY_HEIGHT': "Height of the arena ceiling/floor.",
        'WALL_SOFT_BUFFER': "Distance from wall where soft repulsion begins.",
        'WALL_SOFT_FORCE': "Force pushing ball away from wall before impact.",
        'WALL_ELASTICITY': "Bounciness of the wall (0 = dead thud, 1 = perfect bounce).",
        'WALL_FRICTION': "Friction when sliding along the wall.",
        'FLOOR_ELASTICITY': "Bounciness of the floor/ceiling.",
        'GOAL_POCKET_ENABLED': "Enables the extended corridor for the goal.",
        'GOAL_POCKET_X': "Half-width of the goal pocket corridor.",
        'GOAL_POCKET_Z': "Z-depth where the pocket starts.",
        'GOAL_POCKET_RADIUS': "Effective radius inside the pocket.",
        'LAUNCH_SPEED_SCALE': "Multiplier for converting Stat Power to Physics Velocity.",
        'LAUNCH_SPEED_CAP': "Maximum physical speed the ball can be thrown.",
        'SWIPE_MIN_PX': "Minimum swipe distance to register a throw.",
        'AIM_DX_SCALE': "Sensitivity of horizontal aim from swipe.",
        'AIM_DY_SCALE': "Sensitivity of vertical aim from swipe.",
        'POWER_BASE': "Base power multiplier for a quick tap.",
        'POWER_RANGE': "Additional power multiplier at full charge.",
        'POWER_MAX_BONUS_RATIO': "Charge threshold for 'Max Power' bonus.",
        'POWER_MAX_MULTIPLIER': "Multiplier applied when hitting Max Power.",
        'CURVE_ENABLED': "Enables curve shots via curved swipes.",
        'CURVE_INTENSITY_THRESHOLD': "How curved a swipe must be to trigger spin.",
        'CURVE_SPIN_SCALE': "Multiplier for converting swipe curve to ball spin.",
        'CURVE_SPEED_MULT': "Multiplier for spin based on swipe speed.",
        'CURVE_SPIN_CAP': "Maximum spin allowed from a curve throw.",
        'CURVE_PERFECT_SPIN': "Spin threshold to trigger 'Perfect Curve' FX.",
        'timeScale': "Global game speed multiplier.",
        'demoMode': "Toggle AI vs AI auto-play.",
        'resolution': "Internal render resolution scale (0.5 = half res).",
        'arenaOpacity': "Opacity of the outer arena grid.",
        'arena2Opacity': "Opacity of the inner hex grid."
    };

    class DevTools {
        constructor(gameManager) {
            this.game = gameManager;
            
            // lil-gui attaches to window.lil by default in UMD build
            if (!window.lil || !window.lil.GUI) {
                console.warn("DevTools: lil-gui not found.");
                return;
            }

const container = document.getElementById('game-container');
            this.gui = new window.lil.GUI({ title: 'Flux DevTools', container: container });
            
            // Position as a collapsed tab on the right frame
// Position as a sliding tab on the right frame
// Position as a sliding tab on the right frame
// Wrapper for sliding animation
            const wrapper = document.createElement('div');
            wrapper.style.position = 'absolute';
            wrapper.style.top = '100px';
            wrapper.style.right = '-260px';
            wrapper.style.width = '260px';
            wrapper.style.transition = 'right 0.3s cubic-bezier(0.2, 0.8, 0.2, 1.0)';
            wrapper.style.zIndex = '9999';
            wrapper.style.display = 'flex';
            wrapper.style.flexDirection = 'column';
            container.appendChild(wrapper);

            const dom = this.gui.domElement;
            dom.style.width = '100%';
            dom.style.setProperty('--width', '100%');
            dom.style.maxHeight = '80vh';
            dom.style.overflowY = 'auto';
            dom.style.overflowX = 'hidden';
            
            // Move GUI into wrapper
            wrapper.appendChild(dom);
            
            // Create Toggle Handle
            const handle = document.createElement('div');
            handle.style.position = 'absolute';
            handle.style.left = '-40px'; // Protrude to the left
            handle.style.top = '0';
            handle.style.width = '40px';
            handle.style.height = '40px';
            handle.style.backgroundColor = 'rgba(0, 20, 40, 0.9)';
            handle.style.border = '1px solid #00ffff';
            handle.style.borderRight = 'none';
            handle.style.borderTopLeftRadius = '8px';
            handle.style.borderBottomLeftRadius = '8px';
            handle.style.cursor = 'pointer';
            handle.style.display = 'flex';
            handle.style.justifyContent = 'center';
            handle.style.alignItems = 'center';
            handle.style.color = '#00ffff';
            handle.style.fontSize = '20px';
            handle.innerHTML = '⚙';
            handle.style.boxShadow = '-5px 0 10px rgba(0,0,0,0.5)';
            
            wrapper.appendChild(handle);
            
            // Toggle Logic
            let isOpen = false;
            handle.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent game inputs
                isOpen = !isOpen;
                wrapper.style.right = isOpen ? '0px' : '-260px';
                handle.innerHTML = isOpen ? '»' : '⚙';
            });
            // Default global timeScale if not set
if (window.flux.timeScale === undefined) window.flux.timeScale = 0.8;

this._setupGeneral();
            this._setupGameState();
this._setupOverlays();
            this._setupTeams();
            this._setupPlayerInspector();
            this._setupBallSandbox();
this._setupFXLab();
            this._setupVisualDebug();
            this._setupVisuals();
            this._setupTooltips();
        }

        _setupTooltips() {
            // Create Tooltip DOM
            this.tooltipEl = document.createElement('div');
            Object.assign(this.tooltipEl.style, {
                position: 'fixed',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                backgroundColor: 'rgba(0, 10, 30, 0.95)',
                border: '2px solid #00ffff',
                padding: '20px',
                color: '#fff',
                fontFamily: 'monospace',
                fontSize: '14px',
                maxWidth: '300px',
                zIndex: '10000',
                display: 'none',
                pointerEvents: 'none',
                boxShadow: '0 0 20px rgba(0, 255, 255, 0.3)',
                borderRadius: '8px',
                textAlign: 'center'
            });
            document.body.appendChild(this.tooltipEl);

            // Recursive function to attach listeners
            const attach = (gui) => {
                // Controllers
                if (gui.controllers) {
                    gui.controllers.forEach(c => {
                        const dom = c.domElement.closest('.controller'); // lil-gui structure
                        if(dom) {
                            const label = dom.querySelector('.name');
                            if(label) {
                                this._addLongPress(label, c.property, c._name);
                            }
                        }
                    });
                }
                // Sub-folders
                if(gui.folders) {
                    gui.folders.forEach(f => attach(f));
                }
            };

            // Wait a tick for GUI to fully render DOM
            setTimeout(() => attach(this.gui), 100);
        }

        _addLongPress(element, property, name) {
            let timer = null;
            const duration = 500; // 0.5s

            const start = (e) => {
                timer = setTimeout(() => {
                    this._showTooltip(property, name);
                }, duration);
            };

            const end = () => {
                if(timer) {
                    clearTimeout(timer);
                    timer = null;
                }
                this._hideTooltip();
            };

            element.addEventListener('mousedown', start);
            element.addEventListener('touchstart', start, {passive: true});
            
            element.addEventListener('mouseup', end);
            element.addEventListener('mouseleave', end);
            element.addEventListener('touchend', end);
            element.addEventListener('touchcancel', end);
        }

        _showTooltip(prop, name) {
            const desc = TOOLTIP_DESCRIPTIONS[prop];
            if(desc) {
                this.tooltipEl.innerHTML = `<strong style="color:#00ffff; font-size:16px;">${name || prop}</strong><br><br>${desc}`;
                this.tooltipEl.style.display = 'block';
            }
        }

        _hideTooltip() {
            if (this.tooltipEl) this.tooltipEl.style.display = 'none';
        }


_setupGeneral() {
            const folder = this.gui.addFolder('General');
            
const params = {
                timeScale: window.flux.timeScale,
                demoMode: this.game.isDemoMode,
                toggleHUD: true,
                resolution: 0.50,
arenaOpacity: 0.3,
                arena2Opacity: 0.25
            };

            folder.add(params, 'timeScale', 0.0, 5.0).name('Game Speed').onChange(v => {
                window.flux.timeScale = v;
            });

            folder.add(params, 'demoMode').name('Demo Mode').listen().onChange(v => {
                if (this.game.isDemoMode !== v) {
                    this.game.toggleDemoMode();
                }
            });

            folder.add(params, 'toggleHUD').name('Show HUD').onChange(v => {
                const hud = document.getElementById('ui-layer');
                if (hud) {
                    hud.style.visibility = v ? 'visible' : 'hidden';
                }
            });

            folder.add(params, 'resolution', 0.1, 2.0).name('Resolution Scale').onChange(v => {
                const w = window.innerWidth;
                const h = window.innerHeight;
                const renderer = this.game.renderer;
                if (renderer) {
                    renderer.setSize(w * v, h * v, false);
                }
            });

folder.add(params, 'arenaOpacity', 0.0, 1.0).name('Arena 1 Opacity').onChange(v => {
                if (window.flux.arenaMesh && window.flux.arenaMesh.material) {
                    window.flux.arenaMesh.material.opacity = v;
                }
            });

            const blendModes = {
                'Normal': THREE.NormalBlending,
                'Additive': THREE.AdditiveBlending,
                'Multiply': THREE.MultiplyBlending,
                'Subtractive': THREE.SubtractiveBlending,
                'NoBlending': THREE.NoBlending
            };
params.arenaBlend = 'Normal';

            folder.add(params, 'arenaBlend', Object.keys(blendModes)).name('Arena 1 Blend').onChange(v => {
                if (window.flux.arenaMesh && window.flux.arenaMesh.material) {
                    window.flux.arenaMesh.material.blending = blendModes[v];
                    window.flux.arenaMesh.material.needsUpdate = true;
                }
            });

            // Arena 2 Controls
folder.add(params, 'arena2Opacity', 0.0, 1.0).name('Arena 2 Opacity').onChange(v => {
                if (window.flux.arenaMesh2 && window.flux.arenaMesh2.material && window.flux.arenaMesh2.material.uniforms.uOpacity) {
                    window.flux.arenaMesh2.material.uniforms.uOpacity.value = v;
                }
            });

params.arena2Blend = 'Additive';
            folder.add(params, 'arena2Blend', Object.keys(blendModes)).name('Arena 2 Blend').onChange(v => {
                if (window.flux.arenaMesh2 && window.flux.arenaMesh2.material) {
                    window.flux.arenaMesh2.material.blending = blendModes[v];
                    window.flux.arenaMesh2.material.needsUpdate = true;
                }
            });
            
            // Apply defaults
            if (window.flux.arenaMesh && window.flux.arenaMesh.material) {
                window.flux.arenaMesh.material.opacity = params.arenaOpacity;
            }
            if (window.flux.arenaMesh2 && window.flux.arenaMesh2.material) {
                window.flux.arenaMesh2.material.opacity = params.arena2Opacity;
            }
        }

_setupOverlays() {
            const folder = this.gui.addFolder('Overlays & FX');
            
            // 1. GIF Overlay
            const gifEl = document.getElementById('screen-overlay-gif');
            if (gifEl) {
                const gifParams = {
                    visible: true,
opacity: 0.62,
                    blend: 'overlay'
                };
                
                const gFolder = folder.addFolder('Screen GIF');
                gFolder.add(gifParams, 'visible').onChange(v => gifEl.style.display = v ? 'block' : 'none');
                gFolder.add(gifParams, 'opacity', 0.0, 1.0).onChange(v => gifEl.style.opacity = v);
                
                const blendModes = [
                    'normal', 'multiply', 'screen', 'overlay', 
                    'darken', 'lighten', 'color-dodge', 'color-burn', 
                    'hard-light', 'soft-light', 'difference', 'exclusion', 
                    'hue', 'saturation', 'color', 'luminosity'
                ];
                gFolder.add(gifParams, 'blend', blendModes).onChange(v => gifEl.style.mixBlendMode = v);
            }

            // 2. Water Overlay
            const wo = this.game.waterOverlay;
            if (wo && wo.mesh) {
                const wFolder = folder.addFolder('Water Shader');
                const wParams = { 
                    visible: true,
                    opacity: wo.material.uniforms.uOpacity ? wo.material.uniforms.uOpacity.value : 0.5,
                    blend: 'Additive'
                };
                
                wFolder.add(wParams, 'visible').onChange(v => wo.mesh.visible = v);
                
                if (wo.material.uniforms.uOpacity) {
                    wFolder.add(wParams, 'opacity', 0.0, 2.0).onChange(v => wo.material.uniforms.uOpacity.value = v);
                }

                const threeBlends = {
                    'Normal': THREE.NormalBlending,
                    'Additive': THREE.AdditiveBlending,
                    'Subtractive': THREE.SubtractiveBlending,
                    'Multiply': THREE.MultiplyBlending,
                    'NoBlending': THREE.NoBlending
                };
                
                wFolder.add(wParams, 'blend', Object.keys(threeBlends)).onChange(v => {
                    wo.material.blending = threeBlends[v];
                    wo.material.needsUpdate = true;
                });
            }

            // 3. Light Shafts
            const ls = this.game.lightShafts;
            if (ls && ls.container) {
                const lParams = { visible: true };
                folder.add(lParams, 'visible').name('Light Shafts').onChange(v => ls.container.visible = v);
            }
        }

_setupGameState() {
            const folder = this.gui.addFolder('Game State');
            const gm = this.game;
            
            const params = {
                forceHomeGoal: () => { 
                    if(gm.state === 'active') gm.goalScored('home'); 
                    else console.warn("Game must be active to trigger goal");
                },
                forceAwayGoal: () => { 
                    if(gm.state === 'active') gm.goalScored('away');
                    else console.warn("Game must be active to trigger goal");
                },
                forceHalftime: () => {
                    if(gm.state === 'active') gm.endHalf();
                },
                resetRound: () => gm.resetRound(),
                exitToMenu: () => {
                    if (window.flux.gameInstance && window.flux.gameInstance.menuManager) {
                        window.flux.gameInstance.menuManager.show();
                        window.flux.gameInstance.state = 'menu';
                        // Stop practice if running
                        if (window.flux.gameInstance.practiceManager) {
                            window.flux.gameInstance.practiceManager.stop();
                        }
                    }
                }
            };

            folder.add(params, 'forceHomeGoal').name('Trigger Home Goal');
            folder.add(params, 'forceAwayGoal').name('Trigger Away Goal');
            folder.add(params, 'forceHalftime').name('Force Halftime');
            folder.add(params, 'resetRound').name('Reset Round');
            folder.add(params, 'exitToMenu').name('Exit to Menu');
        }

        _setupTeams() {
            const folder = this.gui.addFolder('Teams');
            if (!this.game.teams.home || !this.game.teams.away) return;

            const home = this.game.teams.home;
            const away = this.game.teams.away;

            // Home
            const hFolder = folder.addFolder('Home Team');
            hFolder.add(home, 'isHuman').name('Is Human Controlled').listen();
            hFolder.add(home, 'aiEnabled').name('AI Logic Enabled').listen();

            // Away
            const aFolder = folder.addFolder('Away Team');
            aFolder.add(away, 'isHuman').name('Is Human Controlled').listen();
            aFolder.add(away, 'aiEnabled').name('AI Logic Enabled').listen();

        }

_setupPlayerInspector() {
            const folder = this.gui.addFolder('Player Inspector (Home Active)');
            
            // Helper to get current active player safely
            const getActive = () => {
                return (this.game.teams.home && this.game.teams.home.activePlayer) 
                    ? this.game.teams.home.activePlayer 
                    : null;
            };

            // Proxy object to bind GUI to dynamic target
            const proxy = {
                get Role() { 
                    const p = getActive();
                    return p ? p.role : '-'; 
                },
                
                get GodMode() { 
                    const p = getActive();
                    return p ? p.isGodMode : false; 
                },
                set GodMode(v) { 
                    const p = getActive();
                    if(p) p.isGodMode = v; 
                },

                // Runtime Values
                get HP() { 
                    const p = getActive();
                    return p ? p.stats.HP : 0; 
                },
                set HP(v) { 
                    const p = getActive();
                    if(p) p.stats.HP = v; 
                },
                
                get CurrentEN() { 
                    const p = getActive();
                    return p ? p.currentEN : 0; 
                },
                set CurrentEN(v) { 
                    const p = getActive();
                    if(p) p.currentEN = v; 
                },

                // Base Stats
                get MaxHP() { 
                    const p = getActive();
                    return p ? p.stats.maxHP : 0; 
                },
                set MaxHP(v) { 
                    const p = getActive();
                    if(p) p.stats.maxHP = v; 
                },

                get SP() { 
                    const p = getActive();
                    return p ? p.stats.SP : 0; 
                },
                set SP(v) { 
                    const p = getActive();
                    if(p) { 
                        p.stats.SP = v; 
                        p._updateDerivedStats(); 
                    } 
                },

                get EN() { 
                    const p = getActive();
                    return p ? p.stats.EN : 0; 
                }, 
                set EN(v) { 
                    const p = getActive();
                    if(p) {
                        p.stats.EN = v;
                    }
                },

                get AT() { 
                    const p = getActive();
                    return p ? p.stats.AT : 0; 
                },
                set AT(v) { 
                    const p = getActive();
                    if(p) p.stats.AT = v; 
                },

                get PA() { 
                    const p = getActive();
                    return p ? p.stats.PA : 0; 
                },
                set PA(v) { 
                    const p = getActive();
                    if(p) p.stats.PA = v; 
                },

                get BL() { 
                    const p = getActive();
                    return p ? p.stats.BL : 0; 
                },
                set BL(v) { 
                    const p = getActive();
                    if(p) p.stats.BL = v; 
                },

                get SH() { 
                    const p = getActive();
                    return p ? p.stats.SH : 0; 
                },
                set SH(v) { 
                    const p = getActive();
                    if(p) p.stats.SH = v; 
                },

                get CA() { 
                    const p = getActive();
                    return p ? p.stats.CA : 0; 
                },
                set CA(v) { 
                    const p = getActive();
                    if(p) p.stats.CA = v; 
                },

                // Actions
                LevelUp: () => { 
                    const p = getActive();
                    if(p) p.levelUp(); 
                },
                FullHeal: () => { 
                    const p = getActive(); 
                    if(p) { 
                        p.stats.HP = p.stats.maxHP; 
                        p.currentEN = p.getStat('EN'); 
                        p.status.venom = 0; 
                        p.status.nap = 0; 
                        for(let k in p.status.wither) p.status.wither[k] = 0;
                        if(window.flux.gameInstance.floatingText) {
                            window.flux.gameInstance.floatingText.spawn("FULL HEAL", p.mesh.position, "heal");
                        }
                    } 
                },
                DrainEN: () => { 
                    const p = getActive();
                    if(p) {
                        p.currentEN = 0;
                        p.fumble(); // Trigger fumble logic
                    }
                }
            };

            folder.add(proxy, 'Role').listen().disable();
            folder.add(proxy, 'GodMode').name('God Mode (Inf HP/EN)').listen();

            const rtFolder = folder.addFolder('Runtime Status');
            rtFolder.add(proxy, 'HP', 0, 9999).listen();
            rtFolder.add(proxy, 'CurrentEN', 0, 100).name('Current EN').listen();

            const statFolder = folder.addFolder('Base Stats');
            statFolder.add(proxy, 'MaxHP', 100, 9999).listen();
            statFolder.add(proxy, 'EN', 0, 99).name('Max EN').listen();
            statFolder.add(proxy, 'SP', 0, 99).listen();
            statFolder.add(proxy, 'AT', 0, 99).listen();
            statFolder.add(proxy, 'PA', 0, 99).listen();
            statFolder.add(proxy, 'BL', 0, 99).listen();
            statFolder.add(proxy, 'SH', 0, 99).listen();
            statFolder.add(proxy, 'CA', 0, 99).listen();

            const actionFolder = folder.addFolder('Actions');
            actionFolder.add(proxy, 'LevelUp').name('Instant Level Up');
            actionFolder.add(proxy, 'FullHeal').name('Full Heal & Cure');
            actionFolder.add(proxy, 'DrainEN').name('Drain EN (Fumble)');
        }

_setupBallSandbox() {
    const root = this.gui.addFolder('Ball Lab (Throw & Physics)');

    // ------------------------------------------------------------
    // Shared state object (lives on window.flux so it survives reloads)
    // ------------------------------------------------------------
    const lab = window.flux.ballLab = window.flux.ballLab || {};
    lab.game = this.game;

    const C = window.flux.BallConfig;
    const TC = window.flux.ThrowConfig;

    if (!C || !TC) {
        console.warn("Ball Lab: Missing BallConfig or ThrowConfig.");
        return;
    }

    // ------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------
    const getBall = () => this.game && this.game.entities ? this.game.entities.ball : null;
    const getActive = () => this.game && this.game.teams && this.game.teams.home ? this.game.teams.home.activePlayer : null;

    const ensurePreviewLine = () => {
        if (lab.previewLine) return;
        if (!this.game || !this.game.scene) return;

        const geom = new THREE.BufferGeometry();
        const mat = new THREE.LineBasicMaterial({ transparent: true, opacity: 0.95 });
        const line = new THREE.Line(geom, mat);
        line.frustumCulled = false;
        line.renderOrder = 999;
        this.game.scene.add(line);
        lab.previewLine = line;
    };

    const clearPreviewLine = () => {
        if (lab.previewLine && lab.previewLine.geometry) {
            lab.previewLine.geometry.dispose();
            lab.previewLine.geometry = new THREE.BufferGeometry();
        }
    };

    // A safe "ghost ball" that can use Ball.updateFree without spawning FX
    const makeGhostBall = (pos, vel, spin) => {
        const gb = {
            mesh: { position: pos.clone() },
            velocity: vel.clone(),
            angularVelocity: (spin ? spin.clone() : new THREE.Vector3()),
            accumulatedRotation: new THREE.Quaternion(),
            power: 0,
            decayRate: 0,
            _bubbleTimer: 999,
            _ghost: true,
            deformNode: null
        };
        return gb;
    };

    // Use Ball.updateFree for faithful trajectory prediction
    const simulate = (ghostBall, steps, stepDt) => {
        const pts = [];
        pts.push(ghostBall.mesh.position.clone());
        const proto = window.flux.Ball && window.flux.Ball.prototype;
        if (!proto || typeof proto.updateFree !== 'function') return pts;

        for (let i = 0; i < steps; i++) {
            proto.updateFree.call(ghostBall, stepDt);
            pts.push(ghostBall.mesh.position.clone());
        }
        return pts;
    };

    // ------------------------------------------------------------
    // Preview + record/replay runtime loop
    // ------------------------------------------------------------
lab.preview = lab.preview || {
        enabled: false,
        source: 'Cannon',
        steps: 120,
        stepDt: 1/60,
        refreshHz: 10,
        showOnHeldOnly: false
    };

    lab.cannon = lab.cannon || {
        yaw: 0,
        pitch: 0,
        power: 20,
        type: 'SH',
        spinX: 0,
        spinY: 0,
        spinZ: 0,
        fireBurst: 1,
        spreadDeg: 0
    };

    lab.recording = lab.recording || {
        isRecording: false,
        frames: [],
        maxSeconds: 12
    };

    lab.replay = lab.replay || {
        isReplaying: false,
        frames: [],
        idx: 0,
        loop: true,
        speed: 1.0
    };

    lab.isReplaying = false;
    lab.targetBall = null;

    lab.applyReplayFrame = (ball, dt) => {
        const rep = lab.replay;
        if (!rep || !rep.isReplaying || !rep.frames || rep.frames.length === 0) {
            lab.isReplaying = false;
            return;
        }

        // Advance time by stepping indices (frame-based)
        const step = Math.max(1, Math.floor(rep.speed));
        rep.idx += step;

        if (rep.idx >= rep.frames.length) {
            if (rep.loop) rep.idx = 0;
            else { rep.isReplaying = false; lab.isReplaying = false; return; }
        }

        const f = rep.frames[rep.idx];
        if (!f) return;

        ball.drop(); // ensure no holder logic fights us
        ball.state = 'free';
        ball.mesh.position.set(f.px, f.py, f.pz);
        ball.velocity.set(f.vx, f.vy, f.vz);
        ball.angularVelocity.set(f.sx, f.sy, f.sz);
    };

    lab._previewTimer = lab._previewTimer || 0;

    lab.update = (dt) => {
        // --- recording ---
        const b = getBall();
        if (b && lab.recording && lab.recording.isRecording) {
            const r = lab.recording;
            const maxFrames = Math.floor((r.maxSeconds || 12) / (dt || (1/60)));
            if (r.frames.length > maxFrames) r.frames.shift();
            r.frames.push({
                px: b.mesh.position.x, py: b.mesh.position.y, pz: b.mesh.position.z,
                vx: b.velocity.x, vy: b.velocity.y, vz: b.velocity.z,
                sx: b.angularVelocity.x, sy: b.angularVelocity.y, sz: b.angularVelocity.z
            });
        }

        // --- preview refresh ---
        lab._previewTimer += dt;
        const refreshInterval = 1.0 / Math.max(1, (lab.preview.refreshHz || 10));
        if (lab.preview.enabled && lab._previewTimer >= refreshInterval) {
            lab._previewTimer = 0;
            lab.refreshPreview();
        }
    };

    lab.refreshPreview = () => {
        if (!lab.preview.enabled) { clearPreviewLine(); return; }
        ensurePreviewLine();

        const b = getBall();
        const p = getActive();
        if (!b || !b.mesh) return;

        if (lab.preview.showOnHeldOnly && b.state !== 'held') {
            clearPreviewLine();
            return;
        }

        // Decide preview source
        let startPos = b.mesh.position;
        let startVel = b.velocity;
        let startSpin = b.angularVelocity;

        if (lab.preview.source === 'Cannon') {
            // Cannon always launches from ball position (or player if held)
            const yawRad = (lab.cannon.yaw || 0) * Math.PI / 180;
            const pitchRad = (lab.cannon.pitch || 0) * Math.PI / 180;

            const dir = new THREE.Vector3(
                Math.sin(yawRad) * Math.cos(pitchRad),
                Math.sin(pitchRad),
                -Math.cos(yawRad) * Math.cos(pitchRad)
            ).normalize();

            const cap = (window.flux.BallConfig.LAUNCH_SPEED_CAP !== undefined ? window.flux.BallConfig.LAUNCH_SPEED_CAP : 85.0);
            const scale = (window.flux.BallConfig.LAUNCH_SPEED_SCALE !== undefined ? window.flux.BallConfig.LAUNCH_SPEED_SCALE : 1.0);
            const speed = Math.min((lab.cannon.power || 20) * scale, cap);

            startPos = (b.state === 'held' && p && p.mesh) ? p.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0)) : b.mesh.position.clone();
            startVel = dir.multiplyScalar(speed);
            startSpin = new THREE.Vector3(lab.cannon.spinX || 0, lab.cannon.spinY || 0, lab.cannon.spinZ || 0);
        }

        const ghost = makeGhostBall(startPos.clone(), startVel.clone(), startSpin);
        const pts = simulate(ghost, Math.floor(lab.preview.steps || 120), (lab.preview.stepDt || (1/60)));

        if (lab.previewLine) {
            lab.previewLine.geometry.dispose();
            lab.previewLine.geometry = new THREE.BufferGeometry().setFromPoints(pts);
        }
    };

    // ------------------------------------------------------------
    // Folder: Ball Physics (BallConfig)
    // ------------------------------------------------------------
    const phys = root.addFolder('Ball Physics (BallConfig)');

    const integ = phys.addFolder('Integration');
    integ.add(C, 'SUBSTEPS', 1, 12, 1).name('Substeps');
    integ.add(C, 'STOP_SPEED', 0.0, 0.2).name('Stop Speed');

    const drag = phys.addFolder('Water Drag');
    drag.add(C, 'WATER_DRAG_LINEAR', 0.0, 2.0).name('Linear Drag');
    drag.add(C, 'WATER_DRAG_QUAD', 0.0, 0.05).name('Quadratic Drag');

    const spin = phys.addFolder('Spin');
    spin.add(C, 'SPIN_DRAG', 0.0, 3.0).name('Spin Decay');

    const magnus = phys.addFolder('Magnus');
    magnus.add(C, 'MAGNUS_ENABLED').name('Enabled');
    magnus.add(C, 'MAGNUS_COEFF', 0.0, 0.5).name('Coeff');
    magnus.add(C, 'MAGNUS_CAP', 0.0, 200.0).name('Cap');

    const depth = phys.addFolder('Depth Constraint');
    depth.add(C, 'DEPTH_TARGET_Y', -5.0, 5.0).name('Target Y');
    depth.add(C, 'DEPTH_SPRING', 0.0, 10.0).name('Spring');
    depth.add(C, 'DEPTH_DAMP', 0.0, 6.0).name('Damp');

    const arena = phys.addFolder('Arena Boundary');
    arena.add(C, 'BOUNDARY_RADIUS', 10.0, 120.0).name('Radius');
    arena.add(C, 'BOUNDARY_HEIGHT', 2.0, 40.0).name('Height');
    arena.add(C, 'WALL_SOFT_BUFFER', 0.0, 20.0).name('Soft Buffer');
    arena.add(C, 'WALL_SOFT_FORCE', 0.0, 200.0).name('Soft Force');
    arena.add(C, 'WALL_ELASTICITY', 0.0, 1.0).name('Wall Bounce');
    arena.add(C, 'WALL_FRICTION', 0.0, 1.0).name('Wall Friction');
    arena.add(C, 'FLOOR_ELASTICITY', 0.0, 1.0).name('Ceil/Floor Bounce');

    const pocket = arena.addFolder('Goal Pocket');
    pocket.add(C, 'GOAL_POCKET_ENABLED').name('Enabled');
    pocket.add(C, 'GOAL_POCKET_X', 0.0, 40.0).name('Pocket Half-X');
    pocket.add(C, 'GOAL_POCKET_Z', 0.0, 50.0).name('Pocket Start |Z|');
    pocket.add(C, 'GOAL_POCKET_RADIUS', 10.0, 120.0).name('Pocket Radius');

    const launch = phys.addFolder('Launch Mapping');
    launch.add(C, 'LAUNCH_SPEED_SCALE', 0.1, 5.0).name('Speed Scale');
    launch.add(C, 'LAUNCH_SPEED_CAP', 10.0, 200.0).name('Speed Cap');

    // ------------------------------------------------------------
    // Folder: Throw mapping (Player.releaseCharge -> Ball.shoot)
    // ------------------------------------------------------------
    const throwMap = root.addFolder('Throw Mapping (ThrowConfig)');
    throwMap.add(TC, 'SWIPE_MIN_PX', 0, 120, 1).name('Swipe Min PX');
    throwMap.add(TC, 'AIM_DX_SCALE', 0.1, 5.0).name('Aim X Scale');
    throwMap.add(TC, 'AIM_DY_SCALE', 0.1, 5.0).name('Aim Y Scale');
    throwMap.add(TC, 'POWER_BASE', 0.1, 3.0).name('Power Base');
    throwMap.add(TC, 'POWER_RANGE', 0.0, 3.0).name('Power Range');
    throwMap.add(TC, 'POWER_MAX_BONUS_RATIO', 0.0, 1.0).name('Max Bonus Ratio');
    throwMap.add(TC, 'POWER_MAX_MULTIPLIER', 1.0, 6.0).name('Max Multiplier');

    const curveMap = throwMap.addFolder('Curve');
    curveMap.add(TC, 'CURVE_ENABLED').name('Enabled');
    curveMap.add(TC, 'CURVE_INTENSITY_THRESHOLD', 0.0, 1.0).name('Input Threshold');
    curveMap.add(TC, 'CURVE_SPIN_SCALE', 0.0, 4000.0).name('Spin Scale');
    curveMap.add(TC, 'CURVE_SPEED_MULT', 0.0, 5.0).name('Swipe Speed Mult');
    curveMap.add(TC, 'CURVE_SPIN_CAP', 0.0, 6000.0).name('Spin Cap');
    curveMap.add(TC, 'CURVE_PERFECT_SPIN', 0.0, 2000.0).name('Perfect Threshold');

    // ------------------------------------------------------------
    // Folder: Teleport / State tools
    // ------------------------------------------------------------
    const tp = root.addFolder('Teleport / Reset');
    const tpParams = {
        ToCenter: () => { const b = getBall(); if (b) b.reset(); },
        ToActivePlayer: () => { const b = getBall(); const p = getActive(); if (b && p) b.grab(p); },
        ToHomeGoal: () => { const b = getBall(); if (b) { b.drop(); b.mesh.position.set(0, 0, 25); b.velocity.set(0,0,0); b.angularVelocity.set(0,0,0); } },
        ToAwayGoal: () => { const b = getBall(); if (b) { b.drop(); b.mesh.position.set(0, 0, -25); b.velocity.set(0,0,0); b.angularVelocity.set(0,0,0); } },
        ToSky: () => { const b = getBall(); if (b) { b.drop(); b.mesh.position.set(0, 10, 0); b.velocity.set(0,0,0); b.angularVelocity.set(0,0,0); } },
        ClearPreview: () => clearPreviewLine()
    };
    tp.add(tpParams, 'ToCenter');
    tp.add(tpParams, 'ToActivePlayer');
    tp.add(tpParams, 'ToHomeGoal');
    tp.add(tpParams, 'ToAwayGoal');
    tp.add(tpParams, 'ToSky');
    tp.add(tpParams, 'ClearPreview');

    // ------------------------------------------------------------
    // Folder: Shot Cannon (force fire with params)
    // ------------------------------------------------------------
    const cannon = root.addFolder('Shot Cannon');
    cannon.add(lab.cannon, 'yaw', -180, 180, 1).name('Yaw (deg)');
    cannon.add(lab.cannon, 'pitch', -89, 89, 1).name('Pitch (deg)');
    cannon.add(lab.cannon, 'power', 0, 120, 0.1).name('Power');
    cannon.add(lab.cannon, 'type', ['PA','SH']).name('Type');
    cannon.add(lab.cannon, 'spinX', -3000, 3000, 1).name('Spin X');
    cannon.add(lab.cannon, 'spinY', -3000, 3000, 1).name('Spin Y');
    cannon.add(lab.cannon, 'spinZ', -3000, 3000, 1).name('Spin Z');
    cannon.add(lab.cannon, 'fireBurst', 1, 10, 1).name('Burst Count');
    cannon.add(lab.cannon, 'spreadDeg', 0, 30, 0.5).name('Spread (deg)');

    const fireParams = {
        Fire: () => {
            const b = getBall();
            const p = getActive();
            if (!b) return;

            const yawRad = (lab.cannon.yaw || 0) * Math.PI / 180;
            const pitchRad = (lab.cannon.pitch || 0) * Math.PI / 180;

            const baseDir = new THREE.Vector3(
                Math.sin(yawRad) * Math.cos(pitchRad),
                Math.sin(pitchRad),
                -Math.cos(yawRad) * Math.cos(pitchRad)
            ).normalize();

            const start = (b.state === 'held' && p && p.mesh) ? p.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0)) : b.mesh.position.clone();

            for (let i = 0; i < (lab.cannon.fireBurst || 1); i++) {
                const dir = baseDir.clone();
                if (lab.cannon.spreadDeg > 0) {
                    const spread = (lab.cannon.spreadDeg * Math.PI / 180);
                    dir.x += (Math.random()-0.5) * spread;
                    dir.y += (Math.random()-0.5) * spread;
                    dir.z += (Math.random()-0.5) * spread;
                    dir.normalize();
                }

                b.drop();
                b.mesh.position.copy(start);
                b.velocity.set(0,0,0);
                b.angularVelocity.set(0,0,0);

                const spin = new THREE.Vector3(lab.cannon.spinX || 0, lab.cannon.spinY || 0, lab.cannon.spinZ || 0);
                b.shoot(dir, lab.cannon.power || 20, lab.cannon.type || 'SH', null, spin);
            }
        }
    };
    cannon.add(fireParams, 'Fire');

    // ------------------------------------------------------------
    // Folder: Trajectory Preview
    // ------------------------------------------------------------
    const preview = root.addFolder('Trajectory Preview');
    preview.add(lab.preview, 'enabled').name('Enabled').onChange(() => lab.refreshPreview());
    preview.add(lab.preview, 'source', ['Cannon', 'Live Ball']).name('Source').onChange(() => lab.refreshPreview());
    preview.add(lab.preview, 'steps', 10, 600, 1).name('Steps').onChange(() => lab.refreshPreview());
    preview.add(lab.preview, 'stepDt', 1/240, 1/15, 1/240).name('Step dt').onChange(() => lab.refreshPreview());
    preview.add(lab.preview, 'refreshHz', 1, 60, 1).name('Refresh Hz');
    preview.add(lab.preview, 'showOnHeldOnly').name('Only when Held').onChange(() => lab.refreshPreview());

    const previewBtns = {
        Refresh: () => lab.refreshPreview(),
        Hide: () => { lab.preview.enabled = false; clearPreviewLine(); }
    };
    preview.add(previewBtns, 'Refresh');
    preview.add(previewBtns, 'Hide');

    // ------------------------------------------------------------
    // Folder: Record / Replay
    // ------------------------------------------------------------
    const rr = root.addFolder('Record / Replay');
    const rrParams = {
        Record: () => {
            lab.recording.isRecording = true;
            lab.recording.frames = [];
        },
        Stop: () => {
            lab.recording.isRecording = false;
        },
        UseRecordingForReplay: () => {
            lab.replay.frames = (lab.recording.frames || []).slice();
            lab.replay.idx = 0;
        },
        Play: () => {
            const b = getBall();
            if (!b) return;
            lab.replay.isReplaying = true;
            lab.isReplaying = true;
            lab.targetBall = b;
            lab.replay.idx = 0;
        },
        Pause: () => {
            lab.replay.isReplaying = false;
            lab.isReplaying = false;
        },
        Clear: () => {
            lab.recording.frames = [];
            lab.replay.frames = [];
            lab.replay.idx = 0;
            lab.replay.isReplaying = false;
            lab.isReplaying = false;
        }
    };
    rr.add(rrParams, 'Record');
    rr.add(rrParams, 'Stop');
    rr.add(rrParams, 'UseRecordingForReplay').name('Copy Rec -> Replay');
    rr.add(lab.replay, 'loop').name('Loop');
    rr.add(lab.replay, 'speed', 0.25, 6.0, 0.25).name('Replay Speed');
    rr.add(rrParams, 'Play');
    rr.add(rrParams, 'Pause');
    rr.add(rrParams, 'Clear');

    // ------------------------------------------------------------
    // Folder: Presets
    // ------------------------------------------------------------
    const presets = root.addFolder('Presets');
    const P = {
        Vanilla: () => {
            Object.assign(C, {
                SUBSTEPS: 2,
                STOP_SPEED: 0.02,
                WATER_DRAG_LINEAR: 0.15,
                WATER_DRAG_QUAD: 0.002,
                SPIN_DRAG: 0.40,
                MAGNUS_ENABLED: true,
                MAGNUS_COEFF: 0.08,
                MAGNUS_CAP: 60.0,
                DEPTH_TARGET_Y: 0.0,
                DEPTH_SPRING: 1.0,
                DEPTH_DAMP: 1.5,
                BOUNDARY_RADIUS: 33.0,
                BOUNDARY_HEIGHT: 15.0,
                WALL_SOFT_BUFFER: 3.0,
                WALL_SOFT_FORCE: 20.0,
                WALL_ELASTICITY: 0.30,
                WALL_FRICTION: 0.95,
                FLOOR_ELASTICITY: 0.40,
                GOAL_POCKET_ENABLED: true,
                GOAL_POCKET_X: 12.0,
                GOAL_POCKET_Z: 25.0,
                GOAL_POCKET_RADIUS: 45.0,
                LAUNCH_SPEED_SCALE: 1.0,
                LAUNCH_SPEED_CAP: 85.0
            });
            lab.refreshPreview();
        },
        ArcadeCurve: () => {
            Object.assign(C, {
                MAGNUS_ENABLED: true,
                MAGNUS_COEFF: 0.16,
                MAGNUS_CAP: 90.0,
                SPIN_DRAG: 0.25,
                WATER_DRAG_LINEAR: 0.12,
                WATER_DRAG_QUAD: 0.001,
                WALL_SOFT_FORCE: 35.0,
                LAUNCH_SPEED_CAP: 110.0
            });
            Object.assign(TC, {
                CURVE_ENABLED: true,
                CURVE_SPIN_SCALE: 1500.0,
                CURVE_SPIN_CAP: 3000.0,
                CURVE_PERFECT_SPIN: 700.0
            });
            lab.refreshPreview();
        },
        SnappyRealistic: () => {
            Object.assign(C, {
                WATER_DRAG_LINEAR: 0.25,
                WATER_DRAG_QUAD: 0.006,
                MAGNUS_COEFF: 0.05,
                MAGNUS_CAP: 40.0,
                SPIN_DRAG: 0.75,
                STOP_SPEED: 0.05,
                LAUNCH_SPEED_CAP: 70.0
            });
            lab.refreshPreview();
        }
    };
    presets.add(P, 'Vanilla');
    presets.add(P, 'ArcadeCurve');
    presets.add(P, 'SnappyRealistic');

    // ------------------------------------------------------------
    // Folder: Snapshot / Export
    // ------------------------------------------------------------
    const snapshot = root.addFolder('Snapshot / Export');

    const _round = (n, places = 4) => {
        if (!Number.isFinite(n)) return null;
        const p = Math.pow(10, places);
        return Math.round(n * p) / p;
    };

    const _v3 = (v, places = 4) => {
        if (!v) return null;
        return [_round(v.x, places), _round(v.y, places), _round(v.z, places)];
    };

    const _cloneJson = (obj) => {
        if (!obj) return null;
        try { return JSON.parse(JSON.stringify(obj)); } catch (e) { return null; }
    };

    const _playerSnap = (p) => {
        if (!p) return null;
        const anim = (p.activeAction && p.activeAction._clip) ? p.activeAction._clip.name : (p.state || null);
        return {
            name: p.characterName || p.name || null,
            role: p.role || null,
            state: p.state || null,
            hasBall: !!p.hasBall,
            isThrowing: !!p.isThrowing,
            isCharging: !!p.isCharging,
            isDashing: !!p.isDashing,
            dashCooldown: _round(p.dashCooldown, 4),
            pos: _v3(p.mesh && p.mesh.position),
            vel: _v3(p.velocity),
            input: _v3(p.inputVector),
            stats: p.stats ? _cloneJson(p.stats) : null,
            anim
        };
    };

    const _teamSnap = (t) => {
        if (!t) return null;
        const active = t.activePlayer ? _playerSnap(t.activePlayer) : null;
        return {
            id: t.id || null,
            side: t.side,
            isHuman: !!t.isHuman,
            aiEnabled: !!t.aiEnabled,
            currentFormation: t.currentFormation || null,
            activePlayer: active,
            players: Array.isArray(t.players) ? t.players.map(_playerSnap) : []
        };
    };

    const buildSnapshot = () => {
        const game = this.game || window.flux.gameInstance || null;
        const ball = game && game.entities ? game.entities.ball : null;
        const camMgr = game ? game.cameraManager : null;
        const cam = (camMgr && camMgr.camera) ? camMgr.camera : (game ? game.camera : null);

        const ballSnap = ball ? {
            state: ball.state || null,
            isInvisible: !!ball.isInvisible,
            holder: ball.holder ? (ball.holder.characterName || ball.holder.name || null) : null,
            lastHolder: ball.lastHolder ? (ball.lastHolder.characterName || ball.lastHolder.name || null) : null,
            pos: _v3(ball.mesh && ball.mesh.position),
            vel: _v3(ball.velocity),
            angVel: _v3(ball.angularVelocity),
            power: _round(ball.power, 4),
            shotType: ball.shotType || null
        } : null;

        const cameraSnap = cam ? {
            pos: _v3(cam.position),
            rot: cam.rotation ? [_round(cam.rotation.x, 4), _round(cam.rotation.y, 4), _round(cam.rotation.z, 4)] : null,
            fov: _round(cam.fov, 4),
            near: _round(cam.near, 6),
            far: _round(cam.far, 4)
        } : null;

        const camMgrSnap = camMgr ? {
            mode: camMgr.mode || null,
            targetName: (camMgr.target && (camMgr.target.characterName || camMgr.target.name)) || null,
            settings: camMgr.settings ? _cloneJson(camMgr.settings) : null
        } : null;

        const debugIO = window.flux && window.flux._debugIO ? window.flux._debugIO : null;
        const inputSnap = debugIO ? {
            settings: debugIO.settings ? _cloneJson(debugIO.settings) : null,
            perf: debugIO.perf ? _cloneJson(debugIO.perf) : null,
            move: (debugIO.input && debugIO.input.move) ? {
                touchId: debugIO.input.move.touchId ?? null,
                dragging: !!debugIO.input.move.dragging,
                vector: debugIO.input.move.vector ? _cloneJson(debugIO.input.move.vector) : null
            } : null,
            aim: (debugIO.input && debugIO.input.aim) ? {
                touchId: debugIO.input.aim.touchId ?? null,
                dragging: !!debugIO.input.aim.dragging,
                vector: debugIO.input.aim.vector ? _cloneJson(debugIO.input.aim.vector) : null
            } : null,
            swipe: (debugIO.input && debugIO.input.swipe) ? {
                touchId: debugIO.input.swipe.touchId ?? null,
                start: debugIO.input.swipe.start ? _cloneJson(debugIO.input.swipe.start) : null,
                points: Array.isArray(debugIO.input.swipe.points) ? debugIO.input.swipe.points.slice(-32).map(_cloneJson) : []
            } : null
        } : null;

        return {
            meta: {
                timestampISO: new Date().toISOString(),
                href: (typeof location !== 'undefined' && location.href) ? location.href : null,
                userAgent: (typeof navigator !== 'undefined' && navigator.userAgent) ? navigator.userAgent : null
            },
            game: game ? {
                score: game.score ? _cloneJson(game.score) : null,
                time: _round(game.time, 4),
                half: game.half ?? null,
                halfDuration: _round(game.halfDuration, 4),
                isOvertime: !!game.isOvertime,
                isDemoMode: !!game.isDemoMode
            } : null,
            config: {
                BallConfig: (window.flux && window.flux.BallConfig) ? _cloneJson(window.flux.BallConfig) : null,
                ThrowConfig: (window.flux && window.flux.ThrowConfig) ? _cloneJson(window.flux.ThrowConfig) : null
            },
            camera: cameraSnap,
            cameraManager: camMgrSnap,
            ball: ballSnap,
            teams: game ? {
                home: _teamSnap(game.teams && game.teams.home),
                away: _teamSnap(game.teams && game.teams.away)
            } : null,
            input: inputSnap
        };
    };

    const _copyText = async (text) => {
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(text);
                return true;
            }
        } catch (e) {}
        // Fallback
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            ta.style.top = '-9999px';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            const ok = document.execCommand('copy');
            document.body.removeChild(ta);
            return ok;
        } catch (e) {}
        return false;
    };

    const _downloadText = (filename, text) => {
        try {
            const blob = new Blob([text], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            a.remove();
            URL.revokeObjectURL(url);
        } catch (e) {
            console.warn('Snapshot download failed:', e);
        }
    };

    const snapshotActions = {
        CopySnapshot: async () => {
            const snap = buildSnapshot();
            const text = JSON.stringify(snap, null, 2);
            const ok = await _copyText(text);
            console.log('[Snapshot]', snap);
            if (!ok) console.warn('Snapshot: copy failed (see console).');
        },
        DownloadSnapshot: () => {
            const snap = buildSnapshot();
            const text = JSON.stringify(snap, null, 2);
            _downloadText('snapshot.json', text);
            console.log('[Snapshot]', snap);
        }
    };

    snapshot.add(snapshotActions, 'CopySnapshot').name('Copy JSON Snapshot');
    snapshot.add(snapshotActions, 'DownloadSnapshot').name('Download snapshot.json');

}
    }

window.flux.DevTools = DevTools;

DevTools.prototype._setupVisualDebug = function() {
        const folder = this.gui.addFolder('Visual Debugging');
        const dv = this.game.debugVisualizer;
        if (!dv) return;

        const params = {
            enabled: dv.enabled,
            hitboxes: dv.showHitboxes,
            vectors: dv.showVectors,
            ai: dv.showAI,
            goalVolume: dv.showGoalVolume
        };

        folder.add(params, 'enabled').name('Enable Visualizer').onChange(v => dv.enabled = v);
        folder.add(params, 'hitboxes').name('Show Hitboxes').onChange(v => dv.showHitboxes = v);
        folder.add(params, 'vectors').name('Show Vectors').onChange(v => dv.showVectors = v);
        folder.add(params, 'ai').name('Show AI Perception').onChange(v => dv.showAI = v);
        folder.add(params, 'goalVolume').name('Show Goal Volume').onChange(v => dv.showGoalVolume = v);
    };

    DevTools.prototype._setupFXLab = function() {
        const folder = this.gui.addFolder('FX Lab & UI Test');
        
        const getTargetPos = () => {
            const p = this.game.teams.home.activePlayer;
            return p && p.mesh ? p.mesh.position : new THREE.Vector3(0, 2, 0);
        };

        const fxParams = {
            SpawnVenom: () => this.game.particleManager.spawn('venom', getTargetPos()),
            SpawnNap: () => this.game.particleManager.spawn('nap', getTargetPos()),
            SpawnWither: () => this.game.particleManager.spawn('wither', getTargetPos()),
            SpawnLearned: () => this.game.particleManager.spawn('learned', getTargetPos()),
            SpawnClash: () => this.game.spawnClash(getTargetPos()),
        };

        const fxSub = folder.addFolder('Particles');
        fxSub.add(fxParams, 'SpawnVenom');
        fxSub.add(fxParams, 'SpawnNap');
        fxSub.add(fxParams, 'SpawnWither');
        fxSub.add(fxParams, 'SpawnLearned');
        fxSub.add(fxParams, 'SpawnClash');

        const txtParams = {
            Text: "TEST",
            Type: "damage",
            Spawn: () => {
                if(this.game.floatingText) 
                    this.game.floatingText.spawn(txtParams.Text, getTargetPos(), txtParams.Type);
            }
        };
        
        const txtSub = folder.addFolder('Floating Text');
        txtSub.add(txtParams, 'Text');
        txtSub.add(txtParams, 'Type', ['damage', 'heal', 'status', 'tech', 'comic-impact', 'comic-action', 'save', 'block', 'default']);
        txtSub.add(txtParams, 'Spawn').name('Spawn Text');

        const camParams = {
            ShakeSmall: () => this.game.cameraManager.addShake(0.5),
            ShakeBig: () => this.game.cameraManager.addShake(2.0),
            ImpactLight: () => this.game.triggerImpact(0.1, 'default'),
            ImpactHeavy: () => this.game.triggerImpact(0.2, 'heavy'),
            ImpactShatter: () => this.game.triggerImpact(0.4, 'shatter'),
        };

        const camSub = folder.addFolder('Camera & Impact');
        camSub.add(camParams, 'ShakeSmall');
        camSub.add(camParams, 'ShakeBig');
        camSub.add(camParams, 'ImpactLight');
        camSub.add(camParams, 'ImpactHeavy');
        camSub.add(camParams, 'ImpactShatter');
    };


DevTools.prototype._setupVisuals = function() {
        const folder = this.gui.addFolder('Asset Forge');
        
        const forgeState = {
            active: false,
            assetName: 'Tidus',
            animName: 'idle',
            posX: 0, posY: 0, posZ: 0,
            rotX: 0, rotY: 0, rotZ: 0,
            scale: 1.0,
            camDist: 5, camHeight: 1.5, camRot: 0
        };

        const assets = {
            'Tidus': 'https://cdn.tinyglb.com/models/da788bef258c4f0b8d9ef1acc19c5567.glb',
            'Wakka': 'https://cdn.tinyglb.com/models/59114c98951647c9b8da74b0bd3636cb.glb',
            'Letty': 'https://cdn.tinyglb.com/models/43ace34c6fd94215967e842bf909da5e.glb',
            'Datto': 'https://cdn.tinyglb.com/models/e6d67ecb2e4c4715bd73a40795e1d3d5.glb',
            'Jassu': 'https://cdn.tinyglb.com/models/8216459567354e63958d4108d828de98.glb',
            'Botta': 'https://cdn.tinyglb.com/models/ad155efedc0d48fdad09da3e1cae9c97.glb',
            'Ball': 'https://cdn.tinyglb.com/models/521ae8788e584e378a79d9732a075356.glb',
            'Goal': 'https://cdn.tinyglb.com/models/a516bd90fa7c4dedb5dcbfdf803f13d5.glb'
        };

        let currentAsset = null;

        const updateTransform = () => {
            if (currentAsset) {
                currentAsset.position.set(forgeState.posX, forgeState.posY, forgeState.posZ);
                currentAsset.rotation.set(forgeState.rotX, forgeState.rotY, forgeState.rotZ);
                currentAsset.scale.setScalar(forgeState.scale);
            }
        };

        const updateCamera = () => {
            if (!forgeState.active) return;
            // Orbit around (1000, Y, 1000)
            const cx = 1000 + Math.sin(forgeState.camRot) * forgeState.camDist;
            const cz = 1000 + Math.cos(forgeState.camRot) * forgeState.camDist;
            this.game.camera.position.set(cx, forgeState.camHeight, cz);
            this.game.camera.lookAt(1000, forgeState.posY + 1, 1000);
        };

        const playAnimation = () => {
            if (!this.vizMixer || !this.vizClips) return;
            this.vizMixer.stopAllAction();
            if (forgeState.animName === 'none') return;
            
            let clip = this.vizClips.find(c => c.name === forgeState.animName);
            if (!clip) clip = this.vizClips.find(c => c.name.toLowerCase().includes(forgeState.animName.toLowerCase()));
            if (clip) this.vizMixer.clipAction(clip).play();
        };

        const spawnAsset = () => {
            if (!this.vizGroup) return;
            
            // Clear previous
            while(this.vizGroup.children.length > 0) {
                const child = this.vizGroup.children[0];
                this.vizGroup.remove(child);
            }
            
            this.vizMixer = null;
            currentAsset = null;

            const url = assets[forgeState.assetName];
            if (!url) return;

            console.log("Forge: Spawning", forgeState.assetName);

            window.flux.AssetLoader.loadModel(url, (gltf) => {
                // Check if we are still in forge mode before adding
                if (!forgeState.active) return;

                const model = gltf.scene;
                this.vizGroup.add(model);
                currentAsset = model;
                
                // Reset model transform relative to group
                model.position.set(0,0,0);
                model.rotation.set(0,0,0);
                
                updateTransform();

                if (gltf.animations && gltf.animations.length > 0) {
                    this.vizMixer = new THREE.AnimationMixer(model);
                    this.vizClips = gltf.animations;
                    playAnimation();
                }
            });
        };

        const toggleForge = (isActive) => {
            forgeState.active = isActive;
            this.game.isForgeMode = isActive; // Critical: Tell main.js to stop game loop
            
            // Toggle Game Visibility (Hide everything in the main arena)
            const gameLayer = [this.game.teams.home, this.game.teams.away, this.game.entities.ball];
            gameLayer.forEach(t => {
                if(t && t.players) t.players.forEach(p => { if(p.mesh) p.mesh.visible = !isActive; });
                else if(t && t.mesh) t.mesh.visible = !isActive;
            });
            if(window.flux.arenaMesh) window.flux.arenaMesh.visible = !isActive;
            if(window.flux.arenaMesh2) window.flux.arenaMesh2.visible = !isActive;
            if(this.game.stadium && this.game.stadium.container) this.game.stadium.container.visible = !isActive;
            if(this.game.waterOverlay && this.game.waterOverlay.mesh) this.game.waterOverlay.mesh.visible = !isActive;
            
            // Hide UI
            const ui = document.getElementById('ui-layer');
            if(ui) ui.style.display = isActive ? 'none' : 'flex';

            if (isActive) {
                // Initialize Forge Scene if needed
                if (!this.vizGroupParent) {
                    this.vizGroupParent = new THREE.Group();
                    this.game.scene.add(this.vizGroupParent);
                    
                    this.vizGroup = new THREE.Group();
                    this.vizGroup.position.set(1000, 0, 1000); // Far away from arena
                    this.vizGroupParent.add(this.vizGroup);

                    const grid = new THREE.GridHelper(20, 20, 0x00ffff, 0x444444);
                    grid.position.set(1000, 0, 1000);
                    this.vizGroupParent.add(grid);

                    this.vizLight = new THREE.DirectionalLight(0xffffff, 1.0);
                    this.vizLight.position.set(1005, 10, 1005);
                    this.game.scene.add(this.vizLight);
                    
                    this.vizAmbient = new THREE.AmbientLight(0x404040);
                    this.game.scene.add(this.vizAmbient);
                }
                
                this.vizGroupParent.visible = true;
                this.vizLight.visible = true;
                this.vizAmbient.visible = true;
                
                spawnAsset();
                updateCamera();
                
            } else {
                // Restore Game
                if (this.vizGroupParent) this.vizGroupParent.visible = false;
                if (this.vizLight) this.vizLight.visible = false;
                if (this.vizAmbient) this.vizAmbient.visible = false;
                
                // Snap camera back to game target
                if (this.game.cameraManager) this.game.cameraManager.snapToTarget();
            }
        };

        folder.add(forgeState, 'active').name('Enable Forge').onChange(toggleForge);
        folder.add(forgeState, 'assetName', Object.keys(assets)).name('Select Asset').onChange(spawnAsset);
        
        const tf = folder.addFolder('Transform');
        tf.add(forgeState, 'posX', -5, 5).onChange(updateTransform);
        tf.add(forgeState, 'posY', -5, 5).onChange(updateTransform);
        tf.add(forgeState, 'posZ', -5, 5).onChange(updateTransform);
        tf.add(forgeState, 'rotX', 0, 6.28).onChange(updateTransform);
        tf.add(forgeState, 'rotY', 0, 6.28).onChange(updateTransform);
        tf.add(forgeState, 'rotZ', 0, 6.28).onChange(updateTransform);
        tf.add(forgeState, 'scale', 0.1, 3.0).onChange(updateTransform);

        folder.add(forgeState, 'animName', ['none', 'idle', 'swim', 'throw', 'catch', 'react']).name('Animation').onChange(playAnimation);

        const cf = folder.addFolder('Camera');
        cf.add(forgeState, 'camDist', 2, 15).onChange(updateCamera);
        cf.add(forgeState, 'camHeight', 0, 10).onChange(updateCamera);
        cf.add(forgeState, 'camRot', 0, 6.28).onChange(updateCamera);

        // Hook Game Loop
        const originalUpdate = this.game.update.bind(this.game);
        this.game.update = (dt) => {
            if (forgeState.active) {
                // Forge Mode: Only update forge components and render
                if (this.vizMixer) this.vizMixer.update(dt);
                
                // Force Camera Update here since main.js loop is skipped
                updateCamera();

                if (this.game.renderer && this.game.scene && this.game.camera) {
                    this.game.renderer.render(this.game.scene, this.game.camera);
                }
            } else {
                // Normal Mode: Run standard game update
                originalUpdate(dt);
            }
        };
    };
})();