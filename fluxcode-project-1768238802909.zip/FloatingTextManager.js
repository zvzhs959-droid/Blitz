(function() {
    window.flux = window.flux || {};

    class FloatingTextManager {
        constructor(scene, containerId, camera) {
            this.scene = scene;
            this.camera = camera;
            this.container = document.getElementById(containerId);
            this.texts = [];
            
            // Reusable vector for projection
            this._tempV = new THREE.Vector3();
        }

spawn(text, worldPos, type = 'default', target = null) {
            if (!this.container || !this.camera) return;

            // Create Wrapper (Positioning)
            const wrapper = document.createElement('div');
            wrapper.className = 'floating-text-wrapper';

            // Create Inner (Animation/Styling)
            const inner = document.createElement('span');
            inner.innerText = text;
            
            // Smart Class Assignment
            let classes = ['floating-text-inner'];
            
            // Add base type
            classes.push(type);

            // Keyword Detection for Auto-Styling
            const upper = text.toString().toUpperCase();
            
if (upper.includes('POISON') || upper.includes('VENOM')) classes.push('venom');
            else if (upper.includes('SLEEP') || upper.includes('NAP') || upper.includes('ZZZ')) classes.push('sleep');
            else if (upper.includes('WITHER')) classes.push('wither');
            else if (type === 'tech' || upper.includes('SHOT') || upper.includes('JECHT') || upper.includes('TACKLE')) classes.push('tech');
            else if (type === 'comic-impact') classes.push('comic-impact');
            else if (type === 'comic-action') classes.push('comic-action');
            else if (!isNaN(parseInt(text)) && type !== 'score') classes.push('damage'); // Numeric is usually damage
            else if (type === 'save' || type === 'block') classes.push('save');

            inner.className = classes.join(' ');
            wrapper.appendChild(inner);
            this.container.appendChild(wrapper);

            // Physics Instance
            const instance = {
                el: wrapper, 
                worldPos: worldPos.clone(),
                offset: new THREE.Vector3(0, 0, 0),
                velocity: new THREE.Vector3(0, 0, 0),
                gravity: 0,
                drag: 0,
                elasticity: 0.6,
                floorY: -999, // Virtual floor relative to start
                
life: 1.0,  // Reduced from 1.5
                maxLife: 1.0,
                target: target
            };

            // Customize Physics based on Type
if (classes.includes('damage') || classes.includes('save') || classes.includes('block')) {
                // DEBRIS PHYSICS (Pop, Arc, Bounce)
                instance.target = null; // Detach from entity so it falls naturally
                instance.gravity = 40.0; // Heavy gravity for snappy feel
                instance.drag = 0.5;
                instance.floorY = -4.0; // Bounce off a virtual floor below impact
                
                // Explosive Burst
                const spread = 6.0;
                instance.velocity.set(
                    (Math.random() - 0.5) * spread,
                    15.0 + Math.random() * 5.0, // High initial pop
                    (Math.random() - 0.5) * spread
                );
                
                instance.life = 2.0;
                instance.maxLife = 2.0;

            } else if (classes.includes('comic-impact')) {
                // COMIC POP (Stay in place mostly, slight drift)
                instance.gravity = 0;
                instance.velocity.set((Math.random()-0.5)*2, 1.0, (Math.random()-0.5)*2);
instance.life = 0.5; // Reduced from 0.8
                instance.maxLife = 0.5;

            } else if (classes.includes('comic-action')) {
                // COMIC ZIP (Fast movement)
                instance.gravity = 0;
                instance.velocity.set(0, 2.0, 0);
instance.life = 0.4; // Reduced from 0.6
                instance.maxLife = 0.4;

            } else if (classes.includes('tech')) {
                // TECH FLOAT (Slow rise)
                instance.gravity = 0;
                instance.velocity.set(0, 2.0, 0); // Steady rise
                instance.life = 2.5;
                instance.maxLife = 2.5;
                instance.offset.y = 2.0; // Start higher

            } else if (classes.includes('sleep')) {
                // SLEEP DRIFT (Slow meandering)
                instance.gravity = -0.5; // Slight anti-gravity
                instance.velocity.set(0, 0.5, 0);
                instance.life = 3.0;
                instance.maxLife = 3.0;

            } else {
                // DEFAULT (Status, etc)
                instance.velocity.set(0, 3.0, 0);
                instance.gravity = 5.0; // Slight arc
            }
            
            // Randomize start pos slightly to prevent stacking
            if (!target) {
                instance.worldPos.x += (Math.random() - 0.5) * 0.5;
                instance.worldPos.z += (Math.random() - 0.5) * 0.5;
            }
instance.worldPos.y += 1.0;
            this.texts.push(instance);
            this.updatePosition(instance);
        }

// spawnVersus removed

        update(dt) {
            for (let i = this.texts.length - 1; i >= 0; i--) {
                const t = this.texts[i];
                t.life -= dt;
                
                // If attached to a target, update base position (only for non-debris)
                if (t.target && t.target.parent) { 
                    t.worldPos.copy(t.target.position);
                    t.worldPos.y += 1.0; 
                }

                // Physics Integration
                if (t.gravity !== 0 || t.velocity.lengthSq() > 0) {
                    // Gravity
                    t.velocity.y -= t.gravity * dt;
                    
                    // Drag (Air resistance)
                    if (t.drag > 0) {
                        t.velocity.multiplyScalar(Math.max(0, 1.0 - (t.drag * dt)));
                    }

                    // Move
                    t.offset.addScaledVector(t.velocity, dt);

                    // Bounce Logic
                    if (t.offset.y < t.floorY) {
                        t.offset.y = t.floorY;
                        // Bounce velocity
                        t.velocity.y *= -t.elasticity;
                        // Ground friction
                        t.velocity.x *= 0.7;
                        t.velocity.z *= 0.7;
                        
                        // Stop bouncing if energy is low
                        if (Math.abs(t.velocity.y) < 2.0) t.velocity.y = 0;
                    }
                }

                if (t.life <= 0) {
                    if (t.el.parentNode) t.el.parentNode.removeChild(t.el);
                    this.texts.splice(i, 1);
                } else {
                    this.updatePosition(t);
                    // Fade out in last 30%
                    if (t.life < t.maxLife * 0.3) {
                        t.el.style.opacity = t.life / (t.maxLife * 0.3);
                    }
                }
            }
        }

        updatePosition(t) {
            // Project world pos + offset to screen
            this._tempV.copy(t.worldPos).add(t.offset);
            
            // Standard Three.js projection
            this._tempV.project(this.camera);

            const x = (this._tempV.x * .5 + .5) * this.container.clientWidth;
            const y = (-(this._tempV.y * .5) + .5) * this.container.clientHeight;

            // Hide if behind camera
            if (this._tempV.z > 1) {
                t.el.style.display = 'none';
            } else {
                t.el.style.display = 'block';
                t.el.style.transform = `translate(${x}px, ${y}px)`;
            }
}
    }

    window.flux.FloatingTextManager = FloatingTextManager;
})();