(function() {
    window.flux = window.flux || {};

    const _loader = new THREE.GLTFLoader();

    // Helper to convert a single material to Basic (Unlit/PSX)
// Helper to convert a single material to Basic (Unlit/PSX)
    function convertMaterial(oldMat, isSkinned) {
        
        // Preserve texture: Check map, then emissiveMap
        const texture = oldMat.map || oldMat.emissiveMap || null;

        // FORCE OPAQUE VISIBILITY
        // We override transparency to ensure models are always visible (fixing the "invisible model" issue).
        const params = {
            map: texture,
            color: 0xffffff,        // FORCE WHITE: Remove any tint from GLTF
            skinning: isSkinned,
            side: THREE.DoubleSide, // Render both sides to prevent backface culling invisibility
            transparent: false,     // Disable transparency to prevent sorting issues
            opacity: 1.0,           // Force full opacity
            alphaTest: 0.5,         // Strong alpha test for cutouts (nets/grates)
            vertexColors: oldMat.vertexColors, // Preserve vertex colors
            depthTest: true,
            depthWrite: true,       // Force depth write so it occludes properly
            fog: true
        };

        // Ensure texture encoding is correct for Three.js
        if (params.map) params.map.encoding = THREE.sRGBEncoding;

        return new THREE.MeshBasicMaterial(params);
    }

    window.flux.AssetLoader = {
        loadModel: function(url, onLoad, onProgress, onError) {
            _loader.load(url, function(gltf) {
                gltf.scene.traverse(function(node) {
                    if (node.isMesh) {
node.castShadow = false;
                        node.receiveShadow = false;
                        node.frustumCulled = false; // Prevent invisibility
                        if (node.material) {
                            if (Array.isArray(node.material)) {
                                node.material = node.material.map(m => convertMaterial(m, node.isSkinnedMesh));
                            } else {
                                node.material = convertMaterial(node.material, node.isSkinnedMesh);
                            }
                        }
                    }
                });
                if (onLoad) onLoad(gltf);
            }, onProgress, onError);
        }
    };
})();