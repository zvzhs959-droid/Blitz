(function() {
    window.flux = window.flux || {};

    class AudioManager {
        constructor() {
            this.bgm = new Audio();
            this.bgm.src = 'https://files.catbox.moe/sp2yhy.mp3';
            this.bgm.loop = true;
            this.bgm.volume = 0.5;
            this.isMuted = false;
            this.hasInteracted = false;
            this.shouldBePlaying = false; // Intent flag

            // Preload
            this.bgm.load();

            // --- HERCULEAN LOOP ENFORCEMENT ---
            // 1. Manual Loop Redundancy
            this.bgm.addEventListener('ended', () => {
                console.log("AudioManager: BGM ended event caught. Forcing manual loop reset.");
                this.bgm.currentTime = 0;
                if (this.shouldBePlaying && !this.isMuted) {
                    const p = this.bgm.play();
                    if (p !== undefined) p.catch(e => console.warn("Manual loop replay failed:", e));
                }
            });

            // 2. Pause Watchdog (If paused but should be playing, FORCE PLAY)
            this.bgm.addEventListener('pause', () => {
                if (this.shouldBePlaying && !this.isMuted) {
                    // Small timeout to allow intentional operations to finish if any
                    setTimeout(() => {
                        if (this.shouldBePlaying && this.bgm.paused) {
                            console.log("AudioManager: Unexpected pause detected. Attempting resume.");
                            this.bgm.play().catch(e => console.warn("Resume failed:", e));
                        }
                    }, 100);
                }
            });

            // 3. Periodic Watchdog (The "Never Stop" Guarantee)
            setInterval(() => this._watchdog(), 1000);
        }

        _watchdog() {
            if (this.shouldBePlaying && !this.isMuted) {
                if (this.bgm.paused || this.bgm.ended) {
                    console.log("AudioManager: Watchdog forcing play.");
                    this.bgm.play().catch(() => {
                        // Silent catch, likely waiting for interaction
                    });
                }
            }
        }

        playBGM() {
            if (this.isMuted) return;
            this.shouldBePlaying = true;
            
            const playPromise = this.bgm.play();
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    console.log("AudioManager: Autoplay prevented. Engaging interaction lock.");
                    this._waitForInteraction();
                });
            }
        }

        _waitForInteraction() {
            if (this._waitingForInteraction) return;
            this._waitingForInteraction = true;
            
            const onInteract = () => {
                this.hasInteracted = true;
                
                // Try to play
                if (this.shouldBePlaying && !this.isMuted) {
                    this.bgm.play().then(() => {
                        // Success! Detach listeners
                        this._waitingForInteraction = false;
                        this._removeInteractionListeners(onInteract);
                        console.log("AudioManager: Audio unlocked successfully.");
                    }).catch(e => {
                        console.warn("AudioManager: Interaction play failed. Keeping listeners attached.", e);
                        // Do NOT detach listeners, wait for next interaction
                    });
                } else {
                    // Not supposed to play? Just detach.
                    this._waitingForInteraction = false;
                    this._removeInteractionListeners(onInteract);
                }
            };
            
            // Use capture to catch it early, but don't use 'once: true' so we can retry if failed
            const opts = { capture: true, passive: true };
            document.addEventListener('click', onInteract, opts);
            document.addEventListener('touchstart', onInteract, opts);
            document.addEventListener('keydown', onInteract, opts);
            document.addEventListener('mousedown', onInteract, opts);
        }

        _removeInteractionListeners(handler) {
            const opts = { capture: true, passive: true };
            document.removeEventListener('click', handler, opts);
            document.removeEventListener('touchstart', handler, opts);
            document.removeEventListener('keydown', handler, opts);
            document.removeEventListener('mousedown', handler, opts);
        }

        stopBGM() {
            this.shouldBePlaying = false;
            this.bgm.pause();
            this.bgm.currentTime = 0;
        }

        pauseBGM() {
            this.shouldBePlaying = false;
            this.bgm.pause();
        }

        resumeBGM() {
            if (!this.isMuted) {
                this.playBGM();
            }
        }

        setVolume(volume) {
            this.bgm.volume = Math.max(0, Math.min(1, volume));
        }

        toggleMute() {
            this.isMuted = !this.isMuted;
            if (this.isMuted) {
                this.shouldBePlaying = false;
                this.bgm.pause();
            } else {
                this.playBGM();
            }
            return this.isMuted;
        }
    }

    window.flux.AudioManager = AudioManager;
})();