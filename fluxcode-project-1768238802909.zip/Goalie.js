(function() {
    window.flux = window.flux || {};
    
    // Reusable vectors to avoid GC
const _gVec = new THREE.Vector3();
    const _gPos = new THREE.Vector3();
    const _ballPos = new THREE.Vector3();
    const _faceVec = new THREE.Vector3();
    const _goalCenter = new THREE.Vector3();
    const _tempVecG = new THREE.Vector3();

    class Goalie extends window.flux.Player {
constructor(scene, role) {
            super(scene, role);
            
            // Goalie Specific Stats (Buffed for Playability)
            this.stats.CA = 30; // Catch
            this.stats.SP = 40; // Speed
            this.stats.EN = 50;
            
            // BUFFED: Strong arm for clearing the zone
            this.stats.PA = 45; // Was 20 - Now strong enough to reach midfield
            this.stats.SH = 35; // Was 10 - Decent clearance kick
            
            this._updateDerivedStats();

            // Goal Dimensions (Save Box) - Matches GameManager detection
            this.goalWidth = 22.0; 
            this.goalHeight = 18.0; 
            
            // Save Mechanics
            this.saveRadius = 6.0; 
            this.pressureMultiplier = 5.0; 
            
            // Techs
            this.techs = {
                active: null, 
                passive: null 
            };
            
            // AI State
            this.throwTimer = 0;
            this._accumulatedSave = 0;
            
            // Super Goalie State
            this.isSuperGoalie = false;
            this.superGoalieTimer = 0;

// Perception Smoothing (Reaction Delay)
            this.perceivedBallPos = new THREE.Vector3();
            this.reactionSpeed = 4.0; // Lower = more delay/smoothing
            this.techImmunityTimer = 0;
        }

        update(dt) {
            // 1. Super Goalie Timer
            if (this.isSuperGoalie) {
                this.superGoalieTimer -= dt;
                if (this.superGoalieTimer <= 0) {
                    this.isSuperGoalie = false;
                }
            }
            
            // 2. Possession Logic (Ball Held)
            if (this.hasBall) {
                this._checkTacklePressure(dt);
                
                const game = window.flux.gameInstance;
                const isHumanControlled = this.team && this.team.isHuman && this.team.activePlayer === this && !game.isDemoMode;
                
                if (isHumanControlled) {
                    // Human: Full control (Rotation, Charging, etc via Player.update)
                    super.update(dt);
                } else {
                    // AI: Logic then update
                    if (!this.isThrowing) {
                        this._aiPossessionLogic(dt);
                    }
                    // Ensure AI doesn't drift
                    this.setInput(0, 0);
                    super.update(dt);
                }
                this._constrainBounds();
                return; 
            }

            // 3. Defense / Save Logic (No Ball)
            // We must handle timers and status manually because we skip super.update() to use custom movement
            if (this.dashCooldown > 0) this.dashCooldown -= dt;
            if (this.clashCooldown > 0) this.clashCooldown -= dt;
            if (this.stunTimer > 0) this.stunTimer -= dt;
            if (this.immunityTimer > 0) this.immunityTimer -= dt;
if (this.immunityTimer > 0) this.immunityTimer -= dt;
            this._updateStatus(dt);

            if (this.stunTimer > 0 || this.status.nap > 0) {
                if (this.mixer) this.mixer.update(dt);
                this._updateHPBar();
                this._constrainBounds();
                return;
            }

            // Custom Movement
            this._defenseLogic(dt);
            
            // Update Animation
            if (this.mixer) this.mixer.update(dt);
            this._updateHPBar();
            
            this._constrainBounds();
        }

_constrainBounds() {
            if (!this.mesh) return;
            const pos = this.mesh.position;
            const side = this.team ? this.team.side : 1;
            
            // X Bounds (Width of penalty area +/- 10m) -> Increased for massive goal
const xLimit = 20.0; // Reduced width of goalie movement
            if (pos.x > xLimit) { pos.x = xLimit; this.velocity.x = 0; }
            if (pos.x < -xLimit) { pos.x = -xLimit; this.velocity.x = 0; }
            
            // Y Bounds
            const yLimit = 12.0; // Reduced height ceiling
            if (pos.y > yLimit) { pos.y = yLimit; this.velocity.y = 0; }
            if (pos.y < -yLimit) { pos.y = -yLimit; this.velocity.y = 0; }
            
            // Z Bounds (Depth)
// Z Bounds (Depth)
            // Home (Side 1): Goal at +46. Trigger at 45. Limit to 45.5.
            // Away (Side -1): Goal at -46. Trigger at -45. Limit to -45.5.
            if (side === 1) {
                if (pos.z > 45.5) { pos.z = 45.5; this.velocity.z = 0; }
                if (pos.z < 20.0) { pos.z = 20.0; this.velocity.z = 0; }
            } else {
                if (pos.z < -45.5) { pos.z = -45.5; this.velocity.z = 0; }
                if (pos.z > -20.0) { pos.z = -20.0; this.velocity.z = 0; }
            }
        }

// Override throwBall to fix "weak throw" issue
// Override throwBall to fix "weak throw" issue and reduce loft
        throwBall(ball, forcedType = null, powerMultiplier = 1.0) {
            if (!this.hasBall || this.isThrowing) return;
            
            this.isThrowing = true;
            const type = forcedType || 'PA';
            const boost = 1.2;
            const finalPower = powerMultiplier * boost;

            // Animation
            const throwKey = (type === 'SH' && this.actions['throw_shot']) ? 'throw_shot' : 'throw_pass';
            this.playOneShot(throwKey, 0.1, { timeScale: 1.2 });

            if (window.flux.gameInstance.floatingText) {
                window.flux.gameInstance.floatingText.spawn("CLEAR!", this.mesh.position, "comic-action");
            }

            setTimeout(() => {
                if (this.hasBall || (ball && ball.holder === this)) {
                    // Calculate Direction
                    const finalDir = new THREE.Vector3(0, 0, 1).applyQuaternion(this.mesh.quaternion).normalize();
                    
                    // REDUCED LOFT: Goalie throws flatter (0.25 instead of 0.8)
                    finalDir.y += 0.25; 
                    finalDir.normalize();

                    // Calculate Stats
                    let statVal = this.getStat(type);
                    statVal *= finalPower;

                    ball.shoot(finalDir, statVal, type);
                    
                    // Extra grace period for Goalie
                    ball.catchGracePeriod = 0.6;

                    this.loseBall();
                    this.catchCooldown = 1.0;
                }
            }, 300); // Windup time

            setTimeout(() => {
                this.isThrowing = false;
                this._updateLocomotionAnim(0.2);
            }, 800);
        }

_defenseLogic(dt) {
            // 0. Game State Check
            if (window.flux.gameInstance.state !== 'active') return;

            const ball = window.flux.gameInstance.entities.ball;
            if (!ball || !ball.mesh) return;

            // --- PERCEPTION UPDATE ---
            // Smoothly interpolate perceived position towards real ball position
            // This creates a natural reaction delay and prevents jittery mirroring
            this.perceivedBallPos.lerp(ball.mesh.position, dt * this.reactionSpeed);

            // Determine Threat Source
            let threatPos = _ballPos;
            let isThreat = false;
            const myGoalZ = (this.team.side === 1) ? 46 : -46;

            // Case A: Ball is Held (Pre-throw)
            if (ball.state === 'held' && ball.holder && ball.holder.team !== this.team) {
                // Track holder, but use perceived position if we wanted to simulate reading the player
                // For now, tracking the ball (which is on the player) via perceivedPos is sufficient
                threatPos = this.perceivedBallPos;
                
                // Check if holder is in attacking half or near enough
                const distToGoal = Math.abs(threatPos.z - myGoalZ);
                if (distToGoal < 40.0) { // If they are within 40m, track them
                    isThreat = true;
                }
            } 
            // Case B: Ball is Free (Shot/Pass)
            else if (ball.state === 'free') {
                threatPos = this.perceivedBallPos;
                
                // Direction Check
                const movingTowards = (this.team.side === 1 && ball.velocity.z > 0) || 
                                      (this.team.side === -1 && ball.velocity.z < 0);
                
                // Position Check
                const inFrontOfGoal = (this.team.side === 1 && threatPos.z < 45.0) || 
                                      (this.team.side === -1 && threatPos.z > -45.0);

                isThreat = movingTowards && inFrontOfGoal;
            }
            if (isThreat) {
                // --- POSITIONING: ANGLE CUTTING ---
                _ballPos.copy(threatPos); // Update reference for lookAt
                
                // 1. Calculate Goal Center
// 1. Calculate Goal Center (Adjusted for Y offset)
_goalCenter.set(0, -4.5, myGoalZ);
                
                // 2. Vector from Goal to Ball
                _tempVecG.subVectors(_ballPos, _goalCenter);
                const distToBall = _tempVecG.length();
                _tempVecG.normalize(); // Now holds direction
                
                // 3. Determine Extension (How far out to step)
                // Base: 1.5m off line.
                // Max: 6.0m off line (Cutting angle).
                // Scale based on ball proximity: Closer ball = More extension (to a point)
let extension = 1.5;
                if (distToBall < 30.0) {
                    const ratio = 1.0 - (Math.max(0, distToBall - 5.0) / 25.0); 
                    extension = 1.5 + (4.5 * ratio); 
                }
                
// Safety: Don't go past the ball (keep 1m buffer)
                extension = Math.min(extension, distToBall - 1.0);
                
                // 4. Calculate Target Position (Base Interception)
                _gPos.copy(_goalCenter).add(_tempVecG.multiplyScalar(extension));
                
                // 5. Vertical Override (Jump to meet ball)
                // Explicitly set Y to match ball height if it's high
                if (_ballPos.y > 0.5) {
                    _gPos.y = _ballPos.y;
                } else {
                    _gPos.y = 0.5; // Default stance
                }

                // 6. Clamp to Goal Box Dimensions (Lateral/Vertical Limits)
                // Goal Width 22 (+/- 11), Height 18 (+/- 9).
                // Allow slightly outside posts to cover angles.
                const clampX = this.goalWidth * 0.6; // +/- 13.2
const clampY = 12.0; // Reduced max jump height
                
                _gPos.x = Math.max(-clampX, Math.min(clampX, _gPos.x));
                _gPos.y = Math.max(-clampY, Math.min(clampY, _gPos.y));
                
                // 6. Lead the ball slightly if it has lateral velocity (Anticipation)
if (ball.velocity.lengthSq() > 1.0) {
                    const anticipation = ball.velocity.clone().multiplyScalar(0.25); // 0.25s lead
                    anticipation.z = 0; // Only lateral lead
                    _gPos.add(anticipation);
                }

                // CLAMP Z: Prevent Goalie from going into the net or behind goal
// CLAMP Z: Prevent Goalie from going into the net or behind goal
// CLAMP Z: Prevent Goalie from going into the net or behind goal
if (this.team.side === 1) {
                    _gPos.z = Math.min(45.5, _gPos.z);
                } else {
                    _gPos.z = Math.max(-45.5, _gPos.z);
                }

                // Move towards target
                const moveDir = _gVec.subVectors(_gPos, this.mesh.position);
                const distToTarget = moveDir.length();
                
                if (distToTarget > 0.1) {
                    moveDir.normalize();
                    // Burst speed for saves if ball is close
                    const urgency = (distToBall < 10.0) ? 1.5 : 1.0;
                    const speed = this.maxSpeed * urgency;
                    
                    this.mesh.position.add(moveDir.multiplyScalar(speed * dt));
                    
                    // Face ball
                    this.mesh.lookAt(_ballPos);
                    
                    if (this.state !== 'swim') this.play('swim', 0.2);
                } else {
                    if (this.state !== 'idle') this.play('idle', 0.2);
                    this.mesh.lookAt(_ballPos);
                }

                // --- SAVE MECHANIC ---
                // If ball is within range, apply CA pressure
                const dist = this.mesh.position.distanceTo(ball.mesh.position);
                if (dist < this.saveRadius) { 
                    this._applySavePressure(ball, dt);
                }
            } else {
                // --- IDLE / RETURN TO POST ---
                // Return to home position (usually center of goal)
                _gPos.copy(this.homePosition);
                const moveDir = _gVec.subVectors(_gPos, this.mesh.position);
                
                if (moveDir.length() > 0.5) {
                    moveDir.normalize();
                    this.mesh.position.add(moveDir.multiplyScalar(this.maxSpeed * 0.6 * dt));
                    if (this.state !== 'swim') this.play('swim', 0.2);
                } else {
                    if (this.state !== 'idle') this.play('idle', 0.2);
                }
                
                // Face center field
                this.mesh.lookAt(0, 0, 0);
            }
        }

        _applySavePressure(ball, dt) {
            // If Goalie is Asleep, they cannot save.
            if (this.status.nap > 0) return;

            // --- SUPER GOALIE TRIGGER ---
            // Trigger if: Tech equipped, Not active, Ball has power, Ball is close
            if (this.techs.active === 'super_goalie' && !this.isSuperGoalie && ball.power > 5.0) {
                // Chance to trigger (High chance for AI, or check HP)
                // Cost: 10 HP
                if (this.stats.HP >= 10) {
                    this.stats.HP -= 10;
                    this.isSuperGoalie = true;
                    this.superGoalieTimer = 1.5; // Lasts 1.5s
                    
                    console.log(`${this.role} used SUPER GOALIE!`);
                    if (window.flux.gameInstance.floatingText) {
                        window.flux.gameInstance.floatingText.spawn("SUPER GOALIE!", this.mesh.position, "save");
                    }
                    
                    // Trigger Techcopy Event
                    if (window.flux.gameInstance && window.flux.gameInstance.triggerTechEvent) {
                        window.flux.gameInstance.triggerTechEvent(this, 'super_goalie');
                    }
                }
            }

            // Calculate Effective CA
            let ca = this.getStat('CA');
            
            // Apply Super Goalie Bonus (e.g. +50% + Flat 10)
            if (this.isSuperGoalie) {
                ca = (ca * 1.5) + 10;
            }
            
            // Apply Grip Gloves (Passive)
            if (this.techs.passive === 'grip_gloves') {
                ca += 5;
            }

            // Calculate Pressure
            // Pressure = CA * dt * Multiplier
            const pressure = ca * dt * this.pressureMultiplier;
            
            if (ball.power > 0) {
                ball.power -= pressure;
                
                // Visual Feedback
                this._accumulatedSave += pressure;
                // THROTTLE: Increased threshold to 12.0
                if (this._accumulatedSave >= 12.0) { 
                    if (window.flux.gameInstance.floatingText) {
                        window.flux.gameInstance.floatingText.spawn("BLOCK!", this.mesh.position, "comic-impact");
                    }
                    this._accumulatedSave = 0;
                }
            }

            // Apply Ball Technique to Goalie (Risk of catching special shots)
// Apply Ball Technique to Goalie (Risk of catching special shots)
            if (ball.technique && this.techImmunityTimer <= 0) {
                this.techImmunityTimer = 2.0;
                const tech = ball.technique;
                
                if (tech.type === 'venom') {
                    this.applyStatus('venom', 15.0);
                } else if (tech.type === 'nap') {
                    this.applyStatus('nap', 8.0);
                } else if (tech.type === 'wither') {
                    this.applyStatus('wither', 15.0, 'CA');
                }
            }

            // Check Result
            if (ball.power <= 0 && this.status.nap <= 0) {
                // CATCH
                this.catchBall(ball);
            }
        }

        catchBall(ball) {
            ball.grab(this);
            this.play('catch', 0.1);
            console.log("SAVED by " + this.role);
            
            // EXP REWARD: Save
            this.gainExp(5);

            if (window.flux.gameInstance.floatingText) {
                window.flux.gameInstance.floatingText.spawn("SAVED!", this.mesh.position, "comic-impact");
            }
            if (window.flux.gameInstance.triggerImpact) window.flux.gameInstance.triggerImpact(0.15, 'heavy');
            
            // Reset throw timer
            this.throwTimer = 0;
        }

_aiPossessionLogic(dt) {
            this.throwTimer += dt;
            
            // Hold for a moment (1.5s) then throw
            if (this.throwTimer > 1.5) {
                // Find best target: Prefer MF or Defenders, but must be somewhat distant to avoid "handoff" look
                // Filter for teammates > 8 units away if possible
                const validMates = this.team.players.filter(p => 
                    p !== this && 
                    p.mesh && 
                    p.mesh.position.distanceTo(this.mesh.position) > 8.0
                );

                let target = null;

                // Priority 1: Midfielder (Playmaker)
                target = validMates.find(p => p.role === 'MF');
                
                // Priority 2: Defenders
                if (!target) target = validMates.find(p => p.role === 'LD' || p.role === 'RD');
                
                // Priority 3: Anyone open (fallback to close range if no one is far)
                if (!target) target = this.team.players.find(p => p !== this && p.role !== 'GL');

                if (target && target.mesh) {
                    // AIMING LOGIC: Loft the pass
                    // Look at target, but aim slightly up to create an arc
                    const targetPos = target.mesh.position.clone();
                    
                    // Calculate distance
                    const dist = this.mesh.position.distanceTo(targetPos);
                    
                    // Loft factor: The further away, the higher we aim
                    // 20 units away -> Aim 5 units above head
                    const loft = Math.max(1.0, dist * 0.25);
                    targetPos.y += loft;

                    this.mesh.lookAt(targetPos);
                    
                    // Throw
                    const ball = window.flux.gameInstance.entities.ball;
                    this.throwBall(ball, 'PA'); 
                    console.log(`${this.role} throws to ${target.role} (Dist: ${dist.toFixed(1)})`);
                } else {
                    // Clear it forward
                    this.mesh.lookAt(0, 5, 0); // Aim up-center
                    const ball = window.flux.gameInstance.entities.ball;
                    this.throwBall(ball, 'SH'); // Hard clear
                }
                
                this.throwTimer = 0;
            }
        }
    }

    window.flux.Goalie = Goalie;
})();