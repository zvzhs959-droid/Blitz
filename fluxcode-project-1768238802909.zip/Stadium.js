(function() {
    window.flux = window.flux || {};

// Reusable Glow for Lights
    const _glowTexture = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
        g.addColorStop(0, 'rgba(255, 255, 255, 1)');
        g.addColorStop(0.4, 'rgba(0, 170, 255, 0.4)');
        g.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 64, 64);
        return new THREE.CanvasTexture(c);
    })();

    const _glowMaterial = new THREE.SpriteMaterial({ 
        map: _glowTexture, 
        transparent: true, 
        blending: THREE.AdditiveBlending,
        depthWrite: false
    });

    class Stadium {
        constructor(scene) {
            this.scene = scene;
            this.container = new THREE.Group();
            this.scene.add(this.container);

            // Config for "Herculean" scale
// Config for "Herculean" scale
            this.config = {
                radius: 60,       // Start outside the arena (48 radius)
                tiers: 6,         // Number of seating rings
                tierHeight: 12,
                tierDepth: 15,
                crowdCount: 8000, // Increased density
                structureColor: 0x080c10, // Deep dark blue/black
                lightColor: 0x00aaff
            };

this.rings = [];
            this.lightSprites = []; // Store light sprites for cinematic control
            this.crowd = null;
            this.crowd = null;

this._buildArchitecture();
            this._buildCrowd();
            this._buildHerculeanRings();
            this._buildStadiumLights();
        }

        _buildArchitecture() {
            // 1. The Void Bowl (Background Occluder)
            // Massive cylinder to block the void
            const bowlGeo = new THREE.CylinderGeometry(180, 50, 120, 32, 1, true);
            const bowlMat = new THREE.MeshBasicMaterial({ 
                color: this.config.structureColor, 
                side: THREE.BackSide,
                fog: true 
            });
            const bowl = new THREE.Mesh(bowlGeo, bowlMat);
            bowl.position.y = 20;
            this.container.add(bowl);

            // 2. Seating Tiers (Concentric Rings)
            const tierMat = new THREE.MeshBasicMaterial({ color: 0x111a22, side: THREE.DoubleSide });
            const rimMat = new THREE.MeshBasicMaterial({ color: 0x004466 });

            for(let i=0; i<this.config.tiers; i++) {
                const y = (i * this.config.tierHeight) - 30;
                const rInner = this.config.radius + (i * (this.config.tierDepth * 0.8));
                const rOuter = rInner + this.config.tierDepth;
                
                // Floor Ring
                const ringGeo = new THREE.RingGeometry(rInner, rOuter, 64);
                ringGeo.rotateX(-Math.PI / 2);
                const mesh = new THREE.Mesh(ringGeo, tierMat);
                mesh.position.y = y;
                this.container.add(mesh);
                
                // Glowing Rim (The "Tech" feel)
                const rimGeo = new THREE.TorusGeometry(rInner, 0.8, 4, 64);
                rimGeo.rotateX(Math.PI / 2);
                const rim = new THREE.Mesh(rimGeo, rimMat);
                rim.position.y = y;
                this.container.add(rim);
            }

            // 3. Massive Pillars (The "Herculean" Support)
            const pillarGeo = new THREE.BoxGeometry(8, 200, 8);
            const pillarMat = new THREE.MeshBasicMaterial({ color: 0x050505 });
            
            for(let i=0; i<8; i++) {
                const angle = (i / 8) * Math.PI * 2;
                const r = 140; // Far out
                const mesh = new THREE.Mesh(pillarGeo, pillarMat);
                mesh.position.set(Math.cos(angle)*r, 0, Math.sin(angle)*r);
                mesh.lookAt(0,0,0);
                this.container.add(mesh);
            }
        }

_buildCrowd() {
            // Instanced Mesh for Crowd (Low Poly, High Count)
            // Using a simple vertical plane that faces center
            const geo = new THREE.PlaneGeometry(1.2, 2.5);
            
            // --- CROWD SHADER IMPLEMENTATION ---
            // Add instance-specific random offset for animation variation
            const offsets = new Float32Array(this.config.crowdCount);
            for(let i=0; i<this.config.crowdCount; i++) {
                offsets[i] = Math.random();
            }
            geo.setAttribute('aOffset', new THREE.InstancedBufferAttribute(offsets, 1));

            // Custom Shader via onBeforeCompile
            const mat = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide });
            
            mat.onBeforeCompile = (shader) => {
                shader.uniforms.uTime = { value: 0 };
                this.crowdUniforms = shader.uniforms;

                shader.vertexShader = `
                    uniform float uTime;
                    attribute float aOffset;
                    varying float vJump; // Pass to fragment for color variation
                ` + shader.vertexShader;

                shader.vertexShader = shader.vertexShader.replace(
                    '#include <begin_vertex>',
                    `
                    #include <begin_vertex>
                    
                    // Animation Logic
                    float speed = 8.0;
                    float t = uTime * speed + (aOffset * 100.0);
                    
                    // Jump (Sine wave clipped)
                    float jump = max(0.0, sin(t));
                    jump = pow(jump, 2.0); // Sharpen the jump curve
                    
                    // Randomize jump height slightly
                    float height = 0.5 + 0.5 * aOffset;
                    
                    transformed.y += jump * height;
                    
                    // Sway (Side to side)
                    transformed.x += cos(t * 0.5) * 0.1;
                    
                    vJump = jump;
                    `
                );

                shader.fragmentShader = `
                    varying float vJump;
                ` + shader.fragmentShader;

                shader.fragmentShader = shader.fragmentShader.replace(
                    'vec4 diffuseColor = vec4( diffuse, opacity );',
                    `
                    vec4 diffuseColor = vec4( diffuse, opacity );
                    
                    // Brighten when jumping (Cheering effect)
                    diffuseColor.rgb += vec3(0.2) * vJump;
                    `
                );
            };
            
this.crowd = new THREE.InstancedMesh(geo, mat, this.config.crowdCount);
            this.crowd.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
            
            // Optimization: Enable culling and manually set bounding sphere to cover the whole stadium
            // This prevents GPU from processing 2500 instances when the entire structure is out of view
            this.crowd.frustumCulled = true;
            this.crowd.geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, 0), 150);
            
            const dummy = new THREE.Object3D();
            const color = new THREE.Color();
            
// 1. Calculate Total Circumference for distribution to ensure all tiers get people
            let totalCirc = 0;
            const tierRadii = [];
            for(let t=0; t<this.config.tiers; t++) {
                const rMin = this.config.radius + (t * (this.config.tierDepth * 0.8)) + 2;
                const circ = 2 * Math.PI * rMin;
                totalCirc += circ;
                tierRadii.push({ rMin: rMin, circ: circ });
            }

            let idx = 0;
            for(let t=0; t<this.config.tiers; t++) {
                const yBase = (t * this.config.tierHeight) - 30;
                const { rMin, circ } = tierRadii[t];
                const rMax = rMin + this.config.tierDepth - 2;
                
                // Distribute proportionally so upper rows don't get cut off
                const countPerTier = Math.floor(this.config.crowdCount * (circ / totalCirc));
                
                for(let i=0; i<countPerTier; i++) {
                    if (idx >= this.config.crowdCount) break;

                    const angle = Math.random() * Math.PI * 2;
                    const r = rMin + Math.random() * (rMax - rMin);
                    
                    dummy.position.set(
                        Math.cos(angle) * r,
                        yBase + 1.25, // Center of quad
                        Math.sin(angle) * r
                    );
                    
                    // Face center
                    dummy.lookAt(0, yBase, 0);
                    dummy.updateMatrix();
                    
                    this.crowd.setMatrixAt(idx, dummy.matrix);
                    
                    // Random Team Colors (Simulating fans)
                    const rand = Math.random();
                    if (rand < 0.45) color.setHex(0x0088ff); // Home Blue
                    else if (rand < 0.9) color.setHex(0xff4444); // Away Red
                    else color.setHex(0xffffff); // Neutral/Flash
                    
                    // Vary brightness for depth
                    color.multiplyScalar(0.5 + Math.random() * 0.5);
                    
                    this.crowd.setColorAt(idx, color);
                    idx++;
                }
            }
            
            this.container.add(this.crowd);
        }

        _buildHerculeanRings() {
            // Massive floating rings that rotate slowly
            const mat = new THREE.MeshBasicMaterial({ 
                color: 0x445566, 
                transparent: true, 
                opacity: 0.3,
                wireframe: true // Tech/Holographic feel
            });

            // 1. Equatorial Ring (Massive)
            const geo1 = new THREE.TorusGeometry(110, 1, 16, 100);
            const ring1 = new THREE.Mesh(geo1, mat);
            ring1.rotation.x = Math.PI / 2;
            this.container.add(ring1);
            this.rings.push({ mesh: ring1, axis: 'z', speed: 0.01 });

            // 2. Tilted Ring
            const geo2 = new THREE.TorusGeometry(130, 2, 16, 100);
            const ring2 = new THREE.Mesh(geo2, mat);
            ring2.rotation.x = Math.PI / 3;
            this.container.add(ring2);
            this.rings.push({ mesh: ring2, axis: 'y', speed: -0.008 });
            
            // 3. Vertical Ring
            const geo3 = new THREE.TorusGeometry(150, 3, 16, 100);
const ring3 = new THREE.Mesh(geo3, mat);
            this.container.add(ring3);
            this.rings.push({ mesh: ring3, axis: 'y', speed: 0.005 });
        }

        _buildStadiumLights() {
            const count = 16; // Number of lights around the equator
            const radius = 36; // Just outside the arena boundary (32)
            const yPos = 0; // Middle of the sphere
            
            const lightGeo = new THREE.SphereGeometry(0.4, 8, 8);
            const lightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

            for(let i=0; i<count; i++) {
                const angle = (i / count) * Math.PI * 2;
                const x = Math.cos(angle) * radius;
                const z = Math.sin(angle) * radius;

                // 1. Physical Fixture (The bulb)
                const mesh = new THREE.Mesh(lightGeo, lightMat);
                mesh.position.set(x, yPos, z);
                this.container.add(mesh);

                // 2. Visual Glow (Flare)
                const sprite = new THREE.Sprite(_glowMaterial);
// 2. Visual Glow (Flare)

                sprite.position.set(x, yPos, z);
                sprite.scale.set(8, 8, 1); // Large glow
                this.container.add(sprite);
                this.lightSprites.push(sprite);

// 3. Actual Point Light - REMOVED for optimization
                // Since we use MeshBasicMaterial (Unlit), real lights waste CPU/GPU resources.
                // The sprite glow above provides the visual effect.
            }
        }
update(dt) {
            // Animate Rings
            this.rings.forEach(r => {
                if (r.mesh && r.axis) {
                    r.mesh.rotation[r.axis] += r.speed * dt;
                }
            });

            // Update Crowd Shader
            if (this.crowdUniforms) {
                this.crowdUniforms.uTime.value += dt;
            }

            // Update Light Pops (Cinematic)
            this.lightSprites.forEach(s => {
                if (s.visible && s.scale.x > 8.0) {
                    // Decay pop effect
                    s.scale.x -= dt * 30.0;
                    s.scale.y -= dt * 30.0;
                    if (s.scale.x < 8.0) s.scale.set(8, 8, 1);
                }
            });
        }

        setAllLights(visible) {
            this.lightSprites.forEach(s => {
                s.visible = visible;
                s.scale.set(8, 8, 1); // Reset scale
            });
        }

        turnOnLight(index) {
            if (this.lightSprites[index]) {
                const s = this.lightSprites[index];
                s.visible = true;
                s.material.opacity = 1.0;
                s.scale.set(20, 20, 1); // Pop effect
            }
        }
    }

    window.flux.Stadium = Stadium;
})();