(function() {
    window.flux = window.flux || {};

    // Reusable math vectors to avoid GC
const _bVec = new THREE.Vector3();
    const _bDir = new THREE.Vector3();
    const _axisY = new THREE.Vector3(0, 1, 0);
    const _tempVec = new THREE.Vector3();
    const _magnusVec = new THREE.Vector3();

// Physics Configuration (Exposed for DevTools)
window.flux.BallConfig = {
        // -----------------------------------------------------------------
        // Core integration
        // -----------------------------------------------------------------
        SUBSTEPS: 2,                // Physics substeps per frame (stability at high speeds)
        STOP_SPEED: 0.02,           // Below this speed, snap to rest (prevents endless drift)

        // -----------------------------------------------------------------
        // Water resistance (physical velocity drag, NOT stat decay)
        // -----------------------------------------------------------------
        WATER_DRAG_LINEAR: 0.15,    // Linear drag term (roughly your previous WATER_DRAG)
        WATER_DRAG_QUAD: 0.002,     // Quadratic drag (stronger at high speed, helps tame rockets)

        // -----------------------------------------------------------------
        // Spin & curve
        // -----------------------------------------------------------------
        SPIN_DRAG: 0.40,            // Spin decay per second
        MAGNUS_ENABLED: true,
        MAGNUS_COEFF: 0.08,         // Lift strength
        MAGNUS_CAP: 60.0,           // Max magnus delta-V per substep (prevents explosions)

        // -----------------------------------------------------------------
        // Depth constraint (keeps ball near play plane without feeling like a hard floor)
        // -----------------------------------------------------------------
        DEPTH_TARGET_Y: 0.0,
        DEPTH_SPRING: 1.0,          // Your previous GRAVITY_SPRING
        DEPTH_DAMP: 1.5,            // Your previous GRAVITY_DAMP

        // -----------------------------------------------------------------
        // Arena boundary (soft wall + clamp)
        // -----------------------------------------------------------------
BOUNDARY_RADIUS: 46.0,
        BOUNDARY_HEIGHT: 20.0,
        GOAL_POCKET_ENABLED: true,
        GOAL_POCKET_X: 12.0,        // Half-width of goal pocket corridor
        GOAL_POCKET_Z: 40.0,        // Start of goal pocket corridor (abs z) - Pushed back
        GOAL_POCKET_RADIUS: 55.0,   // Effective radius when in goal pocket
        WALL_SOFT_BUFFER: 3.0,      // Distance from wall where soft repulsion begins
        WALL_SOFT_FORCE: 20.0,      // Soft repulsion strength
        WALL_ELASTICITY: 0.30,      // Bounce dampening on clamp
        WALL_FRICTION: 0.95,        // Tangential damping on wall contact

        FLOOR_ELASTICITY: 0.40,     // Bounce dampening on ceiling/floor clamp

        // -----------------------------------------------------------------
        // Throw mapping (stat force -> physical launch speed)
        // -----------------------------------------------------------------
        LAUNCH_SPEED_SCALE: 1.0,    // Multiplies force when converting to velocity
        LAUNCH_SPEED_CAP: 85.0      // Physical speed cap (was hardcoded in Ball.shoot)
    };


    
    const C = window.flux.BallConfig; // Local alias for brevity
    // --- TRAIL RENDERER ---
// --- TRAIL RENDERER ---
    class TrailRenderer {
        constructor(scene) {
            this.scene = scene;
            this.segments = 30; // More segments for smoother curves
            this.points = [];
this.baseWidth = 0.8; // Increased width for visibility
            this.currentWidth = 0.8;
            
            // Geometry
            const geometry = new THREE.BufferGeometry();
            const posData = new Float32Array(this.segments * 2 * 3);
            geometry.setAttribute('position', new THREE.BufferAttribute(posData, 3));
            
            // Indices
            const indices = [];
            for (let i=0; i<this.segments-1; i++) {
                const base = i*2;
                indices.push(base, base+1, base+2);
                indices.push(base+1, base+3, base+2);
            }
            geometry.setIndex(indices);
            
            this.material = new THREE.MeshBasicMaterial({
                color: 0x00aaff,
                side: THREE.DoubleSide,
                transparent: true,
                opacity: 0.9, // Increased opacity
                blending: THREE.AdditiveBlending,
                depthWrite: false
            });
            
            this.mesh = new THREE.Mesh(geometry, this.material);
            this.mesh.frustumCulled = false;
            this.scene.add(this.mesh);
            
            // Init points
            for(let i=0; i<this.segments; i++) this.points.push(new THREE.Vector3());
            this.active = false;

            // Reusable temps (avoid per-frame allocations on mobile)
            this._tmpDir = new THREE.Vector3();
            this._tmpToCam = new THREE.Vector3();
            this._tmpRight = new THREE.Vector3();
        }
        
        reset(pos) {
            for(let i=0; i<this.segments; i++) this.points[i].copy(pos);
            this.updateGeometry();
        }
        
        setColor(hex) {
            this.material.color.setHex(hex);
        }
        
        update(currentPos, speedRatio = 0.0) {
            if (!this.active) {
                this.reset(currentPos);
                return;
            }

// Dynamic Width based on speed AND SPIN (Power Visual)
            // Fast ball = Thicker. Spinning ball = Even Thicker.
            const ball = window.flux.gameInstance ? window.flux.gameInstance.entities.ball : null;
            const spinRatio = ball ? Math.min(1.0, ball.angularVelocity.length() / 30.0) : 0;
            
            const targetWidth = this.baseWidth * (0.8 + speedRatio * 1.2 + spinRatio * 2.0);
            this.currentWidth += (targetWidth - this.currentWidth) * 0.2; // Smooth transition

            // Shift points
            for (let i = this.segments - 1; i > 0; i--) {
                this.points[i].copy(this.points[i-1]);
            }
            this.points[0].copy(currentPos);
            
            this.updateGeometry();
        }
        
        updateGeometry() {
            const positions = this.mesh.geometry.attributes.position.array;
            const cam = window.flux.gameInstance ? window.flux.gameInstance.camera : null;
            if (!cam) return;
            const camPos = cam.position;
            const tempDir = this._tmpDir;
            const tempToCam = this._tmpToCam;
            const tempRight = this._tmpRight;
            for (let i=0; i<this.segments; i++) {
                const p = this.points[i];
                
                // Taper width along trail length
                const taper = 1.0 - Math.pow(i / this.segments, 2); // Quadratic taper
                const w = this.currentWidth * taper;
                
                // Calculate direction
                if (i < this.segments - 1) {
                    tempDir.subVectors(this.points[i], this.points[i+1]);
                } else {
                    tempDir.subVectors(this.points[i-1], this.points[i]);
                }
                
                if (tempDir.lengthSq() < 0.0001) tempDir.set(0, 1, 0);
                tempDir.normalize();
                
                tempToCam.subVectors(camPos, p).normalize();
                tempRight.crossVectors(tempDir, tempToCam).normalize().multiplyScalar(w);
                
                // Vert 1
                positions[i*6 + 0] = p.x - tempRight.x;
                positions[i*6 + 1] = p.y - tempRight.y;
                positions[i*6 + 2] = p.z - tempRight.z;
                
                // Vert 2
                positions[i*6 + 3] = p.x + tempRight.x;
                positions[i*6 + 4] = p.y + tempRight.y;
                positions[i*6 + 5] = p.z + tempRight.z;
            }
            this.mesh.geometry.attributes.position.needsUpdate = true;
        }
    }
class Ball {

        constructor(scene) {
            this.scene = scene;
            this.mesh = null;
            this.holder = null; 
            this.lastHolder = null; // Track who threw it last (for EXP/Assists)
            
            this.velocity = new THREE.Vector3(0, 0, 0);
            this.angularVelocity = new THREE.Vector3(0, 0, 0);
            this.state = 'free'; // 'free', 'held', 'magnetized'
            this.isInvisible = false;

            // Continuous Stats
            this.power = 0;      // Current PA or SH value
            this.powerType = 'none'; // 'PA' or 'SH'
            this.decayRate = 3.0; // Stat points lost per second (Water resistance)
            this.catchGracePeriod = 0; // Time before ball can be caught again

            // Magnet System
            this.magnetTarget = null;
            this.magnetTimer = 0;
            this.magnetDuration = 0.2; 
            this.magnetStartPos = new THREE.Vector3();
            this.magnetStartVel = new THREE.Vector3();

            // Visuals (Squash & Stretch)
            this.accumulatedRotation = new THREE.Quaternion();
            this.deformNode = null;
            this.spinNode = null;
            this.model = null;

this.initMesh();
            this.trail = new TrailRenderer(scene);
            this._bubbleTimer = 0;
}
initMesh() {
            // Hierarchy: Mesh (Pos) -> Deform (Squash/Stretch) -> Spin (Rotation) -> Model
            this.mesh = new THREE.Group();
            this.scene.add(this.mesh);

this.deformNode = new THREE.Group();
            this.deformNode.position.y = 0.0; // Reset offset so ball is centered on mesh position
            this.mesh.add(this.deformNode); // Fix: Add deformNode to mesh

            this.spinNode = new THREE.Group();
            this.deformNode.add(this.spinNode);

            // Procedural Placeholder Texture (Blitzball-ish)
            const placeholderTex = (() => {
                const c = document.createElement('canvas');
                c.width = 128; c.height = 64;
                const ctx = c.getContext('2d');
                ctx.fillStyle = '#eeeeee';
                ctx.fillRect(0,0,128,64);
                
                // Blue bumps/details
                ctx.fillStyle = '#0088ff';
                for(let i=0; i<6; i++) {
                    ctx.beginPath();
                    ctx.arc(i*25, 32, 10, 0, Math.PI*2);
                    ctx.fill();
                }
                ctx.fillStyle = '#004488';
                ctx.fillRect(0, 28, 128, 8); // Stripe
                
                return new THREE.CanvasTexture(c);
            })();

            // Placeholder Visual (Immediate feedback, persists until valid model loads)
// Placeholder Visual (Immediate feedback, persists until valid model loads)
// Placeholder Visual (Immediate feedback, persists until valid model loads)
const geometry = new THREE.SphereGeometry(0.3, 16, 16); // Scaled down ~15%
            const material = new THREE.MeshBasicMaterial({
                map: placeholderTex,
                color: 0xffffff, 
                wireframe: false, // Solid
                transparent: false,
                opacity: 1.0
            });
            this.placeholder = new THREE.Mesh(geometry, material);

            // Load GLB Model
            const url = 'https://cdn.tinyglb.com/models/521ae8788e584e378a79d9732a075356.glb';
            
            window.flux.AssetLoader.loadModel(url, (gltf) => {
                console.log("DEBUG: Ball GLB loaded.", gltf);
                
                const model = gltf.scene;

                // 1. Reset root transforms
                model.position.set(0, 0, 0);
                model.rotation.set(0, 0, 0);
                model.scale.set(1, 1, 1);
                model.updateMatrixWorld(true);

                // 2. Harden Materials & Visibility
                model.traverse((node) => {
                    if (node.isMesh) {
                        node.castShadow = false;
                        node.receiveShadow = false;
                        node.frustumCulled = false; // CRITICAL: Prevent culling if bounds are off
                        
                        if (node.material) {
                            const mats = Array.isArray(node.material) ? node.material : [node.material];
                            mats.forEach(m => {
                                m.color.setHex(0xffffff); // Force white base
                                m.side = THREE.DoubleSide;
                                m.transparent = false;
                                m.opacity = 1.0;
                                m.alphaTest = 0; // CRITICAL: Disable alpha test to prevent culling
                                m.depthWrite = true;
                                m.depthTest = true;
                            });
                        }
                    }
                });

                // 3. Compute Bounding Box
                const box = new THREE.Box3().setFromObject(model);
                const size = new THREE.Vector3();
                box.getSize(size);
                const center = new THREE.Vector3();
                box.getCenter(center);

                // 4. Validation
                const maxDim = Math.max(size.x, size.y, size.z);
                if (maxDim <= 0.001 || !isFinite(maxDim)) {
                    console.warn("Ball model has invalid dimensions. Keeping placeholder.");
                    return; 
                }

                // 5. Calculate Scale
// 5. Calculate Scale
const targetDiameter = 0.72; // Reduced scale by ~15% (was 0.85)
                const scaleFactor = targetDiameter / maxDim;

                // 6. Apply Transforms
                model.scale.setScalar(scaleFactor);
                model.position.copy(center).multiplyScalar(-scaleFactor);

                // 7. Swap Placeholder
                if (this.placeholder) {
                    this.spinNode.remove(this.placeholder);
                    if (this.placeholder.geometry) this.placeholder.geometry.dispose();
                    this.placeholder = null;
                }

                this.model = model;
                this.spinNode.add(this.model);
                console.log(`Blitzball model attached. Scale: ${scaleFactor.toFixed(4)}`);

            }, undefined, (err) => {
                console.error("Failed to load Blitzball model:", err);
                // Fallback: Keep placeholder but tint it red to indicate error
                if (this.placeholder) {
                    this.placeholder.material.color.setHex(0xffaaaa);
                }
            });
        }

update(dt) {
            if (!this.mesh) return;

            // Ball Lab replay override (lets DevTools drive the ball deterministically)
            const __lab = window.flux && window.flux.ballLab;
            if (__lab && __lab.isReplaying && __lab.targetBall === this && typeof __lab.applyReplayFrame === 'function') {
                __lab.applyReplayFrame(this, dt);
                if (this.trail) this.trail.active = false;
                this.updateVisuals(dt);
                return;
            }

            // Safety: Reset if position corrupted
            if (isNaN(this.mesh.position.x) || isNaN(this.mesh.position.y) || isNaN(this.mesh.position.z)) {
                this.reset();
                return;
            }

// Safety: Fix "Unpickable Ball" Bug
            // 1. Invalid Actor Check
            if (this.state === 'held' && (!this.holder || !this.holder.mesh)) {
                this.drop();
            }
            if (this.state === 'magnetized') {
                if (!this.magnetTarget || !this.magnetTarget.mesh) {
                    this.drop();
                }
                // 2. Magnetize Timeout (Prevent getting stuck in mid-air)
                if (this.magnetTimer > 2.0) {
                    console.warn("Ball stuck in magnetized state. Dropping.");
                    this.drop();
                }
            }

            // 3. State Consistency
            if (this.state === 'free' && this.holder !== null) {
                this.holder = null;
            }

            // Failsafe: If ball is free and slow, ensure it's catchable immediately
            if (this.state === 'free' && this.velocity.lengthSq() < 0.5) {
                this.catchGracePeriod = 0;
            }
if (this.trail) {
                // Trail is active if ball is moving fast and free
                const speed = this.velocity.length();
                this.trail.active = (this.state === 'free' && speed > 2.0);
                
                // Fix: Offset trail to match visual model position (deformNode offset)
                _bVec.copy(this.mesh.position);
                if (this.deformNode) _bVec.y += this.deformNode.position.y;

                // Pass speed ratio (0 to 1 based on max speed approx 60)
                const ratio = Math.min(speed / 60.0, 1.0);
                this.trail.update(_bVec, ratio);
            }

            if (this.state === 'held' && this.holder && this.holder.mesh) {
                this.updateHeld(dt);
            } else if (this.state === 'magnetized') {
                this.updateMagnetized(dt);
            } else {
                this.updateFree(dt);
            }
            
if (this.catchGracePeriod > 0) {
                this.catchGracePeriod -= dt;
                if (this.catchGracePeriod < 0) this.catchGracePeriod = 0;
            }

this.updateVisuals(dt);
            
            // Safety: Ensure visibility if not explicitly invisible
// Safety: Ensure visibility if not explicitly invisible
            if (this.mesh && !this.isInvisible) {
                this.mesh.visible = true;
                // Force model visibility if present (sometimes GLTF loader hides it)
                if (this.model) this.model.visible = true;
            }
        }

magnetize(target) {
            if (this.state === 'magnetized' || this.state === 'held') return;
            
            this.state = 'magnetized';
            this.magnetTarget = target;
            this.holder = target; // Logical possession so AI reacts
            this.magnetTimer = 0;
            this.magnetStartPos.copy(this.mesh.position);
            this.magnetStartVel.copy(this.velocity);
            
            // Dynamic Duration based on distance (Smoother for long range, snappy for close)
            const dist = this.mesh.position.distanceTo(target.mesh.position);
            this.magnetDuration = Math.max(0.15, Math.min(0.4, dist / 15.0));
            
            // Kill physics
            this.velocity.set(0, 0, 0);
            this.angularVelocity.set(0, 0, 0);

            // Notify player immediately so they stop chasing and play animation
            if (target.receiveBall) {
                target.receiveBall();
            }

            this.reveal();
        }

updateMagnetized(dt) {
            if (!this.magnetTarget || !this.magnetTarget.mesh) {
                this.drop();
                return;
            }

            this.magnetTimer += dt;
            
            // Normalized Time
            let t = this.magnetTimer / this.magnetDuration;
            if (t > 1.0) t = 1.0;

            // Target "Virtual Hand" Position (Front of Chest)
            const holderPos = this.magnetTarget.mesh.position;
            const holderQuat = this.magnetTarget.mesh.quaternion;
            
            // Offset: Forward 0.6, Up 1.0 (Chest height)
            const offset = _bVec.set(0, 1.0, 0.6).applyQuaternion(holderQuat);
            const targetPos = offset.add(holderPos);

            // --- QUADRATIC BEZIER CURVE ---
            // P0 = Start, P2 = Target
            // P1 = Control Point (Projected along initial velocity to preserve momentum feel)
            
            const p0 = this.magnetStartPos;
            const p2 = targetPos;
            
            // Calculate P1 (Control Point)
            // Project forward from P0 along start velocity vector
            // Distance of projection = 40% of total distance to target
            const dist = p0.distanceTo(p2);
            const p1 = _tempVec.copy(p0);
            
            const velLen = this.magnetStartVel.lengthSq();
            if (velLen > 1.0) {
                // Use velocity tangent
// Use velocity tangent
                _bDir.copy(this.magnetStartVel).normalize();
                p1.add(_bDir.multiplyScalar(dist * 0.4));
            } else {
                // No velocity (stationary ball), arc upwards slightly
                p1.lerp(p2, 0.5);
                p1.y += 1.5; 
            }

            // Bezier: B(t) = (1-t)^2 * P0 + 2(1-t)t * P1 + t^2 * P2
            const oneMinusT = 1.0 - t;
            const w0 = oneMinusT * oneMinusT;
            const w1 = 2.0 * oneMinusT * t;
            const w2 = t * t;
            
            this.mesh.position.x = (w0 * p0.x) + (w1 * p1.x) + (w2 * p2.x);
            this.mesh.position.y = (w0 * p0.y) + (w1 * p1.y) + (w2 * p2.y);
            this.mesh.position.z = (w0 * p0.z) + (w1 * p1.z) + (w2 * p2.z);

            // Finish
            if (t >= 1.0) {
                this.grab(this.magnetTarget);
            }
        }

updateHeld(dt) {
            // ATTACHED STATE (Virtual Attachment)
            if (!this.holder || !this.holder.mesh) {
                this.drop();
                return;
            }

            this.velocity.set(0, 0, 0);
            this.angularVelocity.set(0, 0, 0);

            // 1. Try to use Hand Bone if available (Realism)
            if (this.holder.handBone) {
                // Get world position of the hand bone
                this.holder.handBone.getWorldPosition(this.mesh.position);
                
                // Adjust slightly to sit IN the hand rather than ON the wrist
                // We can't easily know "forward" for the bone without more info, 
                // but usually GLTF bones are oriented. For now, exact bone pos is better than chest.
            } else {
                // 2. Fallback: Calculate "Carrying" Position (Right Hand Side)
                // Relative to player: Up 0.8 (Waist/Chest), Right 0.4, Forward 0.5
                const holderPos = this.holder.mesh.position;
                const holderQuat = this.holder.mesh.quaternion;
                
                // Reuse _bVec
// Reuse _bVec
                // Offset: x=0.35 (Right), y=1.3 (Chest/Hands), z=0.5 (Forward)
                _bVec.set(0.35, 1.3, 0.5).applyQuaternion(holderQuat);
                this.mesh.position.copy(holderPos).add(_bVec);
            }

// Visual Flair: Spin the ball slowly
            const rotX = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0), 2 * dt);
            const rotY = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0), 5 * dt);
            this.accumulatedRotation.multiply(rotX).multiply(rotY);
        }


updateFree(dt) {
    const C = window.flux.BallConfig || {};
    const substeps = Math.max(1, Math.floor(C.SUBSTEPS || 1));
    const stepDt = dt / substeps;

    // --- 1) Integrate physics in substeps for stability ---
    for (let s = 0; s < substeps; s++) {
        // A) Magnus effect (curve from spin)
        if (C.MAGNUS_ENABLED && this.angularVelocity && this.velocity) {
            const spinSq = this.angularVelocity.lengthSq();
            const velSq = this.velocity.lengthSq();
            if (spinSq > 0.25 && velSq > 0.25) {
                _magnusVec.copy(this.angularVelocity).cross(this.velocity).multiplyScalar((C.MAGNUS_COEFF || 0) * stepDt);

                // Cap to avoid numeric blowups
                const cap = (C.MAGNUS_CAP !== undefined ? C.MAGNUS_CAP : 60.0);
                const magLen = _magnusVec.length();
                if (magLen > cap) _magnusVec.multiplyScalar(cap / magLen);

                this.velocity.add(_magnusVec);
            }
        }

        // B) Spin decay
        if (this.angularVelocity) {
            const spinDrag = Math.max(0, 1.0 - (C.SPIN_DRAG || 0) * stepDt);
            this.angularVelocity.multiplyScalar(spinDrag);
        }

        // C) Depth spring (keeps ball near plane)
        const targetY = (C.DEPTH_TARGET_Y !== undefined ? C.DEPTH_TARGET_Y : 0.0);
        const yErr = (this.mesh.position.y - targetY);
        this.velocity.y -= yErr * (C.DEPTH_SPRING || 0) * stepDt;
        this.velocity.y *= Math.max(0, 1.0 - (C.DEPTH_DAMP || 0) * stepDt);

        // D) Apply drag (linear + quadratic)
        const vLen = this.velocity.length();
        if (vLen > 0.00001) {
            const lin = (C.WATER_DRAG_LINEAR !== undefined ? C.WATER_DRAG_LINEAR : (C.WATER_DRAG || 0)) * stepDt;
            const quad = (C.WATER_DRAG_QUAD || 0) * vLen * stepDt;
            const drag = Math.max(0, 1.0 - lin - quad);
            this.velocity.multiplyScalar(drag);

            const stop = (C.STOP_SPEED || 0);
            if (stop > 0 && this.velocity.lengthSq() < stop * stop) {
                this.velocity.set(0, 0, 0);
            }
        }

        // E) Move
        _tempVec.copy(this.velocity).multiplyScalar(stepDt);
        this.mesh.position.add(_tempVec);

        // F) Stat power decay (game logic)
        if (this.power > 0) {
            this.power -= this.decayRate * stepDt;
            if (this.power < 0) this.power = 0;
        }

        // G) Boundary logic (soft wall + clamp)
        const pos = this.mesh.position;
        const distXZ = Math.sqrt(pos.x * pos.x + pos.z * pos.z);

        const boundaryRadius = (C.BOUNDARY_RADIUS !== undefined ? C.BOUNDARY_RADIUS : 33.0);
        let effectiveBoundary = boundaryRadius;

        if (C.GOAL_POCKET_ENABLED) {
            const inGoalPocket = (Math.abs(pos.x) < (C.GOAL_POCKET_X || 12.0) && Math.abs(pos.z) > (C.GOAL_POCKET_Z || 25.0));
            if (inGoalPocket) effectiveBoundary = (C.GOAL_POCKET_RADIUS || 45.0);
        }

        const softBuffer = Math.max(0.01, (C.WALL_SOFT_BUFFER !== undefined ? C.WALL_SOFT_BUFFER : 3.0));

        // Soft repulsion (curves trajectory near wall instead of ping-pong)
        if (distXZ > effectiveBoundary - softBuffer) {
            const penetration = distXZ - (effectiveBoundary - softBuffer);
            const ratio = Math.max(0, Math.min(1, penetration / softBuffer));

            _tempVec.set(-pos.x, 0, -pos.z);
            if (_tempVec.lengthSq() > 0.0001) {
                _tempVec.normalize();
                const force = ratio * ratio * (C.WALL_SOFT_FORCE || 0) * stepDt;
                this.velocity.addScaledVector(_tempVec, force);
            }
        }

        // Hard clamp if it still hits
        if (distXZ > effectiveBoundary) {
            _tempVec.set(-pos.x, 0, -pos.z);
            if (_tempVec.lengthSq() > 0.0001) _tempVec.normalize();

            const overlap = distXZ - effectiveBoundary;
            pos.addScaledVector(_tempVec, overlap);

const vDotN = this.velocity.dot(_tempVec);

            // Only adjust if moving outward (against inward normal)
            if (vDotN < 0) {
                // Trigger Arena Deformation if impact is forceful
                const impactSpeed = Math.abs(vDotN);
                if (impactSpeed > 10.0 && window.flux.triggerArenaImpact) {
                    // Pass the contact point (pos) and strength based on speed
                    window.flux.triggerArenaImpact(pos, Math.min(impactSpeed * 0.5, 15.0));
                }

                const e = (C.WALL_ELASTICITY !== undefined ? C.WALL_ELASTICITY : 0.3);
                const impulse = _tempVec.clone().multiplyScalar(-vDotN * (1.0 + e));
                this.velocity.add(impulse);
                
                // Tangential friction
                const friction = (C.WALL_FRICTION !== undefined ? C.WALL_FRICTION : 0.95);
                const tangent = this.velocity.clone().projectOnPlane(_tempVec);
                this.velocity.sub(tangent.multiplyScalar(1.0 - friction));
            }
        }

        // Ceiling/Floor clamp
        const bh = (C.BOUNDARY_HEIGHT !== undefined ? C.BOUNDARY_HEIGHT : 15.0);
        if (Math.abs(pos.y) > bh) {
            const sign = Math.sign(pos.y) || 1;
            pos.y = bh * sign;
            const fe = (C.FLOOR_ELASTICITY !== undefined ? C.FLOOR_ELASTICITY : 0.4);
            this.velocity.y *= -fe;
}
    }

    // --- 2) FX that should run once per frame (not per substep) ---
    if (!this._ghost) {
        const speedSq = this.velocity.lengthSq();
        if (speedSq > 2.0 && window.flux.gameInstance && window.flux.gameInstance.particleManager) {
            this._bubbleTimer -= dt;
            if (this._bubbleTimer <= 0) {
                const pm = window.flux.gameInstance.particleManager;
                const offset = this.velocity.clone().normalize().multiplyScalar(-0.8);

                // Standard bubble
// Standard bubble
                const stdPos = this.mesh.position.clone().add(offset).add(_bDir.set((Math.random()-0.5)*0.3, (Math.random()-0.5)*0.3, (Math.random()-0.5)*0.3));
                if (this.deformNode) stdPos.y += this.deformNode.position.y;
                pm.spawn('bubble', stdPos, { scale: 0.4 + Math.random() * 0.4 }); // Increased scale

                // Micro bubbles at high speed
                if (speedSq > 50.0) {
                    const count = Math.min(4, Math.floor(speedSq / 60));
                    for (let i = 0; i < count; i++) {
const jitter = _bDir.set((Math.random()-0.5)*0.4, (Math.random()-0.5)*0.4, (Math.random()-0.5)*0.4);
                        const spawnPos = this.mesh.position.clone().add(offset).add(jitter);
                        if (this.deformNode) spawnPos.y += this.deformNode.position.y;
                        pm.spawn('bubble_micro', spawnPos, { scale: 0.05 + Math.random() * 0.1 });
                    }
                    this._bubbleTimer = 0.02;
                } else {
                    if (Math.random() > 0.5) {
const jitter = _bDir.set((Math.random()-0.5)*0.2, (Math.random()-0.5)*0.2, (Math.random()-0.5)*0.2);
                        const spawnPos = this.mesh.position.clone().add(offset).add(jitter);
                        if (this.deformNode) spawnPos.y += this.deformNode.position.y;
                        pm.spawn('bubble_micro', spawnPos, { scale: 0.04 + Math.random() * 0.06 });
                    }
                    this._bubbleTimer = 0.05;
                }
            }
        }
    }

    // --- 3) Visual rotation ---
    const spinSpeed = this.angularVelocity.length();
    if (spinSpeed > 0.5) {
        const axis = _tempVec.copy(this.angularVelocity).normalize();
        const q = new THREE.Quaternion().setFromAxisAngle(axis, spinSpeed * dt);
        this.accumulatedRotation.premultiply(q);
    } else {
        const speed = this.velocity.length();
        if (speed > 0.1) {
            _tempVec.copy(this.velocity).cross(_axisY).normalize();
            if (_tempVec.lengthSq() > 0.01) {
                const q = new THREE.Quaternion().setFromAxisAngle(_tempVec, speed * dt);
                this.accumulatedRotation.premultiply(q);
            }
        }
    }
}

grab(player) {
            this.reveal(); 
            
            // Announcement: Possession (if taking from free state)
            if (this.state === 'free') {
                 if (window.flux.gameInstance && window.flux.gameInstance.showAnnouncement) {
                     window.flux.gameInstance.showAnnouncement("POSSESSION", "normal");
                 }
            }

            // Check Turnover (Possession Change)
            const previousTeam = this.holder ? this.holder.team : (this.lastHolder ? this.lastHolder.team : null);
            if (previousTeam && previousTeam !== player.team) {
                 if (window.flux.gameInstance && window.flux.gameInstance.floatingText) {
                     window.flux.gameInstance.floatingText.spawn("TURNOVER", player.mesh.position, "tech");
                 }
            }
            
            // If someone else held it, they lose it
            if (this.holder && this.holder !== player) {
                this.holder.loseBall();
            }

            this.holder = player;
            this.state = 'held';
            
            // NOTE: We do NOT parent the mesh to the player anymore.
            // This prevents the ball from flying around due to swim animations.
            // Instead, we update its position manually in updateHeld().
            
            // Notify player
            if (player.receiveBall) {
                player.receiveBall();
            }
            
            console.log("Ball grabbed by " + player.role);
        }

        drop() {
            this.reveal(); // Ensure visible
            
            // No need to detach from scene graph since we aren't parenting to player anymore.
            // Just clear holder.

            if (this.holder) {
                if (this.holder.loseBall) this.holder.loseBall();
                this.holder = null;
            }
            
            this.state = 'free';
        }
// Shoot/Pass
// Shoot/Pass
        shoot(directionVector, force, type = 'SH', technique = null, spinVector = null) {

            this.lastHolder = this.holder; // Record for EXP attribution
            
            // Fumble Detection (Type 'none' is used by Player.fumble)
            if (type === 'none') {
                if (window.flux.gameInstance && window.flux.gameInstance.showAnnouncement) {
                    window.flux.gameInstance.showAnnouncement("FUMBLE!", "slam");
                }
            }

            this.drop(); // Detach first
            
            // Set Grace Period to prevent instant interceptions/catches
            // 0.2s allows ball to clear the thrower's immediate vicinity
            this.catchGracePeriod = 0.2;

            // Physical Velocity (Visual speed)
            const C = window.flux.BallConfig || {};
            const scale = (C.LAUNCH_SPEED_SCALE !== undefined ? C.LAUNCH_SPEED_SCALE : 1.0);
            const cap = (C.LAUNCH_SPEED_CAP !== undefined ? C.LAUNCH_SPEED_CAP : 85.0);
            const speed = Math.min(force * scale, cap);
            this.velocity.copy(directionVector).normalize().multiplyScalar(speed);
            
            // Apply Spin if provided
            if (spinVector) {
                this.angularVelocity.copy(spinVector);
            } else {
                this.angularVelocity.set(0, 0, 0);
            }
            
            // Stat Power (Game Logic)
            this.power = force;
            this.powerType = type;
            this.technique = technique; 
            
            // Update Trail Color
            if (this.trail) {
                let color = 0x00aaff; // Default Blue (Pass)
                
                if (technique) {
                    if (technique.type === 'venom') color = 0x00ff00; // Green (Venom)
                    else if (technique.type === 'wither') color = 0x888888; // Grey
                    else if (technique.type === 'nap') color = 0x000088; // Dark Blue
                    else if (technique.type === 'sphere') color = 0x00ffff; // Cyan
                    else if (technique.type === 'jecht') color = 0xff0000; // Red
                    else if (technique.type === 'invisible') color = 0x444444; // Dark Grey
                } else if (type === 'SH') {
                    color = 0xff4400; // Orange/Red
                }
                
                this.trail.setColor(color);
            }
            
            // Handle Invisible Shot
            if (technique && technique.type === 'invisible') {
                this.isInvisible = true;
                if (this.mesh) this.mesh.visible = false;
                // FX: Poof
                if (window.flux.gameInstance && window.flux.gameInstance.particleManager) {
                    window.flux.gameInstance.particleManager.spawn('wither', this.mesh.position, { scale: 2.0 });
                }
                console.log("Invisible Shot!");
            }
            
            console.log(`Ball ${type} with Power: ${this.power.toFixed(1)} Spin: ${this.angularVelocity.length().toFixed(1)}`);
            
            // Visual Feedback for Curve
            if (this.angularVelocity.length() > 15.0 && window.flux.gameInstance && window.flux.gameInstance.floatingText) {
                window.flux.gameInstance.floatingText.spawn("CURVE!", this.mesh.position, "tech");
            }
        }

        reveal() {
            if (this.isInvisible) {
                // FX: Reveal Poof
                if (window.flux.gameInstance && window.flux.gameInstance.particleManager && this.mesh) {
                    window.flux.gameInstance.particleManager.spawn('wither', this.mesh.position, { scale: 2.0 });
                }
            }
            this.isInvisible = false;
            if (this.mesh) this.mesh.visible = true;
        }

// Duplicate reveal removed
        
reset() {
            this.reveal();
            this.drop();
            this.mesh.position.set(0, 0, 0);
            this.velocity.set(0, 0, 0);
            this.angularVelocity.set(0, 0, 0);
            this.catchGracePeriod = 0;
            this.power = 0;
        }
isCatchable() {
            return this.catchGracePeriod <= 0;
        }

        updateVisuals(dt) {
            if (!this.deformNode || !this.spinNode) return;

            // 1. Squash & Stretch based on velocity
// 1. Squash & Stretch based on velocity
            const speed = this.velocity.length();
            
            // Only apply stretch if moving fast enough
            if (speed > 1.0 && this.state === 'free') {
                // Orient deformNode to velocity direction
                const dir = this.velocity.clone().normalize();
                // Default forward is Z (0,0,1)
                this.deformNode.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1), dir);
                
                // Calculate stretch factor
                // Max stretch at speed 40 (approx max shot power)
                const factor = Math.min(speed / 40.0, 1.0); 
                const stretch = 1.0 + (factor * 0.8); // Increased stretch max to 1.8x
                const squash = 1.0 / Math.sqrt(stretch); // Maintain volume
                
                this.deformNode.scale.set(squash, squash, stretch);
            } else {
                // Reset deformation
                this.deformNode.quaternion.identity();
                this.deformNode.scale.set(1, 1, 1);
            }

            // 2. Apply Accumulated Spin
            // Since deformNode might be rotated, we need to apply spin in the correct space.
            // spinNode rotation = deformNode_inverse * accumulatedRotation
const invDeform = this.deformNode.quaternion.clone().invert();
            this.spinNode.quaternion.copy(invDeform.multiply(this.accumulatedRotation));
        }
    }

window.flux.Ball = Ball;
    window.flux.TrailRenderer = TrailRenderer;
})();