(function() {
    window.flux = window.flux || {};

    // Ball Lab / DevTools: throw & curve mapping knobs
    // (Defaults match current feel; DevTools can tweak at runtime.)
    window.flux.ThrowConfig = window.flux.ThrowConfig || {
        SWIPE_MIN_PX: 20,
        AIM_DX_SCALE: 1.0,
        AIM_DY_SCALE: 1.0,

        POWER_BASE: 1.0,
        POWER_RANGE: 0.8,          // Base multiplier = POWER_BASE + ratio*POWER_RANGE
        POWER_MAX_BONUS_RATIO: 0.95,
        POWER_MAX_MULTIPLIER: 2.5,

        CURVE_ENABLED: true,
        CURVE_INTENSITY_THRESHOLD: 0.25,
        CURVE_SPIN_SCALE: 1000.0,
        CURVE_SPEED_MULT: 1.5,
        CURVE_SPIN_CAP: 1500.0,
        CURVE_PERFECT_SPIN: 500.0
    };

// Reusable math objects
const _pVec = new THREE.Vector3();
    const _pVec2 = new THREE.Vector3();
    const _pQuat = new THREE.Quaternion();
    const _pQuat2 = new THREE.Quaternion();
    const _pTargetQuat = new THREE.Quaternion();
    const _pEuler = new THREE.Euler();
    const _pAxisY = new THREE.Vector3(0, 1, 0);
    const _pAxisZ = new THREE.Vector3(0, 0, 1);
    const _pInvQuat = new THREE.Quaternion();
    const _pTmpQuat = new THREE.Quaternion();
    const _pTmpEuler = new THREE.Euler();


class Player {
        constructor(scene, role = 'MF') {
            this.scene = scene;
            this.role = role;
            this.team = null; // Assigned by Team.addPlayer
            this.homePosition = new THREE.Vector3();

            this.mesh = null;
            this.mixer = null;
            this.actions = {};
            this.activeAction = null;
            this.state = 'idle';
                        this._animLocked = false;
            this._lockedState = null;
            this._lastLocomotion = 'idle';
this.inputVector = new THREE.Vector3(0, 0, 0);

            // Physics (Drift/Inertia Model)
            this.velocity = new THREE.Vector3(0, 0, 0);
            this.acceleration = 12.0;
            this.drag = 3.0;
            this.maxSpeed = 8.0;
            // Bone reference for holding ball
            this.handBone = null;
// Procedural animation bone refs (filled in setMesh)
this.bones = {
    hips: null,
    spine: null,
    chest: null,
    neck: null,
    head: null,
    rUpperArm: null,
    rForeArm: null,
    rHand: null,
    lUpperArm: null,
    lForeArm: null,
    lHand: null
};
this._boneBaseQuats = null; // Optional future use
this._procAnimTime = 0;
this._smoothedSpeed = 0;
this._movingLatch = false;

this.canCatch = true;
            this.catchCooldown = 0; // Replaces setTimeout for safety

            // Blitzball Stats
            this.stats = {
                HP: 100,
                maxHP: 100,
                EN: 30,
                AT: 10,
                PA: 15,
                BL: 10,
                SH: 15,
                CA: 10,
                SP: 60
            };

            // Leveling System
            this.level = 1;
            this.exp = 0;
            this.nextLevelExp = 100;

            // Status Effects & Techniques
            this.status = {
                venom: 0,
                nap: 0,
                wither: { PA: 0, SH: 0, AT: 0, BL: 0, CA: 0, SP: 0 }
            };

            this.marking = null;
            this.learnedTechs = [];

            this.techs = {
                tackle: null,
                shoot: null,
                pass: null,
                passive: null
            };

            // Visuals
            this.baseColorHex = 0xffffff;
            this.originalMaterials = [];
            this.auraMesh = null;
            this.rotationOffset = 0;
this.baseScale = 1.17; // Increased ~8%

            // Real-time Stats
            this.currentEN = this.stats.EN;
this.tackleRadius = 2.0; // Reduced from 2.5 to reduce swarm lock

            this.speed = 4.0;
            this._updateDerivedStats();

            this.hasBall = false;
            this.isThrowing = false;

            // Dash State
            this.isDashing = false;
            this.dashTime = 0;
            this.dashTotalTime = 0.5;
this.dashCooldown = 0;
            this.dashVec = new THREE.Vector3();

            // Feedback Accumulators
            this._accumulatedDamage = 0;
            this._damageTimer = 0;

            // HP Bar
            this.hpBar = null;
            this.hpBarFill = null;

            // Gameplay Flow Timers
            this.stunTimer = 0;
            this.immunityTimer = 0;

            // Banking & Verticality
            this.bankingAmount = 0;
            this.targetY = 0;

            // Encounter System
            this.isEngaged = false;
            this.clashTimer = 0;

            this.encounterTimer = 0; // Track duration of current engagement
            // Charge Mechanic
            this.isCharging = false;
            this.chargeTime = 0;
            this.maxChargeTime = 1.5;

            // FIXED: Improved Rotation State with hysteresis
            this.currentYaw = 0;
            this.targetYaw = 0;
            this.lastValidYaw = 0; // Store last known good yaw for deadzone handling
            this.pitchAmount = 0;
            this.bankingAmount = 0;
            this.facingDeadzone = 0.3; // Minimum input/velocity magnitude to update facing

            // Particle Emission Timers
            this._particleTimers = {
                venom: 0,
                nap: 0,
                wither: 0
            };

            // DevTools Flags
            this.isGodMode = false;

            // Pass Target Indicator
// Pass Target Indicator
            this.passTargetIndicator = null;
            
            // Bubble Trail Timer
            this._bubbleTimer = 0;

this._dashParticleTimer = 0;
            this.struggleIntensity = 0; // Continuous pressure factor (0.0 to 1.0)
        }

        syncRotation() {
            if (!this.mesh) return;
            const euler = new THREE.Euler().setFromQuaternion(this.mesh.quaternion, 'YXZ');
            this.currentYaw = euler.y - this.rotationOffset;
            this.targetYaw = this.currentYaw;
            this.lastValidYaw = this.currentYaw;
            this.bankingAmount = 0;
            this.pitchAmount = 0;
        }

        getStat(name) {
            let val = this.stats[name];
            if (this.status.wither[name] > 0) {
                val *= 0.5;
            }
            return val;
        }

        applyStatus(type, duration, subType = null) {
            if (type === 'venom') {
                const wasActive = this.status.venom > 1.0;
                this.status.venom = Math.max(this.status.venom, duration);

                if (!wasActive) {
                    console.log(`${this.role} poisoned!`);
                    if (window.flux.gameInstance.floatingText)
                        window.flux.gameInstance.floatingText.spawn("POISON", this.mesh.position, "status");
                }
            } else if (type === 'nap') {
                const wasActive = this.status.nap > 1.0;
                this.status.nap = Math.max(this.status.nap, duration);

                if (!wasActive) {
                    if (this.hasBall) this.fumble();
                    console.log(`${this.role} fell asleep!`);
                    if (window.flux.gameInstance.floatingText)
                        window.flux.gameInstance.floatingText.spawn("SLEEP", this.mesh.position, "status");
                }
            } else if (type === 'wither' && subType) {
                const currentVal = this.status.wither[subType] || 0;
                const wasActive = currentVal > 1.0;
                this.status.wither[subType] = Math.max(currentVal, duration);

                if (!wasActive) {
                    console.log(`${this.role} withered ${subType}!`);
                    if (window.flux.gameInstance.floatingText)
                        window.flux.gameInstance.floatingText.spawn(`WITHER ${subType}`, this.mesh.position, "status");
                }
            }
        }

        _updateDerivedStats() {
            const sp = this.getStat('SP');
            this.maxSpeed = 5.0 + (sp / 15.0);
            this.currentEN = this.getStat('EN');
        }

setMesh(sourceMesh, animations) {
            this.mesh = sourceMesh;
            this.scene.add(this.mesh);
            this._createHPBar();
            this._createAura();
            this._createPassTargetIndicator();

            // Custom Character Scaling
            if (this.characterName) {
                if (this.characterName.includes('Tidus')) this.baseScale = 1.6;
                else if (this.characterName.includes('Wakka')) this.baseScale = 1.4;
            }

            this.mesh.scale.setScalar(this.baseScale);

            this.mesh.traverse((node) => {
                if (node.isMesh && node.material) {
                    const convertOne = (mat) => {
                        const m = new THREE.MeshBasicMaterial({
                            map: mat.map || null,
                            color: new THREE.Color(0xffffff), // FORCE WHITE: Ignore source color
                            transparent: !!mat.transparent,
                            opacity: (mat.opacity !== undefined ? mat.opacity : 1),
                            alphaTest: (mat.alphaTest !== undefined ? mat.alphaTest : 0),
                            side: mat.side,
                            depthTest: mat.depthTest,
                            depthWrite: mat.depthWrite,
                            fog: true,
                            skinning: !!node.isSkinnedMesh
                        });
                        this.originalMaterials.push({ material: m, baseColor: m.color.clone() });
                        return m;
                    };
                    node.material = Array.isArray(node.material)
                        ? node.material.map(convertOne)
                        : convertOne(node.material);
                }

                if (node.isBone) {
                    const name = (node.name || '').toLowerCase();

                    // Core spine/head chain (Mixamo-friendly)
                    if (!this.bones.hips && name.includes('hips')) this.bones.hips = node;
                    if (!this.bones.spine && name.includes('spine') && !name.includes('spine2') && !name.includes('spine_2')) this.bones.spine = node;
                    if (!this.bones.chest && (name.includes('chest') || name.includes('spine2') || name.includes('spine_2'))) this.bones.chest = node;
                    if (!this.bones.neck && name.includes('neck')) this.bones.neck = node;
                    if (!this.bones.head && name.includes('head')) this.bones.head = node;

                    const isRight = name.includes('right') || name.endsWith('r') || name.includes('_r') || name.includes('.r');
                    const isLeft  = name.includes('left')  || name.endsWith('l') || name.includes('_l') || name.includes('.l');

                    // Arms/hands (Mixamo: mixamorigRightArm/RightForeArm/RightHand)
                    if (!this.bones.rUpperArm && (name.includes('rightarm') || (isRight && name.includes('upperarm')))) this.bones.rUpperArm = node;
                    if (!this.bones.rForeArm && (name.includes('rightforearm') || (isRight && name.includes('forearm')))) this.bones.rForeArm = node;
                    if (!this.bones.rHand && ((name.includes('hand') && isRight) || name.includes('righthand'))) this.bones.rHand = node;

                    if (!this.bones.lUpperArm && (name.includes('leftarm') || (isLeft && name.includes('upperarm')))) this.bones.lUpperArm = node;
                    if (!this.bones.lForeArm && (name.includes('leftforearm') || (isLeft && name.includes('forearm')))) this.bones.lForeArm = node;
                    if (!this.bones.lHand && ((name.includes('hand') && isLeft) || name.includes('lefthand'))) this.bones.lHand = node;

                    // Back-compat: ball attachment uses handBone
                    if (!this.handBone && this.bones.rHand) this.handBone = this.bones.rHand;
                }
            });

            this.mixer = new THREE.AnimationMixer(this.mesh);

            if (animations) {
                const _normClipName = (s) => (s || '')
                    .toLowerCase()
                    .replace(/[_\-]+/g, ' ')
                    .replace(/\s+/g, ' ')
                    .trim();

                // Helper to strip leg tracks from action clips
                const _stripLegs = (clip) => {
                    const tracks = [];
                    clip.tracks.forEach(t => {
                        // Regex to match leg bones (Mixamo style: RightUpLeg, RightLeg, RightFoot, RightToeBase)
                        // Also generic "Leg", "Foot"
                        if (!t.name.match(/(UpLeg|Leg|Foot|Toe)/i)) {
                            tracks.push(t);
                        }
                    });
                    clip.tracks = tracks;
                    return clip;
                };

                animations.forEach((clip) => {
                    const name = _normClipName(clip.name);
                    const has = (re) => re.test(name);
                    
                    let isLocomotion = false;
                    let actionKey = null;

                    // --- Core locomotion ---
                    if (has(/tread|treading|idle|float/)) {
                        actionKey = 'idle';
                        isLocomotion = true;
                    } else if (has(/dash|sprint|burst|fast\s*swim|swim\s*fast/)) {
                        actionKey = 'dash';
                        isLocomotion = true;
                    } else if (has(/swim|freestyle|crawl/)) {
                        actionKey = 'swim';
                        isLocomotion = true;
                    
                    // --- Throwing (pass/shot variants if present) ---
                    } else if (has(/throw|toss|pitch/)) {
                        if (has(/shoot|shot|goal/)) actionKey = 'throw_shot';
                        else if (has(/pass/)) actionKey = 'throw_pass';
                        else actionKey = 'throw';

                    // --- Catching (jump/air variants if present) ---
                    } else if (has(/catch|receive|grab|intercept/)) {
                        if (has(/jump|leap|air|dive/)) actionKey = 'catch_jump';
                        else actionKey = 'catch';

                    // --- Hit / React ---
                    } else if (has(/react|hit|hurt|damage|stagger|knock/)) {
                        actionKey = 'react';

                    // --- Optional states ---
                    } else if (has(/charge|aim|ready|windup|hold/)) {
                        actionKey = 'charge';
                    } else if (has(/tackle|check|ram/)) {
                        actionKey = 'tackle';
                    } else if (has(/block|save/)) {
                        actionKey = 'block';
                    } else if (has(/celebrate|victory|cheer/)) {
                        actionKey = 'celebrate';
                    } else {
                        actionKey = clip.name;
                    }

                    // Strip legs from non-locomotion clips to allow treading water overlay
                    if (!isLocomotion && actionKey) {
                        _stripLegs(clip);
                    }

                    if (actionKey) {
                        this.actions[actionKey] = this.mixer.clipAction(clip);
                    }
                });
            }

            // Start default locomotion
            if (this.actions['idle']) {
                this.playLocomotion('idle');
            } else {
                // Fallback
                const first = Object.values(this.actions)[0];
                if(first) first.play();
            }

            // One-shot animation listener
            if (this.mixer) {
                this.mixer.addEventListener('finished', (e) => {
                    if (!this._animLocked) return;
                    if (!e || !e.action) return;
                    
                    // Check if the finished action is our current one-shot
                    if (e.action === this.activeOneShot) {
                        this._animLocked = false;
                        this._lockedState = null;
                        this.activeOneShot = null;

                        // Return to locomotion updates
                        if (!this.isThrowing) {
                            this._updateLocomotionAnim(0.15);
                        }
                    }
                });
            }
        }

        // New method for base layer (legs/body movement)
        playLocomotion(actionName, duration = 0.5) {
            const newAction = this.actions[actionName];
            if (!newAction || newAction === this.activeLocomotion) return;

            if (this.activeLocomotion) {
                this.activeLocomotion.fadeOut(duration);
            }

            newAction.reset();
            newAction.fadeIn(duration);
            newAction.play();
            this.activeLocomotion = newAction;
            this._lastLocomotion = actionName;
        }

        // Overhauled play method to handle layering
        play(actionName, duration = 0.5) {
            // If it's a locomotion state, route to playLocomotion
            if (['idle', 'swim', 'dash'].includes(actionName)) {
                this.playLocomotion(actionName, duration);
                return;
            }

            // Otherwise treat as an action layer
            const newAction = this.actions[actionName];
            if (!newAction) return;

            // If we have an active one-shot, fade it out
            if (this.activeOneShot && this.activeOneShot !== newAction) {
                this.activeOneShot.fadeOut(0.1);
            }

            newAction.reset();
            newAction.fadeIn(0.1); // Fast transition for actions
            newAction.play();
            
            this.activeOneShot = newAction;
            this.state = actionName;
        }

        _updateLocomotionAnim(duration = 0.2) {
            // Note: We NO LONGER check _animLocked here.
            // Locomotion should update continuously based on speed, 
            // running underneath the upper body action.
            
            const vx = this.velocity ? this.velocity.x : 0;
            const vz = this.velocity ? this.velocity.z : 0;
            const speed = Math.sqrt(vx * vx + vz * vz);

            // Smooth speed
            const smoothK = 1.0 - Math.pow(0.001, duration);
            this._smoothedSpeed += (speed - this._smoothedSpeed) * smoothK;

            const speedNorm = (this.maxSpeed > 0.0001) ? THREE.MathUtils.clamp(this._smoothedSpeed / this.maxSpeed, 0, 1) : 0;

            // Hysteresis
            const enterMove = 0.18;
            const exitMove = 0.10;

            const inputMoving = this.inputVector && this.inputVector.lengthSq() > 0.06;
            const velMoving = this._smoothedSpeed > (this._movingLatch ? exitMove : enterMove);

            this._movingLatch = inputMoving || velMoving;

            let target = this._movingLatch ? 'swim' : 'idle';
            if (this._movingLatch && this.isDashing && this.actions['dash']) target = 'dash';

            // Update playback rate
            const applyRate = (key) => {
                const a = this.actions[key];
                if (!a) return;
                if (key === 'swim') a.timeScale = THREE.MathUtils.lerp(0.85, 1.70, speedNorm);
                else if (key === 'dash') a.timeScale = THREE.MathUtils.lerp(1.10, 2.20, speedNorm);
                else if (key === 'idle') a.timeScale = THREE.MathUtils.lerp(0.95, 1.05, speedNorm);
            };

            applyRate(target);

            if (this._lastLocomotion !== target) {
                const a = this.actions[target];
                if (a) {
                    try { a.setLoop(THREE.LoopRepeat); } catch (_) {}
                    a.clampWhenFinished = false;
                }
                this.playLocomotion(target, duration);
            }
        }

        playOneShot(actionName, duration = 0.1, opts = {}) {
            const a = this.actions[actionName];
            if (!a) return false;

            this._animLocked = true;
            this._lockedState = actionName;

            try {
                a.reset();
                a.setLoop(THREE.LoopOnce);
                a.clampWhenFinished = true;
                a.timeScale = (opts.timeScale !== undefined ? opts.timeScale : 1.0);
            } catch (_) {}

            // Use the new play method which handles layering
            this.play(actionName, duration);
            return true;
        }
        setInput(x, z) {
            if (this.status.nap > 0) {
                this.inputVector.set(0, 0, 0);
                return;
            }
            this.inputVector.set(x, 0, z);
        }

receiveBall() {
            this.canCatch = false;
            
            // CRITICAL FIX: Reset states that might prevent shooting
            this.isThrowing = false;
            this.isCharging = false;
            this._hideChargeUI();

            if (this.status.nap > 0) {
                this.status.nap = 0;
            }

            this.hasBall = true;
            this.immunityTimer = 2.0;

            const ball = window.flux.gameInstance.entities.ball;
            if (ball && ball.lastHolder && ball.lastHolder.team === this.team && ball.lastHolder !== this) {
                ball.lastHolder.gainExp(2);
                this.gainExp(1);
            }

            const ballY = (this.ballRef && this.ballRef.mesh) ? this.ballRef.mesh.position.y : 0;
            const catchKey = (ballY > 0.25 && this.actions['catch_jump']) ? 'catch_jump' : 'catch';
            this.playOneShot(catchKey, 0.1);

            if (window.flux.gameInstance.floatingText) {
                window.flux.gameInstance.floatingText.spawn("SNAP!", this.mesh.position, "comic-action");
            }
        }

throwBall(ball, forcedType = null, powerMultiplier = 1.0, forcedSpin = null) {
            if (!this.hasBall || this.isThrowing) return;
            if (this.status.nap > 0) return;

            this.isThrowing = true;

            // Lock aim direction at start of throw
            this.lockedAimVector = new THREE.Vector3();

            if (this.inputVector.lengthSq() > 0.1) {
                this.lockedAimVector.copy(this.inputVector).normalize();
            } else {
                this.lockedAimVector.set(0, 0, 1).applyQuaternion(this.mesh.quaternion).normalize();
            }

const goalZ = (this.team && this.team.side === 1) ? -46 : 46;
            const distToGoal = Math.abs(this.mesh.position.z - goalZ);

            let type = forcedType;
            if (!type) {
                type = (distToGoal < 25) ? 'SH' : 'PA';
            }

            const isFinisher = (type === 'SH' && distToGoal < 12.0);

            let techName = (type === 'SH') ? this.techs.shoot : this.techs.pass;

            if (this.status.venom > 0 && techName) {
                if (window.flux.gameInstance.floatingText)
                    window.flux.gameInstance.floatingText.spawn("SILENCED", this.mesh.position, "status");
                techName = null;
            }

            let windupTime = 100;
            let animSpeed = 1.5;

            if (powerMultiplier > 1.1) {
                windupTime += 200;
            }

            if (isFinisher && !techName) {
                windupTime = 50;
                animSpeed = 3.0;
            }

if (techName) {
                windupTime = 400;
                animSpeed = 0.8;

                if (window.flux.gameInstance.cameraManager) {
                    window.flux.gameInstance.cameraManager.playCinematic(techName, this.mesh, 1.2);
                }

                this.immunityTimer = 1.5;

                if (window.flux.gameInstance.floatingText) {
                    const label = techName.replace('_', ' ').toUpperCase();
                    window.flux.gameInstance.floatingText.spawn(label, this.mesh.position, "tech");
                }

                // NEW: Spawn Tech Glyph (Vertical Casting Circle)
                if (window.flux.gameInstance.glyphManager) {
                    window.flux.gameInstance.glyphManager.spawn('tech', this.mesh.position, {
                        parent: this,
                        life: 1.2,
                        rotationSpeed: 4.0,
                        scaleSpeed: 1.5,
                        offsetY: 1.2,
                        faceCamera: true
                    });
                }
            }

            // Pick best throw clip (pass/shot variants if present)
            const throwKey =
                (type === 'SH' && this.actions['throw_shot']) ? 'throw_shot' :
                (type === 'PA' && this.actions['throw_pass']) ? 'throw_pass' :
                'throw';

            this.playOneShot(throwKey, 0.1, { timeScale: animSpeed });

            if (window.flux.gameInstance.floatingText && !techName) {
                window.flux.gameInstance.floatingText.spawn("WHOOSH", this.mesh.position, "comic-action");
            }

setTimeout(() => {
                // Safety: If ball holder is still us, proceed. If hasBall is false but holder is us, assume sync lag and proceed.
                if (this.hasBall || (ball && ball.holder === this)) {
const throwAction = this.actions[throwKey];
                    if (throwAction) throwAction.timeScale = 1.0;

                    let finalDir = new THREE.Vector3();
                    let referenceDir = new THREE.Vector3();

if (this.overrideAimVector) {
                        finalDir.copy(this.overrideAimVector).normalize();
                        referenceDir.copy(finalDir);

                        // REMOVED: Instant rotation snap. 
                        // The update loop handles smooth rotation via targetYaw.
                        // This prevents the "flipping around" visual glitch.
                    } else {
                        finalDir.copy(this.lockedAimVector);
                        referenceDir.copy(this.lockedAimVector);
                    }

const spin = new THREE.Vector3(0, 0, 0);

                    if (forcedSpin) {
                        spin.copy(forcedSpin);
                    } else if (this.inputVector.lengthSq() > 0.1) {
                        const inputDir = this.inputVector.clone().normalize();
                        const crossY = new THREE.Vector3().crossVectors(referenceDir, inputDir).y;

                        if (Math.abs(crossY) > 0.1) {
                            spin.set(0, crossY * 12.0, 0);
                        }
                    }

                    let baseCost = (type === 'SH') ? 20 : 10;
                    let techCost = 0;
                    let techBonus = 0;
                    let techPayload = null;

                    if (techName) {
                        switch (techName) {
                            case 'venom':
                                techCost = (type === 'SH' ? 20 : 10);
                                techBonus = 3;
                                techPayload = { type: 'venom', level: 1 };
                                break;
                            case 'wither':
                                techCost = (type === 'SH' ? 20 : 10);
                                techBonus = 3;
                                techPayload = { type: 'wither', level: 1 };
                                break;
                            case 'nap':
                                techCost = (type === 'SH' ? 35 : 30);
                                techBonus = 3;
                                techPayload = { type: 'nap', level: 1 };
                                break;
                            case 'sphere':
                                if (type === 'SH') {
                                    techCost = 25;
                                    const rng = Math.floor(Math.random() * 11) + 5;
                                    techBonus = rng;
                                    techPayload = { type: 'sphere', level: 1, bonus: rng };
                                    if (window.flux.gameInstance.floatingText)
                                        window.flux.gameInstance.floatingText.spawn(`SPHERE +${rng}`, this.mesh.position, "goal");
                                }
                                break;
                            case 'jecht':
                                if (type === 'SH') {
                                    techCost = 40;
                                    techBonus = 5;
                                    techPayload = { type: 'jecht', level: 1 };
                                    this._performJechtKnockback();
                                }
                                break;
                            case 'invisible':
                                if (type === 'SH') {
                                    techCost = 25;
                                    techBonus = 2;
                                    techPayload = { type: 'invisible', level: 1 };
                                }
                                break;
                        }
                    }

                    const totalCost = baseCost + techCost;

                    let powerFactor = 1.0;
                    if (this.stats.HP < totalCost) {
                        powerFactor = 0.5;
                        this.stats.HP = 0;
                        techPayload = null;
                        techBonus = 0;
                        if (window.flux.gameInstance.floatingText)
                            window.flux.gameInstance.floatingText.spawn("TIRED", this.mesh.position, "damage");
                    } else {
                        this.stats.HP -= totalCost;
                    }

                    let statVal = this.getStat(type);
                    statVal += techBonus;
                    statVal *= powerFactor;
                    statVal *= powerMultiplier;

const goalZ = (this.team && this.team.side === 1) ? -46 : 46;
                    const goalDir = new THREE.Vector3(0, 0, goalZ - this.mesh.position.z).normalize();
                    const goalDot = finalDir.dot(goalDir);

                    if (type === 'SH') {
                        const goalPos = new THREE.Vector3(0, 2, goalZ);
                        const toGoal = goalPos.clone().sub(this.mesh.position).normalize();

                        const sh = this.getStat('SH');
                        let assistFactor = Math.min(0.9, Math.max(0.1, sh / 100.0));

                        if (this.overrideAimVector) {
                            assistFactor *= 0.1;
                        }

                        if (goalDot > 0.2) {
                            finalDir.lerp(toGoal, assistFactor);
                        }

                        if (isFinisher) {
                            finalDir.y += 0.05;
                            if (window.flux.gameInstance.floatingText) {
                                window.flux.gameInstance.floatingText.spawn("SLAM!", this.mesh.position, "comic-impact");
                            }
} else {
                            finalDir.y += 0.25;
                        }
                        
// Goalie Loft Bonus (Prevent interception by immediate defender)
                        if (this.role === 'GL') finalDir.y += 0.8; // High loft for clearance

                    } else {
                        const target = this._findPassTargetInCone(finalDir);

                        if (target) {
                            const toMate = target.mesh.position.clone().sub(this.mesh.position);
                            if (target.velocity.lengthSq() > 0.1) {
                                toMate.addScaledVector(target.velocity, 0.5);
                            }
                            toMate.normalize();

                            const pa = this.getStat('PA');
                            let assistFactor = Math.min(1.0, 0.3 + (pa / 80.0));

                            if (this.overrideAimVector) {
                                assistFactor *= 0.1;
                            }

                            finalDir.lerp(toMate, assistFactor);

                            const dist = this.mesh.position.distanceTo(target.mesh.position);
                            finalDir.y += Math.min(0.6, dist * 0.03);
                        } else {
finalDir.y += 0.2;
                        }
                        
                        // Goalie Loft Bonus for Passing
// Goalie Loft Bonus for Passing
                        if (this.role === 'GL') finalDir.y += 0.8; // High loft for clearance
                    }

                    finalDir.normalize();

                    if (techPayload && window.flux.gameInstance && window.flux.gameInstance.triggerTechEvent) {
                        window.flux.gameInstance.triggerTechEvent(this, techName);
                    }

ball.shoot(finalDir, statVal, type, techPayload, spin);
                    
                    // Extra grace period for Goalie to prevent point-blank interceptions
                    if (this.role === 'GL') {
                        ball.catchGracePeriod = 0.6; // 0.6s immunity (approx 10-12m travel)
                    }

this.loseBall();

this.catchCooldown = 1.0; // 1s cooldown
                    this.canCatch = false;
                }
            }, windupTime);

            setTimeout(() => {
                this.isThrowing = false;
                this.overrideAimVector = null;
                this._updateLocomotionAnim(0.2);
            }, windupTime + 500);
        }

        _findPassTargetInCone(aimDir) {
            if (!this.team) return null;

            let bestTarget = null;
            let maxScore = -Infinity;

            for (const mate of this.team.players) {
                if (mate === this || !mate.mesh) continue;

                const toMate = mate.mesh.position.clone().sub(this.mesh.position).normalize();
                const dot = aimDir.dot(toMate);

                if (dot > 0.7) {
                    const dist = this.mesh.position.distanceTo(mate.mesh.position);
                    const score = (dot * 10) - (dist * 0.1);

                    if (score > maxScore) {
                        maxScore = score;
                        bestTarget = mate;
                    }
                }
            }
            return bestTarget;
        }

startCharge() {
            if (!this.hasBall || this.isThrowing || this.status.nap > 0) return;
            this.isCharging = true;
            this.chargeTime = 0;

// Visuals handled in update

            // Show charge UI
            this._updateChargeUI(0);

            // NEW: Spawn Charge Glyph (Ground Ring)
            if (window.flux.gameInstance && window.flux.gameInstance.glyphManager) {
                window.flux.gameInstance.glyphManager.spawn('charge', this.mesh.position, {
                    parent: this,
                    life: this.maxChargeTime,
                    rotationSpeed: 3.0,
                    scaleSpeed: 0.2,
                    offsetY: 0.1
                });
            }
        }

releaseCharge(dx, dy, curveInput = null) {
            if (!this.isCharging) return;
            this.isCharging = false;

            // Power Calculation
            const ratio = Math.min(this.chargeTime / this.maxChargeTime, 1.0);
            const TC = window.flux.ThrowConfig || {};

            // Base multiplier (defaults: 1.0 to 1.8)
            let multiplier = (TC.POWER_BASE !== undefined ? TC.POWER_BASE : 1.0) + (ratio * (TC.POWER_RANGE !== undefined ? TC.POWER_RANGE : 0.8));// MAX POWER BONUS: If held near max, significant boost
            if (ratio > (TC.POWER_MAX_BONUS_RATIO !== undefined ? TC.POWER_MAX_BONUS_RATIO : 0.95)) {
                multiplier = (TC.POWER_MAX_MULTIPLIER !== undefined ? TC.POWER_MAX_MULTIPLIER : 2.5); // Critical Power
                if (window.flux.gameInstance.floatingText) {
                    window.flux.gameInstance.floatingText.spawn("MAX POWER!", this.mesh.position, "comic-impact");
                }
                if (window.flux.gameInstance.cameraManager) {
                    window.flux.gameInstance.cameraManager.addFovImpulse(-10);
                    window.flux.gameInstance.cameraManager.addShake(1.0);
                }
            }

            this._hideChargeUI();

            // Aim Vector Calculation
            let aimVec = null;
            const swipeLen = Math.sqrt(dx*dx + dy*dy);

            if (swipeLen > (TC.SWIPE_MIN_PX !== undefined ? TC.SWIPE_MIN_PX : 20)) {
                const camera = window.flux.gameInstance.camera;
                const fwd = new THREE.Vector3();
                const right = new THREE.Vector3();

                if (camera) {
                    camera.getWorldDirection(fwd);
                    fwd.y = 0;
                    if (fwd.lengthSq() < 0.001) fwd.set(0, 0, -1);
                    else fwd.normalize();

                    right.crossVectors(fwd, new THREE.Vector3(0, 1, 0)).normalize();

                    const worldVec = new THREE.Vector3();
                    worldVec.addScaledVector(right, dx * (TC.AIM_DX_SCALE !== undefined ? TC.AIM_DX_SCALE : 1.0));
                    worldVec.addScaledVector(fwd, -dy * (TC.AIM_DY_SCALE !== undefined ? TC.AIM_DY_SCALE : 1.0));
                    worldVec.normalize();

                    aimVec = worldVec;
                    this.overrideAimVector = aimVec;
                } else {
                    aimVec = new THREE.Vector3(0, 0, 1).applyQuaternion(this.mesh.quaternion).normalize();
                    this.overrideAimVector = null;
                }
            } else {
                aimVec = new THREE.Vector3(0, 0, 1).applyQuaternion(this.mesh.quaternion).normalize();
                this.overrideAimVector = null;
            }

// --- ANALOG CURVE LOGIC ---
            // Formula: Curve = Intensity * Speed
            let spinVec = null;
            
if ((TC.CURVE_ENABLED !== false) && curveInput && Math.abs(curveInput.intensity) > (TC.CURVE_INTENSITY_THRESHOLD !== undefined ? TC.CURVE_INTENSITY_THRESHOLD : 0.25)) {
                const rawIntensity = Math.abs(curveInput.intensity);
                const sign = Math.sign(curveInput.intensity); // Positive = Right Hump = Left Curve
                const swipeSpeed = curveInput.speed || 1.0;

                // 1. Base Spin from Arc (Tuned for realism, no cyclones)
// 1. Base Spin from Arc (Herculean Boost)
                let spinMag = rawIntensity * (TC.CURVE_SPIN_SCALE !== undefined ? TC.CURVE_SPIN_SCALE : 1000.0);

                // 2. Speed Bonus (Quickness adds RPM)
                const speedBonus = Math.max(1.0, swipeSpeed * (TC.CURVE_SPEED_MULT !== undefined ? TC.CURVE_SPEED_MULT : 1.5));
                spinMag *= speedBonus;

                // Cap (Increased to 1500 for massive arcs)
                spinMag = Math.min((TC.CURVE_SPIN_CAP !== undefined ? TC.CURVE_SPIN_CAP : 1500.0), spinMag);

                // Apply Spin
                // Right Hump (Positive Intensity) -> Left Curve (Positive Spin Y)
                spinVec = new THREE.Vector3(0, spinMag * sign, 0);
                
if (spinMag > (TC.CURVE_PERFECT_SPIN !== undefined ? TC.CURVE_PERFECT_SPIN : 500.0) && window.flux.gameInstance.floatingText) {
                    window.flux.gameInstance.floatingText.spawn("PERFECT CURVE", this.mesh.position, "tech");
                    if (window.flux.gameInstance.cameraManager) {
                        window.flux.gameInstance.cameraManager.addShake(0.5);
                        window.flux.gameInstance.cameraManager.addRollImpulse(sign * -0.3); // Tilt camera into the curve
                    }
                }
            }

            // Determine Type (Pass vs Shoot)
// Determine Type (Pass vs Shoot)
            const goalZ = (this.team && this.team.side === 1) ? -46 : 46;
            const goalDir = new THREE.Vector3(0, 0, goalZ - this.mesh.position.z).normalize();
            const dotGoal = aimVec.dot(goalDir);

            let type = 'PA';
            const distToGoal = Math.abs(this.mesh.position.z - goalZ);

            if (dotGoal > 0.8 && distToGoal < 35.0) {
                type = 'SH';
            } else if (dotGoal > 0.5 && distToGoal < 20.0) {
                type = 'SH';
            }

            // Smart Pass Override
            const targetMate = this._findPassTargetInCone(aimVec);
            if (targetMate && type === 'SH') {
                const distMate = this.mesh.position.distanceTo(targetMate.mesh.position);
                if (distMate < 12.0) type = 'PA';
            }

            const ball = window.flux.gameInstance.entities.ball;
            if (ball) {
                this.throwBall(ball, type, multiplier, spinVec);
            }
        }

        // NEW: Charge UI methods
        _updateChargeUI(ratio) {
            const meter = document.getElementById('charge-meter-fill');
            if (meter) {
                meter.style.width = `${ratio * 100}%`;
                if (ratio > 0.9) {
                    meter.style.background = 'linear-gradient(90deg, #ff0, #f80)';
                } else if (ratio > 0.5) {
                    meter.style.background = 'linear-gradient(90deg, #0f0, #ff0)';
                } else {
                    meter.style.background = 'linear-gradient(90deg, #0af, #0f0)';
                }
            }
            const container = document.getElementById('charge-meter-container');
            if (container) container.style.display = 'block';
        }

        _hideChargeUI() {
            const container = document.getElementById('charge-meter-container');
            if (container) container.style.display = 'none';
        }

        setOverrideAim(x, z) {
            if (!this.overrideAimVector) this.overrideAimVector = new THREE.Vector3();
            this.overrideAimVector.set(x, 0, z).normalize();
        }

loseBall() {
            this.hasBall = false;
            this._hidePassTargetIndicators();
            // Fix: Ensure player can catch again if they lose possession unexpectedly
            this.canCatch = true;
            // Safety: Reset states to prevent locking
            this.isThrowing = false;
            this.isCharging = false;
            this._hideChargeUI();
        }

update(dt) {
            if (!this.mesh) return;

            // SYNC FIX: If ball thinks I hold it, but I don't, force receive
            if (this.ballRef && this.ballRef.holder === this && !this.hasBall) {
                console.warn("Syncing ball possession to player");
                this.receiveBall();
            }

            if (this.isGodMode) {
                this.stats.HP = this.stats.maxHP;
                this.currentEN = this.getStat('EN');
                this.status.venom = 0;
                this.status.nap = 0;
            }

            if (this.mixer) {
                this.mixer.update(dt);
            }
            // Animation: keep locomotion/charge updated unless a one-shot is locking animations.
            this._updateLocomotionAnim(0.2);


            this._updateStatus(dt);

            // Charge Logic
// Charge Logic
            if (this.isCharging) {
                if (!this.hasBall || this.status.nap > 0 || this.stunTimer > 0) {
                    this.isCharging = false;
                    this.mesh.position.y = 0;
                    this.mesh.scale.setScalar(this.baseScale);
                    this._hideChargeUI();
                } else {
this.chargeTime += dt;
                    
                    // AUTO-RELEASE: If held too long (3s), force release to prevent stuck state
                    if (this.chargeTime > 3.0) {
                        this.releaseCharge(0, 0); // Force weak shot
                        return;
                    }

                    const ratio = Math.min(this.chargeTime / this.maxChargeTime, 1.0);
                    
                    // Levitation (Powering up)
                    const hover = (Math.sin(Date.now() * 0.02) * 0.1) + (ratio * 0.8);
                    
                    // Vibration (Intensity increases with charge)
                    const shake = 0.05 + (0.1 * ratio);
                    
                    // Apply Y offset (Hover + Jitter)
                    this.mesh.position.y = hover + (Math.random() - 0.5) * shake;
                    
                    // Apply Rotation Jitter (via banking/pitch variables)
                    // This avoids positional drift while giving a "struggling to contain power" look
                    this.bankingAmount += (Math.random() - 0.5) * shake;
                    this.pitchAmount += (Math.random() - 0.5) * shake;

                    // Ensure scale stays normal (Remove swelling effect)
                    this.mesh.scale.setScalar(this.baseScale);

                    this._updateChargeUI(ratio);
                }
            }
if (this.dashCooldown > 0) this.dashCooldown -= dt;
            if (this.clashCooldown > 0) this.clashCooldown -= dt;
            if (this.stunTimer > 0) this.stunTimer -= dt;
            if (this.immunityTimer > 0) this.immunityTimer -= dt;
            if (this.catchCooldown > 0) {
                this.catchCooldown -= dt;
                if (this.catchCooldown <= 0) this.canCatch = true;
            }
            // Dash Logic
// Dash Logic
            if (this.isDashing) {
                this.dashTime -= dt;
                
this._dashParticleTimer -= dt;
                if (this._dashParticleTimer <= 0) {
                    this._dashParticleTimer = 0.01; // Increased density (was 0.03)
                    if (window.flux.gameInstance && window.flux.gameInstance.particleManager) {
                        const back = this.velocity.clone().normalize().negate();
                        if (back.lengthSq() < 0.1) back.set(0, 0, 1);
                        
                        // Spawn multiple particles per tick for a "stream"
                        for(let i=0; i<2; i++) {
                            const pos = this.mesh.position.clone().add(back.multiplyScalar(0.5));
                            pos.y += 1.0 + (Math.random() - 0.5) * 0.5;
                            pos.x += (Math.random() - 0.5) * 0.5;
                            pos.z += (Math.random() - 0.5) * 0.5;
                            
                            window.flux.gameInstance.particleManager.spawn('dash_stream', pos, { scale: 2.0 + Math.random() });
                        }
                    }
                }

                // Smooth Rotation during Dash
                let diff = this.targetYaw - this.currentYaw;
                while (diff > Math.PI) diff -= Math.PI * 2;
                while (diff < -Math.PI) diff += Math.PI * 2;
                
                const turnSpeed = 15.0; // Fast turning for dash
                const change = Math.max(-turnSpeed * dt, Math.min(turnSpeed * dt, diff));
                this.currentYaw += change;

                this._checkTackleCollision();
                
                if (this.dashTime <= 0) {
                    this.isDashing = false;
                    this.mesh.position.y = 0;
                    this.dashType = null;
                } else {
                    if (this.dashType === 'vertical') {
                        _pVec.copy(this.dashVec).multiplyScalar(dt);
                        this.mesh.position.add(_pVec);
                        const t = 1 - (this.dashTime / this.dashTotalTime);
                        this.mesh.position.y = Math.sin(t * Math.PI) * 3.0;
                    } else {
                        // Horizontal Dash Movement
                        _pVec.copy(this.velocity).multiplyScalar(dt);
                        this.mesh.position.add(_pVec);
                        this.mesh.position.y = 0;

                        // Visual Tackle Lean (Shoulder Bash Animation)
                        const t = 1 - (this.dashTime / this.dashTotalTime); // 0 to 1
                        const lean = Math.sin(t * Math.PI); // Peak at 1.0 in middle
                        
                        // Re-apply base facing + Aggressive Shoulder Check
// Re-apply base facing + Aggressive Shoulder Check
                        _pQuat.setFromAxisAngle(_pAxisY, this.currentYaw + this.rotationOffset);
                        
                        let pitch = 0;
                        let yaw = 0;
                        let roll = 0;
                        let lungeAmt = 0;

                        if (this.dashType === 'horizontal' || this.dashType === 'break') {
                             // TACKLE/BREAK: Aggressive Shoulder Check
                             pitch = 1.2 * lean; // Head down / Lean forward
                             yaw = 0.8 * lean;   // Turn shoulder into target
                             roll = -0.6 * lean; // Dip shoulder
                             lungeAmt = 0.8 * lean; // Thrust mesh forward visually
                        } else if (this.dashType === 'sprint') {
                             // SPRINT: Aerodynamic lean
                             pitch = 0.5 * lean; 
                             lungeAmt = 0.2 * lean;
                        }

                        // Apply Lunge (Visual Offset)
                        if (lungeAmt > 0) {
                             _pVec.set(0, 0, lungeAmt).applyQuaternion(_pQuat);
                             this.mesh.position.add(_pVec);
                        }

                        _pEuler.set(pitch, yaw, roll);
                        _pQuat2.setFromEuler(_pEuler);
                        this.mesh.quaternion.multiplyQuaternions(_pQuat, _pQuat2);

                        this.velocity.multiplyScalar(0.96);

                        this.velocity.multiplyScalar(0.96);
                    }
                }
                return;
            }
            // Stun/Nap Check
            if (this.status.nap > 0 || this.stunTimer > 0) {
                const dragFactor = Math.max(0, 1 - (2.0 * dt));
                this.velocity.multiplyScalar(dragFactor);

                _pVec.copy(this.velocity).multiplyScalar(dt);
                this.mesh.position.add(_pVec);

                if (!this._animLocked && this.state !== 'idle' && this.state !== 'catch') this.play('idle', 0.5);

                this._updateHPBar();
                this._updatePassTargetIndicators();
                return;
            }

            this._checkTacklePressure(dt);

            if (this.isThrowing) {
                this.velocity.multiplyScalar(Math.max(0, 1.0 - (2.0 * dt)));

                this._applySoftCollision(dt);
                this._applyGoalCrease(dt);

                _pVec.copy(this.velocity).multiplyScalar(dt);
                this.mesh.position.add(_pVec);

this._updateVerticality(dt);
                this._updateBanking(dt); // Enable rotation during throw

            } else {
                this._updatePhysics(dt);
                this._updateVerticality(dt);
                this._updateBanking(dt);
            }

this._updateHPBar();
            this._updatePassTargetIndicators();

            // Bubble Trail Logic
// Bubble Trail Logic (Dynamic)
            const speedSq = this.velocity.lengthSq();
            if (speedSq > 1.0 && window.flux.gameInstance && window.flux.gameInstance.particleManager) {
                this._bubbleTimer -= dt;
                if (this._bubbleTimer <= 0) {
                    const pm = window.flux.gameInstance.particleManager;
                    const backDir = this.velocity.clone().normalize().negate();
                    
                    // 1. Standard Wake (Always spawn)
                    const offset = backDir.clone().multiplyScalar(0.8);
                    offset.y = 0.5 + Math.random() * 0.5; 
                    offset.x += (Math.random()-0.5) * 0.5;
                    offset.z += (Math.random()-0.5) * 0.5;
                    pm.spawn('bubble', this.mesh.position.clone().add(offset), { scale: 0.15 + Math.random() * 0.25 });

                    // 2. Cavitation (High Speed) - Add on top
                    const isHighSpeed = speedSq > 40.0; 
                    if (isHighSpeed) {
                        for(let i=0; i<3; i++) {
                            const mOffset = backDir.clone().multiplyScalar(0.5 + Math.random()*0.5);
                            mOffset.x += (Math.random()-0.5)*0.8;
                            mOffset.y = 0.5 + (Math.random()-0.5)*0.8; 
                            mOffset.z += (Math.random()-0.5)*0.8;
                            
                            pm.spawn('bubble_micro', this.mesh.position.clone().add(mOffset), { scale: 0.06 + Math.random()*0.08 });
                        }
                        this._bubbleTimer = 0.03; 
                    } else {
                        this._bubbleTimer = 0.1; 
                    }
                }
            }
            // Procedural 'alive' pose: look/aim/ball-hold offsets (applied after mixer update)
            this._applyProceduralPose(dt);

}


_applyProceduralPose(dt) {
    if (!this.mesh) return;

    // Advance local time (used for subtle sways)
    this._procAnimTime += dt;

    const b = this.bones;
    if (!b) return;

    const game = window.flux.gameInstance;
    const ball = (game && game.entities) ? game.entities.ball : null;

    let shouldApply = false;

    // Build a desired world-space direction we want the torso/head to bias toward.
    // NOTE: We apply this AFTER the animation mixer has posed bones, as a small additive offset.
    _pVec.set(0, 0, 1).applyQuaternion(this.mesh.quaternion).normalize();

    if (this.hasBall) {
        // Aim direction (prefer explicit aim vector)
        if (this.overrideAimVector) {
            _pVec.copy(this.overrideAimVector).normalize();
        } else if (this.lockedAimVector) {
            _pVec.copy(this.lockedAimVector).normalize();
        } else if (this.inputVector && this.inputVector.lengthSq() > 0.08) {
            _pVec.copy(this.inputVector).normalize();
        } else {
            _pVec.set(0, 0, 1).applyQuaternion(this.mesh.quaternion).normalize();
        }
        shouldApply = true;
    } else if (ball && ball.mesh) {
        // Look at the ball if it's in the "awareness" radius
        const dist = this.mesh.position.distanceTo(ball.mesh.position);
        if (dist < 20.0) {
            _pVec.subVectors(ball.mesh.position, this.mesh.position);
            shouldApply = true;
        }
    }

    if (!shouldApply) return;

    // Convert the direction into the player's local space so yaw/pitch are stable.
    _pInvQuat.copy(this.mesh.quaternion).invert();
    _pVec.applyQuaternion(_pInvQuat).normalize();

    const lx = _pVec.x, ly = _pVec.y, lz = _pVec.z;
    const yaw = Math.atan2(lx, lz);
    const pitch = Math.atan2(ly, Math.sqrt(lx * lx + lz * lz) + 1e-6);

    const yawC = THREE.MathUtils.clamp(yaw, -0.9, 0.9);
    const pitchC = THREE.MathUtils.clamp(pitch, -0.6, 0.6);

    const speedNorm = (this.maxSpeed > 0.0001) ? THREE.MathUtils.clamp(this._smoothedSpeed / this.maxSpeed, 0, 1) : 0;
    const aimW = (this.hasBall ? (this.isCharging ? 1.0 : 0.65) : 0.35) * (1.0 - 0.35 * speedNorm);
    const headW = (this.hasBall ? 0.55 : 0.75) * (1.0 - 0.25 * speedNorm);

    // Torso bias (spine/chest)
    if (b.chest) {
        _pTmpEuler.set(-pitchC * 0.20 * aimW, yawC * 0.35 * aimW, 0);
        _pTmpQuat.setFromEuler(_pTmpEuler);
        b.chest.quaternion.multiply(_pTmpQuat);
    } else if (b.spine) {
        _pTmpEuler.set(-pitchC * 0.15 * aimW, yawC * 0.25 * aimW, 0);
        _pTmpQuat.setFromEuler(_pTmpEuler);
        b.spine.quaternion.multiply(_pTmpQuat);
    }

    // Head/neck look
    if (b.neck) {
        _pTmpEuler.set(-pitchC * 0.25 * headW, yawC * 0.45 * headW, 0);
        _pTmpQuat.setFromEuler(_pTmpEuler);
        b.neck.quaternion.multiply(_pTmpQuat);
    }
    if (b.head) {
        _pTmpEuler.set(-pitchC * 0.30 * headW, yawC * 0.55 * headW, 0);
        _pTmpQuat.setFromEuler(_pTmpEuler);
        b.head.quaternion.multiply(_pTmpQuat);
    }

    // Ball-hold / aim arm pose (keeps "swim" animation but reads as holding/aiming)
    if (this.hasBall && !this.isThrowing && !this._animLocked) {
        const t = this._procAnimTime;
        const lift = THREE.MathUtils.clamp(0.35 + (this.isCharging ? 0.55 : 0.25) - speedNorm * 0.2, 0.15, 0.95);
        const sway = Math.sin(t * 5.0) * 0.05 * (0.5 + lift);

        const raiseX = -0.55 * lift + sway;
        const raiseZ = -0.25 * lift;

        if (b.rUpperArm) {
            _pTmpEuler.set(raiseX, yawC * 0.10 * lift, raiseZ);
            _pTmpQuat.setFromEuler(_pTmpEuler);
            b.rUpperArm.quaternion.multiply(_pTmpQuat);
        }
        if (b.rForeArm) {
            _pTmpEuler.set(-0.35 * lift + sway * 0.5, 0, 0);
            _pTmpQuat.setFromEuler(_pTmpEuler);
            b.rForeArm.quaternion.multiply(_pTmpQuat);
        }

        // Counterbalance left arm slightly for a more dynamic silhouette
        if (b.lUpperArm) {
            _pTmpEuler.set(0.15 * lift, -yawC * 0.05 * lift, 0.15 * lift);
            _pTmpQuat.setFromEuler(_pTmpEuler);
            b.lUpperArm.quaternion.multiply(_pTmpQuat);
        }
    }
}


        _updateStatus(dt) {
            const pm = window.flux.gameInstance ? window.flux.gameInstance.particleManager : null;

            if (this.status.venom > 0) {
                this.status.venom -= dt;
                this.stats.HP -= 5 * dt;
                if (this.stats.HP < 0) this.stats.HP = 0;

                this._particleTimers.venom -= dt;
                if (this._particleTimers.venom <= 0 && pm) {
                    pm.spawn('venom', this.mesh.position);
                    this._particleTimers.venom = 0.15;
                }
            } else {
                if (!this.hasBall && this.stats.HP < this.stats.maxHP) {
                    this.stats.HP += 5 * dt;
                    if (this.stats.HP > this.stats.maxHP) this.stats.HP = this.stats.maxHP;
                }
            }

            if (this.hasBall) {
                this.stats.HP -= 2.0 * dt;
                if (this.stats.HP < 0) this.stats.HP = 0;
            }

            if (this.status.nap > 0) {
                this.status.nap -= dt;

                this._particleTimers.nap -= dt;
                if (this._particleTimers.nap <= 0 && pm) {
                    pm.spawn('nap', this.mesh.position);
                    this._particleTimers.nap = 0.8;
                }
            }

            let isWithering = false;
            for (let key in this.status.wither) {
                if (this.status.wither[key] > 0) {
                    this.status.wither[key] -= dt;
                    isWithering = true;
                }
            }

            if (isWithering) {
                this._particleTimers.wither -= dt;
                if (this._particleTimers.wither <= 0 && pm) {
                    pm.spawn('wither', this.mesh.position);
                    this._particleTimers.wither = 0.2;
                }
            }

            this._updateVisuals();
        }

_updateVisuals() {
            // REMOVED: Yellow sphere/tint logic as per request.
            // Always revert to base color.
            this.originalMaterials.forEach(entry => {
                entry.material.color.copy(entry.baseColor);
            });
        }

        _createAura() {
            // Aura removed per user request
            this.auraMesh = null;
        }

        // NEW: Pass target indicator
        _createPassTargetIndicator() {
            // Create a ring that highlights potential pass targets
            const geo = new THREE.RingGeometry(0.8, 1.0, 16);
            const mat = new THREE.MeshBasicMaterial({
                color: 0x00ff00,
                transparent: true,
                opacity: 0.6,
                side: THREE.DoubleSide
            });
            this.passTargetIndicator = new THREE.Mesh(geo, mat);
            this.passTargetIndicator.rotation.x = -Math.PI / 2;
            this.passTargetIndicator.position.y = 0.1;
            this.passTargetIndicator.visible = false;
            this.scene.add(this.passTargetIndicator);
        }

        _updatePassTargetIndicators() {
            if (!this.hasBall || !this.team) {
                this._hidePassTargetIndicators();
                return;
            }

            // Find best pass target
            const aimDir = new THREE.Vector3(0, 0, 1).applyQuaternion(this.mesh.quaternion);
            const target = this._findPassTargetInCone(aimDir);

            if (target && target.mesh && this.passTargetIndicator) {
                this.passTargetIndicator.visible = true;
                this.passTargetIndicator.position.x = target.mesh.position.x;
                this.passTargetIndicator.position.z = target.mesh.position.z;
                this.passTargetIndicator.position.y = 0.1;
                this.passTargetIndicator.rotation.z += 0.05;
            } else {
                this._hidePassTargetIndicators();
            }
        }

        _hidePassTargetIndicators() {
            if (this.passTargetIndicator) {
                this.passTargetIndicator.visible = false;
            }
        }

_applySoftCollision(dt) {
            if (!this.mesh || !window.flux.gameInstance) return;

            const game = window.flux.gameInstance;
            const teams = [game.teams.home, game.teams.away];

            const repulsionRadius = 0.5; // Reduced to 0.5 to fix invisible wall issues
            const stiffness = 15.0;

            teams.forEach(team => {
                if (!team) return;
                team.players.forEach(other => {
                    if (other === this || !other.mesh) return;

                    const dx = this.mesh.position.x - other.mesh.position.x;
                    const dy = this.mesh.position.y - other.mesh.position.y;
                    const dz = this.mesh.position.z - other.mesh.position.z;

                    const distSq = dx*dx + dy*dy + dz*dz;
                    const minDist = repulsionRadius * 2.0;

                    if (distSq < minDist * minDist && distSq > 0.0001) {
                        const dist = Math.sqrt(distSq);
                        const overlap = minDist - dist;

                        const force = overlap * stiffness;

                        const nx = dx / dist;
                        const ny = dy / dist;
                        const nz = dz / dist;

                        this.velocity.x += nx * force * dt;
                        this.velocity.y += ny * force * dt;
                        this.velocity.z += nz * force * dt;
                    }
                });
            });
        }

_updatePhysics(dt) {
            this._applySoftCollision(dt);
            this._applyGoalCrease(dt);

            const inputLenSq = this.inputVector.lengthSq();
            const isInputActive = inputLenSq > 0.01;

            let currentMaxSpeed = this.maxSpeed;
            
            // STRUGGLE STATE: Hinder movement based on pressure
            // Instead of a binary 0.8 multiplier, we scale based on intensity.
            // Max struggle (1.0) reduces speed to 40%.
            if (this.struggleIntensity > 0) {
                currentMaxSpeed *= (1.0 - (this.struggleIntensity * 0.6));
            } else if (this.isEngaged) {
                // Fallback slight reduction if engaged but low pressure
                currentMaxSpeed *= 0.9;
            }
            
            if (this.isCharging) currentMaxSpeed *= 0.9;

            if (isInputActive) {
                _pVec.copy(this.inputVector).normalize();

                // Apply Struggle Jitter to direction
                // Simulates wrestling for control
                if (this.struggleIntensity > 0.3) {
                    const jitter = (Math.random() - 0.5) * this.struggleIntensity * 0.8;
                    _pVec.x += jitter;
                    _pVec.z += jitter;
                    _pVec.normalize();
                }

                const targetVelX = _pVec.x * currentMaxSpeed;
                const targetVelZ = _pVec.z * currentMaxSpeed;

                const currentSpeed = this.velocity.length();
                const speedRatio = Math.min(1.0, currentSpeed / this.maxSpeed);

                // Agility is reduced when struggling
                let agility = THREE.MathUtils.lerp(10.0, 2.0, speedRatio);
                if (this.struggleIntensity > 0) agility *= 0.5;

                const t = 1.0 - Math.pow(0.01, dt * agility);

                this.velocity.x += (targetVelX - this.velocity.x) * t;
                this.velocity.z += (targetVelZ - this.velocity.z) * t;

            } else {
                const brakeFactor = 2.0;
                const t = 1.0 - Math.pow(0.1, dt * brakeFactor);

                this.velocity.x += (0 - this.velocity.x) * t;
                this.velocity.z += (0 - this.velocity.z) * t;

                if (this.velocity.lengthSq() < 0.01) {
                    this.velocity.set(0, this.velocity.y, 0);
                }
            }

            this.velocity.y *= Math.max(0, 1.0 - (2.0 * dt));

            _pVec.copy(this.velocity).multiplyScalar(dt);
            this.mesh.position.add(_pVec);
        }

        _updateVerticality(dt) {
            let targetY = 0;

            const ball = window.flux.gameInstance.entities.ball;

            if (ball && ball.mesh && !this.hasBall) {
                const distToBall = this.mesh.position.distanceTo(ball.mesh.position);
                if (distToBall < 15.0) {
                    targetY = ball.mesh.position.y;
                }
            }

            if (this.hasBall) {
                targetY = 0.5;
            }

            const yDiff = targetY - this.mesh.position.y;

            const lift = yDiff * 10.0 * dt;
            this.velocity.y += lift;

            if (this.mesh.position.y > 8.0) {
                this.mesh.position.y = 8.0;
                this.velocity.y *= -0.5;
            } else if (this.mesh.position.y < -8.0) {
                this.mesh.position.y = -8.0;
                this.velocity.y *= -0.5;
            }
        }

        // FIXED: Improved banking with hysteresis to prevent facing flips
// FIXED: Improved banking with hysteresis to prevent facing flips
        _updateBanking(dt) {
            const inputLenSq = this.inputVector.lengthSq();
            const velLenSq = this.velocity.lengthSq();

            let targetYaw = this.targetYaw;
            let shouldUpdateYaw = false;

            // PRIORITY 1: Explicit Aim (Aim Stick / Swipe)
            if (this.overrideAimVector) {
                targetYaw = Math.atan2(this.overrideAimVector.x, this.overrideAimVector.z);
                shouldUpdateYaw = true;
            }
            // PRIORITY 2: Movement Input
            else if (inputLenSq > this.facingDeadzone * this.facingDeadzone) {
                targetYaw = Math.atan2(this.inputVector.x, this.inputVector.z);
                shouldUpdateYaw = true;
            } 
            // PRIORITY 3: Velocity (Drifting)
            else if (velLenSq > this.facingDeadzone * this.facingDeadzone) {
                targetYaw = Math.atan2(this.velocity.x, this.velocity.z);
                shouldUpdateYaw = true;
            }

            // If we should update, do so. Otherwise keep last valid yaw
            if (shouldUpdateYaw) {
                this.lastValidYaw = targetYaw;
            } else {
                targetYaw = this.lastValidYaw;
            }

            // Smooth Yaw with wrap-around handling
            let diff = targetYaw - this.currentYaw;
            while (diff > Math.PI) diff -= Math.PI * 2;
            while (diff < -Math.PI) diff += Math.PI * 2;

            const speedRatio = Math.min(1.0, this.velocity.length() / this.maxSpeed);
const turnSpeed = THREE.MathUtils.lerp(8.0, 4.0, speedRatio); // Reduced from 12.0/6.0 to reduce flipping

            // Prevent sudden snaps when diff is very large (teleport/reset scenarios)
            const maxYawChange = Math.PI * dt * turnSpeed;
            const yawChange = Math.max(-maxYawChange, Math.min(maxYawChange, diff * dt * turnSpeed));

            this.currentYaw += yawChange;
            this.targetYaw = targetYaw;

            // Banking
            const bankSensitivity = 0.8;
            const maxBank = 0.75;

            let targetBank = -diff * bankSensitivity;
            targetBank = Math.max(-maxBank, Math.min(maxBank, targetBank));

            const bankLerp = 1.0 - Math.pow(0.02, dt);
            this.bankingAmount += (targetBank - this.bankingAmount) * bankLerp;

            // Pitch
            const pitchSensitivity = 0.1;
            const maxPitch = 1.0;

            let targetPitch = -this.velocity.y * pitchSensitivity;
            targetPitch = Math.max(-maxPitch, Math.min(maxPitch, targetPitch));

            const pitchLerp = 1.0 - Math.pow(0.05, dt);
            this.pitchAmount += (targetPitch - this.pitchAmount) * pitchLerp;

            // Apply Rotation
            const finalYaw = this.currentYaw + this.rotationOffset;

            this.mesh.quaternion.setFromAxisAngle(_pAxisY, finalYaw);

            _pQuat.setFromAxisAngle(new THREE.Vector3(1, 0, 0), this.pitchAmount);
            this.mesh.quaternion.multiply(_pQuat);

            _pQuat.setFromAxisAngle(new THREE.Vector3(0, 0, 1), this.bankingAmount);
            this.mesh.quaternion.multiply(_pQuat);

            // Idle Bob
            if (velLenSq < 0.1 && !this.isEngaged) {
                const time = Date.now() * 0.0015;
                const bobPitch = Math.sin(time) * 0.03;
                const bobRoll = Math.cos(time * 0.7) * 0.02;

_pEuler.set(bobPitch, 0, bobRoll);
                _pQuat.setFromEuler(_pEuler);
                this.mesh.quaternion.multiply(_pQuat);
            }
        }

_checkTacklePressure(dt) {
            this.struggleIntensity = 0;
            
            if (!this.hasBall) {
                this.isEngaged = false;
                this.encounterTimer = 0;
                return;
            }

            if (this.immunityTimer > 0) return;
            if (this.isDashing) return;

            const game = window.flux.gameInstance;
            if (!game || !this.team) return;

            const opponentTeamId = this.team.id === 'home' ? 'away' : 'home';
            const opponentTeam = game.teams[opponentTeamId];
            if (!opponentTeam) return;

            let totalPressure = 0;
            let engagedCount = 0;
            const effectiveRadius = this.tackleRadius; 

            // Forward vector for shielding check
            _pVec.copy(_pAxisZ).applyQuaternion(this.mesh.quaternion); 

            for (const entity of opponentTeam.players) {
                if (!entity.mesh || entity.status.nap > 0 || entity.stunTimer > 0) continue;
                
                const dist = this.mesh.position.distanceTo(entity.mesh.position);
                if (dist < effectiveRadius) {
                    engagedCount++;
                    
                    // Calculate Pressure Intensity (0 to 1 based on distance)
                    const proximity = 1.0 - (dist / effectiveRadius);
                    
                    // Base Pressure from AT stat
                    let pressure = entity.getStat('AT') * proximity;

                    // Directional Shielding (Continuous)
                    const toOpp = entity.mesh.position.clone().sub(this.mesh.position).normalize();
                    const dot = _pVec.dot(toOpp);
                    
                    // If opponent is BEHIND (dot < -0.2), pressure is reduced (Shielding)
                    let isShielded = false;
                    if (dot < -0.2) {
                        pressure *= 0.5;
                        isShielded = true;
                    }

                    // Tech Modifiers (Continuous application chance)
                    if (entity.techs.tackle === 'venom') {
                        if (Math.random() < dt * 0.5) this.applyStatus('venom', 5.0);
                        pressure *= 1.2;
                    } else if (entity.techs.tackle === 'wither') {
                        if (Math.random() < dt * 0.5) this.applyStatus('wither', 5.0, 'EN');
                        pressure *= 1.2;
                    } else if (entity.techs.tackle === 'drain') {
                        const drainAmt = pressure * dt * 0.5;
                        this.stats.HP -= drainAmt;
                        entity.stats.HP += drainAmt;
                    }

                    totalPressure += pressure;

                    // Visuals: Sparks occasionally based on pressure
                    if (Math.random() < dt * 4.0 * proximity) { 
                         if (game.spawnClash) {
                            const mid = this.mesh.position.clone().lerp(entity.mesh.position, 0.5);
                            mid.y += 1.0;
                            game.spawnClash(mid, 0.5);
                        }
                    }
                    
                    // Occasional Shield Text
                    if (isShielded && Math.random() < dt * 1.0 && game.floatingText) {
                        // game.floatingText.spawn("SHIELD", this.mesh.position, "block"); // Too spammy, maybe just sound later
                    }
                }
            }

            this.isEngaged = (engagedCount > 0);

            if (this.isEngaged) {
                this.encounterTimer += dt;

                // Apply EN Drain (Continuous)
                // Scaling: 20 AT pressure -> approx 10 EN lost per second
                const drainRate = totalPressure * 0.5; 
                this.currentEN -= drainRate * dt;
                
                // Update Struggle Intensity for Physics (0.0 to 1.0)
                // Max struggle at roughly 30 pressure
                this.struggleIntensity = Math.min(1.0, totalPressure / 30.0);

                // Visual Feedback for Drain (Accumulate to avoid spam)
                this._accumulatedDamage += drainRate * dt;
                if (this._accumulatedDamage > 5.0) {
                    if (game.floatingText) {
                        game.floatingText.spawn(`-${Math.floor(this._accumulatedDamage)}`, this.mesh.position, "damage");
                    }
                    this._accumulatedDamage = 0;
                }
                
                // Hint for player if engaged too long
                if (this.encounterTimer > 1.0 && this.encounterTimer < 1.1 && this.team.isHuman && this.team.activePlayer === this) {
                     if (game.floatingText) game.floatingText.spawn("BREAK!", this.mesh.position, "tech");
                }
            } else {
                this.encounterTimer = 0;
            }

            if (this.currentEN <= 0) {
                this.fumble();
            }
        }

        _performJechtKnockback() {
            if (!this.team) return;
            const game = window.flux.gameInstance;
            const opponentTeamId = this.team.id === 'home' ? 'away' : 'home';
            const opponentTeam = game.teams[opponentTeamId];

            if (!opponentTeam) return;

            const range = 6.0;
            const force = 25.0;

            if (game.floatingText) {
                game.floatingText.spawn("JECHT SHOT!", this.mesh.position, "goal");
            }

            opponentTeam.players.forEach(p => {
                if (!p.mesh) return;
                const dist = this.mesh.position.distanceTo(p.mesh.position);
                if (dist < range) {
                    const dir = p.mesh.position.clone().sub(this.mesh.position).normalize();
                    dir.y = 0.5;
                    dir.normalize();

p.velocity.add(dir.multiplyScalar(force));

                    p.stunTimer = 2.0; // Ensure they stay down
                    p.isDashing = false;
                    const reactAction = p.actions && p.actions['react'];
                    if (reactAction) {
                        reactAction.setLoop(THREE.LoopOnce);
                        reactAction.clampWhenFinished = true;
                        p.playOneShot('react', 0.1);
} else {
                        p.play('catch', 0.5);
                    }

                    if (game.floatingText) {
                        game.floatingText.spawn("SMACK!", p.mesh.position, "damage");
                    }
                    if (game.triggerImpact) game.triggerImpact(0.15, 'shatter');
                }
            });
        }

        fumble() {
            console.log("FUMBLE! EN Depleted.");
            if (window.flux.gameInstance.floatingText && this.mesh) {
                window.flux.gameInstance.floatingText.spawn("CRASH!", this.mesh.position, "comic-impact");
            }

            this.stunTimer = 1.5;

            const backDir = new THREE.Vector3(0, 0, 1).applyQuaternion(this.mesh.quaternion).normalize().negate();
            backDir.x += (Math.random() - 0.5) * 0.5;
            backDir.z += (Math.random() - 0.5) * 0.5;
            backDir.normalize();

            this.velocity.add(backDir.multiplyScalar(12.0));

            if (this.hasBall) {
                const ball = window.flux.gameInstance.entities.ball;
                if (ball) {
                    const ejectDir = new THREE.Vector3(Math.random()-0.5, 0.8, Math.random()-0.5).normalize();
                    ball.shoot(ejectDir, 6.0, 'none');
this.loseBall();
                    this.canCatch = false;

                    this.currentEN = 0;
                }
            }
        }

        dash(x, z) {
            if (this.isDashing || this.dashCooldown > 0) return;
            if (this.status.nap > 0) return;

            // OFFENSE: BREAK TACKLE
            if (this.hasBall && this.isEngaged) {
                const cost = 15;

                if (this.currentEN < cost) {
                    if (window.flux.gameInstance.floatingText) {
                        window.flux.gameInstance.floatingText.spawn("FAILED!", this.mesh.position, "damage");
                    }
                    this.fumble();
                    return;
                }

                this.currentEN -= cost;
                this.isDashing = true;
                this.dashTime = 0.4;
                this.dashCooldown = 2.0;
                this.dashType = 'break';

_pVec.set(0, 0, 1).applyQuaternion(this.mesh.quaternion);
this.velocity.add(_pVec.multiplyScalar(10.0)); // Nerfed from 15.0 for realism

                const game = window.flux.gameInstance;
                const opponentTeamId = this.team.id === 'home' ? 'away' : 'home';
                const opponentTeam = game.teams[opponentTeamId];

                opponentTeam.players.forEach(p => {
                    if (!p.mesh) return;
                    const dist = this.mesh.position.distanceTo(p.mesh.position);
                    if (dist < this.tackleRadius * 1.5) {
                        const pushDir = p.mesh.position.clone().sub(this.mesh.position).normalize();
                        pushDir.y = 0.5;
                        p.velocity.add(pushDir.multiplyScalar(15.0));

                        p.stunTimer = 2.0;
                        p.play('catch', 0.2);

                        if (game.floatingText) {
                            game.floatingText.spawn("STUN!", p.mesh.position, "damage");
                        }
                    }
                });

if (game.floatingText) {
                    game.floatingText.spawn("BREAK!", this.mesh.position, "tech");
                }
                
// NEW: Spawn Break Glyph (Explosive Burst)
                if (game.glyphManager) {
                    game.glyphManager.spawn('status', this.mesh.position, {
                        parent: this,
                        life: 0.5,
                        rotationSpeed: 8.0,
                        scaleSpeed: 3.0,
                        offsetY: 0.5
                    });
                }
                
// Particle Burst (Break Tackle)
                if (game.particleManager) {
                    game.particleManager.spawn('shockwave', this.mesh.position, { scale: 2.0, life: 0.3 });
                    game.particleManager.spawn('flash', this.mesh.position, { scale: 2.5 });
                    // Bubble Burst
                    for(let i=0; i<30; i++) {
const bPos = this.mesh.position.clone().add(_pVec.set((Math.random()-0.5), 1.0+(Math.random()-0.5), (Math.random()-0.5)));
                    game.particleManager.spawn('bubble', bPos, { scale: 0.2 + Math.random() * 0.4 });
                    }
                }

                if (game.triggerImpact) game.triggerImpact(0.15, 'heavy');

                return;
            }

            // OFFENSE: SPRINT
            if (this.hasBall) {
                const cost = 5;
                if (this.currentEN < cost) {
                    if (window.flux.gameInstance.floatingText) {
                        window.flux.gameInstance.floatingText.spawn("NO EN!", this.mesh.position, "damage");
                    }
                    return;
                }

                this.currentEN -= cost;
                this.isDashing = true;
                this.dashTime = 0.4;
                this.dashCooldown = 1.5;
                this.dashType = 'sprint';

const burstDir = this.velocity.clone().normalize();
                if (burstDir.lengthSq() < 0.1) burstDir.set(0, 0, 1).applyQuaternion(this.mesh.quaternion);

this.velocity.add(burstDir.multiplyScalar(12.0)); // Nerfed from 15.0

                if (window.flux.gameInstance.cameraManager) {
                    window.flux.gameInstance.cameraManager.addFovImpulse(20);
                }
                if (window.flux.gameInstance.floatingText) {
                    window.flux.gameInstance.floatingText.spawn("DASH!", this.mesh.position, "tech");
                }
                return;
            }

            // DEFENSE: BLOCK / TACKLE
            const ball = window.flux.gameInstance.entities.ball;
            let isBlockContext = false;
            if (ball && ball.mesh) {
                const dist = this.mesh.position.distanceTo(ball.mesh.position);
                if (dist < 8.0 && ball.mesh.position.y > 2.5) {
                    isBlockContext = true;
                }
            }

            this.isDashing = true;
            this.dashTime = this.dashTotalTime;
            this.dashCooldown = 1.5;

            const len = Math.sqrt(x*x + z*z);
            const nx = (len > 0) ? x/len : 0;
            const nz = (len > 0) ? z/len : 0;

if (len > 0) {
                // Smooth turn for dash instead of snap
                this.targetYaw = Math.atan2(nx, nz);
            }
            if (isBlockContext) {
                this.dashType = 'vertical';

                const dirToBall = ball.mesh.position.clone().sub(this.mesh.position);
                dirToBall.y = 0;

                if (dirToBall.lengthSq() > 0.01) {
                    dirToBall.normalize();
                    this.dashVec.copy(dirToBall).multiplyScalar(8.0);
                } else {
                    this.dashVec.set(0, 0, 0);
                }

                const catchAction = this.actions['catch'];
                if (catchAction) {
                    catchAction.setLoop(THREE.LoopOnce);
                    catchAction.clampWhenFinished = true;
                    catchAction.timeScale = 1.5;
                }
                this.play('catch', 0.1);

                if (window.flux.gameInstance.floatingText) {
                    window.flux.gameInstance.floatingText.spawn("BLOCK!", this.mesh.position, "default");
                }

            } else {
                this.dashType = 'horizontal';
                this._hasHitTackle = false;

                // Apply velocity impulse in dash direction
// Apply velocity impulse in dash direction
                _pVec.set(nx, 0, nz);
                if (_pVec.lengthSq() < 0.1) {
                    _pVec.set(0, 0, 1).applyQuaternion(this.mesh.quaternion);
                }
this.velocity.add(_pVec.multiplyScalar(14.0)); // Nerfed from 20.0

                const lungeAction = this.actions['throw'];
                if (lungeAction) {
                    lungeAction.setLoop(THREE.LoopOnce);
                    lungeAction.clampWhenFinished = true;
                    lungeAction.timeScale = 2.0;
                }
                this.play('throw', 0.1);

                if (window.flux.gameInstance.triggerImpact) window.flux.gameInstance.triggerImpact(0.05, 'default');
            }

if (window.flux.gameInstance.cameraManager) {
                window.flux.gameInstance.cameraManager.addFovImpulse(10);
                window.flux.gameInstance.cameraManager.addShake(0.3); 
            }
            // Dash Effect
            if (window.flux.gameInstance.particleManager) {
                const dashPos = this.mesh.position.clone();
                dashPos.y += 1.0;
                window.flux.gameInstance.particleManager.spawn('shockwave', dashPos, { scale: 1.5, life: 0.3 });
                // Speed lines
                const back = this.velocity.clone().normalize().negate();
                for(let i=0; i<3; i++) {
                    const p = dashPos.clone().add(back.multiplyScalar(Math.random()));
                    p.x += (Math.random()-0.5);
                    window.flux.gameInstance.particleManager.spawn('dash_stream', p, { scale: 1.5 });
                }
            }
        }

        _createHPBar() {
            const container = new THREE.Group();

            const bgGeo = new THREE.PlaneGeometry(1.2, 0.15);
            const bgMat = new THREE.MeshBasicMaterial({ color: 0x000000, side: THREE.DoubleSide, depthTest: false });
            const bg = new THREE.Mesh(bgGeo, bgMat);
            container.add(bg);

            const fillGeo = new THREE.PlaneGeometry(1.16, 0.11);
            fillGeo.translate(0.58, 0, 0);
            const fillMat = new THREE.MeshBasicMaterial({ color: 0x00ff00, side: THREE.DoubleSide, depthTest: false });
            this.hpBarFill = new THREE.Mesh(fillGeo, fillMat);
            this.hpBarFill.position.set(-0.58, 0, 0.01);
            container.add(this.hpBarFill);

            this.hpBar = container;
            this.scene.add(this.hpBar);
        }

_updateHPBar() {
            if (!this.hpBar || !this.mesh) return;

            // Visibility Check: Only show in Active/Practice states
            const game = window.flux.gameInstance;
            const allowedState = game && (game.state === 'active' || game.state === 'kickoff');
            
            if (!allowedState) {
                this.hpBar.visible = false;
                return;
            }

            this.hpBar.position.copy(this.mesh.position);
            this.hpBar.position.y += 2.2;

            if (window.flux.gameInstance && window.flux.gameInstance.camera) {
                this.hpBar.lookAt(window.flux.gameInstance.camera.position);
            }

            const pct = Math.max(0, this.stats.HP / this.stats.maxHP);
            this.hpBarFill.scale.setX(pct);

            if (pct > 0.5) this.hpBarFill.material.color.setHex(0x00ff00);
            else if (pct > 0.25) this.hpBarFill.material.color.setHex(0xffff00);
            else this.hpBarFill.material.color.setHex(0xff0000);

            // Hide if full HP to reduce clutter, unless in practice mode
            const alwaysShow = game && game.gameMode === 'practice';
            this.hpBar.visible = (pct < 0.98 || alwaysShow);
        }

        gainExp(amount) {
            if (!window.flux.gameInstance || window.flux.gameInstance.state !== 'active') return;

            this.exp += amount;

            if (this.exp >= this.nextLevelExp) {
                this.levelUp();
            }
        }

        levelUp() {
            this.level++;
            this.exp -= this.nextLevelExp;
            this.nextLevelExp = Math.floor(this.nextLevelExp * 1.5);

            const keys = ['HP', 'EN', 'AT', 'PA', 'BL', 'SH', 'CA', 'SP'];

            const hpGain = Math.floor(Math.random() * 20) + 10;
            this.stats.maxHP += hpGain;
            this.stats.HP = this.stats.maxHP;

            keys.forEach(k => {
                if (k === 'HP') return;
                if (Math.random() > 0.4) {
                    const gain = Math.floor(Math.random() * 2) + 1;
                    this.stats[k] += gain;
                }
            });

            this._updateDerivedStats();

            console.log(`${this.role} reached Level ${this.level}!`);

            if (window.flux.gameInstance.floatingText && this.mesh) {
                window.flux.gameInstance.floatingText.spawn("LEVEL UP!", this.mesh.position, "tech");
            }
        }

        _checkTackleCollision() {
            if (!this.team || this._hasHitTackle) return;

            const game = window.flux.gameInstance;
            if (!game) return;

            const opponentTeamId = this.team.id === 'home' ? 'away' : 'home';
            const opponentTeam = game.teams[opponentTeamId];

            for (const opp of opponentTeam.players) {
                if (!opp.mesh) continue;
                const dist = this.mesh.position.distanceTo(opp.mesh.position);

if (dist < 3.0) { // Increased from 2.0 for easier hits
                    this._resolveTackleHit(opp);
                    this._hasHitTackle = true;
                    return;
                }
            }
        }

        _resolveTackleHit(opp) {
            this.isDashing = false;
            this.velocity.multiplyScalar(-0.5);
            this.play('idle', 0.2);

            const at = this.getStat('AT');
            let damage = at * 3.0;

            if (this.techs.tackle === 'venom') {
                opp.applyStatus('venom', 10.0);
                damage += 5;
            } else if (this.techs.tackle === 'wither') {
                opp.applyStatus('wither', 10.0, 'EN');
                damage += 5;
            } else if (this.techs.tackle === 'drain') {
                this.stats.HP += 20;
                opp.stats.HP -= 20;
                if (window.flux.gameInstance.floatingText)
                    window.flux.gameInstance.floatingText.spawn("DRAIN", this.mesh.position, "heal");
            }

            if (opp.hasBall) {
                opp.currentEN -= damage;

if (window.flux.gameInstance.floatingText) {
                    // Removed "EN" suffix for cleaner look
                    window.flux.gameInstance.floatingText.spawn(`${Math.floor(damage)}`, opp.mesh.position, "damage");
                    window.flux.gameInstance.floatingText.spawn("BAM!", opp.mesh.position, "comic-impact");
                }

                if (opp.currentEN <= 0) {
                    opp.fumble();
                } else {
                    opp.stunTimer = 0.5;
                    opp.playOneShot('react', 0.1);
}

                if (this.techs.tackle && window.flux.gameInstance.triggerTechEvent) {
                    window.flux.gameInstance.triggerTechEvent(this, this.techs.tackle);
                }

            } else {
                opp.stunTimer = 1.0;
                opp.playOneShot('react', 0.1);
if (window.flux.gameInstance.floatingText) {
                    window.flux.gameInstance.floatingText.spawn("SMACK!", opp.mesh.position, "comic-impact");
                }
            }

            const pushDir = opp.mesh.position.clone().sub(this.mesh.position).normalize();
            pushDir.y = 0.2;
            opp.velocity.add(pushDir.multiplyScalar(12.0));

            if (window.flux.gameInstance.triggerImpact) window.flux.gameInstance.triggerImpact(0.1, 'heavy');
            if (window.flux.gameInstance.cameraManager) window.flux.gameInstance.cameraManager.addShake(0.8);
            if (window.flux.gameInstance.spawnClash) {
const mid = this.mesh.position.clone().add(opp.mesh.position).multiplyScalar(0.5);
                window.flux.gameInstance.spawnClash(mid);
            }
            
// Bubble Burst (Tackle Hit)
// Bubble Burst (Tackle Hit)
            if (window.flux.gameInstance.particleManager) {
                const mid = this.mesh.position.clone().lerp(opp.mesh.position, 0.5);
                mid.y += 1.0;
                for(let i=0; i<30; i++) {
                    const bubblePos = mid.clone().add(new THREE.Vector3((Math.random()-0.5)*1.5, (Math.random()-0.5)*1.5, (Math.random()-0.5)*1.5));
                    window.flux.gameInstance.particleManager.spawn('bubble', bubblePos, { scale: 0.15 + Math.random() * 0.35 });
                }
            }
        }

        _applyGoalCrease(dt) {

            const goals = [

                new THREE.Vector3(0, 0, 46),
                new THREE.Vector3(0, 0, -46)
            ];

            const radius = 10.0;

            goals.forEach(goal => {
                const dx = this.mesh.position.x - goal.x;
                const dz = this.mesh.position.z - goal.z;
                const distSq = dx*dx + dz*dz;

                if (distSq < radius * radius) {
                    const dist = Math.sqrt(distSq);
                    const pushX = dist > 0 ? dx / dist : 1;
                    const pushZ = dist > 0 ? dz / dist : 0;

                    const force = 50.0;
                    this.velocity.x += pushX * force * dt;
                    this.velocity.z += pushZ * force * dt;

                    if (dist < radius - 0.5) {
                        const clampRatio = radius / (dist + 0.001);
                        this.mesh.position.x = goal.x + dx * clampRatio;
                        this.mesh.position.z = goal.z + dz * clampRatio;
                    }
                }
            });
        }
    }

    window.flux.Player = Player;
})();
