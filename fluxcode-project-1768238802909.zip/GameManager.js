(function() {
    window.flux = window.flux || {};

// Spark Texture (Procedural Burst)
    const _sparkTexture = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        ctx.clearRect(0,0,64,64);
        
        // Burst shape
        const cx = 32, cy = 32;
        const spikes = 8;
        const outer = 30;
        const inner = 10;
        
        ctx.beginPath();
        for(let i=0; i<spikes*2; i++){
            const r = (i%2===0)? outer : inner;
            const a = (Math.PI*i)/spikes;
            ctx.lineTo(cx + Math.cos(a)*r, cy + Math.sin(a)*r);
        }
        ctx.closePath();
        ctx.fillStyle = '#ffcc00';
        ctx.fill();
        
        // White Core
        ctx.beginPath();
        ctx.arc(cx, cy, 8, 0, Math.PI*2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        
        return new THREE.CanvasTexture(c);
    })();

    const _sparkMaterial = new THREE.SpriteMaterial({ 
        map: _sparkTexture, 
        transparent: true, 
        blending: THREE.AdditiveBlending,
        depthWrite: false
    });

    class GameManager {

        
constructor(scene, uiLayerId, camera, renderer) {
window.flux.gameInstance = this;
            this.renderer = renderer; // Store renderer
            this.scene = scene;
            this.camera = camera;
            this.uiLayer = document.getElementById(uiLayerId);
            
            this.score = { home: 0, away: 0 };
            this.time = 0;
            this.half = 1;
            this.halfDuration = 300; // 5 minutes (seconds)
            this.isOvertime = false;
            this.isDemoMode = false;
this.gameMode = 'normal'; // 'normal' or 'practice'
            this.isForgeMode = false; // Asset Forge State
            // Impact Frames
            this.impactPause = 0;
            
            this.state = 'menu'; // Start in menu
this.teams = {
                home: null,
                away: null
            };
            
            this.entities = {
                ball: null
            };

this.ui = {
                scorePlayer: null,
                scoreCpu: null,
                timer: null,
                half: null,
                announcement: null,
                // Player Status Panel
                statusPanel: {
                    container: null,
                    name: null,
                    hpBar: null,
                    hpText: null,
                    expBar: null
                }
            };

            // Techcopy State
            this.techCopyState = {
                active: false,
                timer: 0,
                tech: null,
                learners: []
            };

this.miniMap = new window.flux.MiniMap();
            
            // Initialize Floating Text
// Initialize Floating Text
this.floatingText = new window.flux.FloatingTextManager(scene, uiLayerId, camera);
            
            // Reusable vector for UI calculations
            this._tempVec = new THREE.Vector3();

            // Initialize Particle Manager (Status Effects)
            
// Initialize Particle Manager (Status Effects)
            this.particleManager = new window.flux.ParticleManager(scene);
this.glyphManager = null; // Injected by main.js
            this._initParticles(); // 3D Spark System (Legacy/Impact)

this.debugVisualizer = new window.flux.DebugVisualizer(scene);
            this.practiceManager = new window.flux.PracticeManager(this); // Initialize Practice Manager
            this._injectStyles();
this._initUI();
        }

_initCinematics() {
            this.menuShotIndex = 0;
            this.menuShotTimer = 0;
            this.menuShots = [
                // 1. "The Arena" - Wide Establishing Shot (Slow dolly in)
                {
                    duration: 10.0,
                    update: (t, cam) => {
                        const p1 = new THREE.Vector3(60, 35, 60);
                        const p2 = new THREE.Vector3(40, 25, 40);
                        // Smoothstep interpolation
                        const st = t * t * (3 - 2 * t); 
                        cam.position.lerpVectors(p1, p2, st);
                        cam.lookAt(0, 0, 0);
                    }
                },
                // 2. "The Team" - Tracking Shot along the formation
                {
                    duration: 8.0,
                    update: (t, cam) => {
                        // Move along the side of the home team formation
                        const zStart = -25;
                        const zEnd = 25;
                        const currentZ = zStart + (zEnd - zStart) * t;
                        
                        cam.position.set(-25, 6, currentZ);
                        cam.lookAt(0, 2, currentZ * 0.8); // Look slightly ahead of center
                    }
                },
                // 3. "The Striker" - Close up orbit on a key position
                {
                    duration: 8.0,
                    update: (t, cam) => {
                        // Focus on where the LF/RF usually stands (approx +/- 10, -10)
                        const target = new THREE.Vector3(-10, 0, -10);
                        const angle = t * 1.0 + 3.5;
                        const dist = 10.0;
                        
                        cam.position.set(
                            target.x + Math.cos(angle) * dist,
                            target.y + 4.0,
                            target.z + Math.sin(angle) * dist
                        );
                        cam.lookAt(target.x, target.y + 1.5, target.z);
                    }
                },
                // 4. "The Goal" - Low Angle looking up at the net
                {
                    duration: 7.0,
                    update: (t, cam) => {
                        const p1 = new THREE.Vector3(0, -5, 32); // Low near goal
                        const p2 = new THREE.Vector3(0, 8, 20);  // Rising up
                        cam.position.lerpVectors(p1, p2, t);
                        cam.lookAt(0, 15, 45); // Look up at the structure
                        cam.rotation.z = (t - 0.5) * 0.15; // Slight cinematic tilt
                    }
                },
                // 5. "The Dive" - Vertical drop into the pool
                {
                    duration: 8.0,
                    update: (t, cam) => {
                        const p1 = new THREE.Vector3(0, 50, 0);
                        const p2 = new THREE.Vector3(0, 10, 0);
                        const st = t * t * (3 - 2 * t);
                        cam.position.lerpVectors(p1, p2, st);
                        cam.lookAt(0, 0, 0);
                        cam.rotation.z = t * 0.8; // Spiral down
                    }
                }
];
        }

        _injectStyles() {
            if (document.getElementById('flux-dynamic-styles')) return;
            const style = document.createElement('style');
            style.id = 'flux-dynamic-styles';
style.textContent = `
                @keyframes textSlam {
                    0% { transform: translate(-50%, -50%) scale(4); opacity: 0; letter-spacing: 50px; }
                    10% { transform: translate(-50%, -50%) scale(1); opacity: 1; letter-spacing: 5px; }
                    15% { transform: translate(-50%, -50%) scale(1.1); }
                    20% { transform: translate(-50%, -50%) scale(1); }
                    80% { transform: translate(-50%, -50%) scale(1); opacity: 1; filter: blur(0px); }
                    100% { transform: translate(-50%, -50%) scale(1.5); opacity: 0; filter: blur(10px); }
                }
                
                .announcement-slam {
                    position: absolute;
                    top: 45%; left: 50%;
                    transform: translate(-50%, -50%);
                    width: 100%;
                    text-align: center;
                    font-family: 'Impact', sans-serif;
                    font-size: 96px;
                    font-style: italic;
                    text-transform: uppercase;
                    background: linear-gradient(to bottom, #ffffff 0%, #ffdd00 45%, #ff8800 100%);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    filter: drop-shadow(0 0 10px rgba(0,0,0,1)) drop-shadow(0 0 30px rgba(255, 100, 0, 0.6));
                    z-index: 2000;
                    animation: textSlam 1.8s cubic-bezier(0.1, 0.8, 0.1, 1) forwards;
                    pointer-events: none;
                    white-space: nowrap;
                }

                .modal-overlay {
                    position: absolute; top: 0; left: 0; width: 100%; height: 100%;
                    background: radial-gradient(circle at center, rgba(10, 25, 60, 0.95) 0%, rgba(0, 0, 0, 0.98) 100%);
                    display: flex; justify-content: center; align-items: center; flex-direction: column;
                    z-index: 1900;
                    opacity: 0; pointer-events: none; transition: opacity 0.8s;
                    backdrop-filter: blur(8px);
                }
                .modal-overlay.active { opacity: 1; pointer-events: auto; }
                
                .modal-title {
                    font-family: 'Garamond', serif;
                    font-size: 52px; color: #fff;
                    text-transform: uppercase;
                    text-shadow: 0 0 20px #00aaff, 0 0 40px #0044aa;
                    margin-bottom: 30px;
                    border-bottom: 2px solid #00aaff;
                    padding-bottom: 10px;
                    width: 80%; text-align: center;
                    letter-spacing: 5px;
                }
                
                .modal-score-container {
                    display: flex; align-items: center; gap: 40px;
                    margin-bottom: 40px;
                }
                .modal-score {
                    font-family: 'Impact', sans-serif;
                    font-size: 80px; color: #ffd700;
                    letter-spacing: 5px;
                    text-shadow: 0 0 20px #b8860b;
                }
                .modal-vs {
                    font-family: 'Courier New', monospace;
                    font-size: 24px; color: #00aaff; opacity: 0.7;
                }

                .flash-overlay {
                    position: absolute; top: 0; left: 0; width: 100%; height: 100%;
                    background: white;
                    z-index: 2100;
                    opacity: 0; pointer-events: none;
                    transition: opacity 0.1s ease-out;
                    mix-blend-mode: overlay;
                }

                @keyframes clashPop {
                    0% { transform: translate(-50%, -50%) scale(0.5); opacity: 1; }
                    50% { transform: translate(-50%, -50%) scale(1.5); opacity: 0.8; }
                    100% { transform: translate(-50%, -50%) scale(2.0); opacity: 0; }
                }

                .clash-spark {
                    position: absolute;
                    width: 60px; height: 60px;
                    background: radial-gradient(circle, #ffffff 0%, #ffff00 40%, transparent 70%);
                    border-radius: 50%;
                    pointer-events: none;
                    z-index: 1500;
                    mix-blend-mode: screen;
                    animation: clashPop 0.3s ease-out forwards;
                    box-shadow: 0 0 20px #ffaa00;
                }
            `;
            document.head.appendChild(style);
        }

        registerTeams(homeTeam, awayTeam, ball) {
            this.teams.home = homeTeam;
            this.teams.away = awayTeam;
this.entities.ball = ball;
            
            // Initialize MiniMap
            if (this.miniMap) {
                this.miniMap.init(homeTeam, awayTeam, ball);
            }
        }

_initUI() {
            // Bind to existing HTML elements
            this.ui.scorePlayer = document.getElementById('score-player');
            this.ui.scoreCpu = document.getElementById('score-cpu');
            this.ui.timer = document.getElementById('timer-display');
            this.ui.half = document.getElementById('half-indicator');
            this.ui.announcement = document.getElementById('announcement');
            
            this.ui.techFlash = document.getElementById('tech-flash-overlay');
            if (this.ui.techFlash) {
                this.ui.techSub = this.ui.techFlash.querySelector('.tech-sub-text');
            }
            this.ui.techTimerFill = document.querySelector('.tech-timer-fill');

            // Bind Player Status Panel
            this.ui.statusPanel.container = document.getElementById('player-status-panel');
            this.ui.statusPanel.name = document.querySelector('#player-status-panel .char-name');
            this.ui.statusPanel.hpBar = document.querySelector('#player-status-panel .hp-bar-fill');
            this.ui.statusPanel.hpText = document.querySelector('#player-status-panel .hp-value');
            this.ui.statusPanel.expBar = document.querySelector('#player-status-panel .tech-bar-fill');
            
            // End Game Menu Bindings
            this.ui.endMenu = document.getElementById('end-game-menu');
            const btnRematch = document.getElementById('end-btn-rematch');
            const btnExit = document.getElementById('end-btn-exit');

            if (btnRematch) {
                btnRematch.addEventListener('click', () => {
                    this._hideEndMenu();
                    this.startMatch(this.gameMode);
                });
            }
            if (btnExit) {
                btnExit.addEventListener('click', () => {
                    this._hideEndMenu();
                    if (window.flux.gameInstance.menuManager) {
                        window.flux.gameInstance.menuManager.show();
                        this.state = 'menu';
                    }
                });
            }

            // Create Modal Overlay (For Halftime only now)
            this.ui.modal = document.createElement('div');
            this.ui.modal.className = 'modal-overlay';
            this.ui.modal.innerHTML = `
                <div class="modal-title">HALF TIME</div>
                <div class="modal-score-container">
                    <div class="modal-score" id="modal-score-home">0</div>
                    <div class="modal-vs">-</div>
                    <div class="modal-score" id="modal-score-away">0</div>
                </div>
                <div id="modal-msg" style="color: #00aaff; font-size: 14px; letter-spacing: 2px;">PREPARING 2ND HALF...</div>
            `;
            this.uiLayer.appendChild(this.ui.modal);

            // Create Flash Overlay
            this.ui.flash = document.createElement('div');
            this.ui.flash.className = 'flash-overlay';
            this.uiLayer.appendChild(this.ui.flash);

            // Initial State
            this._updateScoreUI();
            if (this.ui.timer) this.ui.timer.innerText = "00:00";
        }
        _updateScoreUI() {
            if (this.ui.scorePlayer) this.ui.scorePlayer.innerText = this.score.home;
            if (this.ui.scoreCpu) this.ui.scoreCpu.innerText = this.score.away;
        }

updatePractice(dt) {
            // Delegate logic to PracticeManager
            if (this.practiceManager) {
                this.practiceManager.update(dt);
            }
        }

        update(dt) {

if (this.state === 'intro') {
                this.introTimer += dt;

                // 1. Lights Sequence (0.5s to 2.5s)
                if (this.stadium && this.introTimer > 0.5 && this.introTimer < 2.5) {
                    const duration = 2.0;
                    const progress = (this.introTimer - 0.5) / duration;
                    const total = this.stadium.lightSprites.length;
                    const activeCount = Math.floor(progress * total);
                    
                    for(let i=0; i<total; i++) {
                        if (i <= activeCount && !this.stadium.lightSprites[i].visible) {
                            this.stadium.turnOnLight(i);
                        }
                    }
                }

                // 2. Camera Movement (Spiral In)
                if (this.camera) {
                    const t = this.introTimer;
                    const duration = 5.0;
                    const pct = Math.min(1.0, t / duration);
                    
                    // Smooth ease
                    const ease = 1 - Math.pow(1 - pct, 3);
                    
                    const startRadius = 120;
                    const endRadius = 40;
                    const radius = startRadius + (endRadius - startRadius) * ease;
                    
                    const startHeight = 60;
                    const endHeight = 20;
                    const height = startHeight + (endHeight - startHeight) * ease;
                    
                    const angle = t * 0.4; // Rotation
                    
                    this.camera.position.set(
                        Math.sin(angle) * radius,
                        height,
                        Math.cos(angle) * radius
                    );
                    this.camera.lookAt(0, 0, 0);
                }

                // 3. Crowd Roar / Hype (3.0s)
                if (this.introTimer > 3.0 && !this._introRoarTriggered) {
                    this._introRoarTriggered = true;
                    this.showAnnouncement("ARE YOU READY?", "slam");
                    if (this.cameraManager) this.cameraManager.addShake(1.5);
                    
                    // Flash crowd
                    if (this.stadium && this.stadium.crowd) {
                        // We can't easily flash instanced mesh color without iterating, 
                        // but we can spawn some particles
                        if (this.particleManager) {
                            for(let i=0; i<20; i++) {
                                const pos = new THREE.Vector3(
                                    (Math.random()-0.5)*100,
                                    10 + Math.random()*20,
                                    (Math.random()-0.5)*100
                                );
                                this.particleManager.spawn('flash', pos, { scale: 5.0 });
                            }
                        }
                    }
                }

                // 4. End Intro (5.0s)
                if (this.introTimer > 5.0) {
                    this._introRoarTriggered = false;
                    // Restore UI
                    document.getElementById('hud-top').style.opacity = '1';
                    document.getElementById('player-status-panel').style.opacity = '1';
                    
                    // Ensure all lights on
                    if (this.stadium) this.stadium.setAllLights(true);
                    
                    this.resetRound(null); // Go to kickoff
                }
                return;
            }

            if (this.state === 'menu') {
                // --- POPULATE ARENA FOR B-ROLL ---
                // Ensure players are visible and animated
                const animateTeam = (team) => {
                    if (!team) return;
                    team.players.forEach(p => {
                        if (p.mesh) {
                            p.mesh.visible = true;
                            // Gentle bobbing to simulate treading water
                            p.mesh.position.y = p.homePosition.y + Math.sin(Date.now() * 0.002 + p.mesh.id) * 0.5;
                            // Ensure idle animation is playing
                            if (p.state !== 'idle') p.play('idle', 0.5);
                            if (p.mixer) p.mixer.update(dt);
                        }
                    });
                };
                animateTeam(this.teams.home);
                animateTeam(this.teams.away);

                // --- CINEMATIC B-ROLL ---
                if (this.menuShots && this.menuShots.length > 0) {
                    const shot = this.menuShots[this.menuShotIndex];
                    this.menuShotTimer += dt;
                    
                    if (this.menuShotTimer >= shot.duration) {
                        this.menuShotTimer = 0;
                        this.menuShotIndex = (this.menuShotIndex + 1) % this.menuShots.length;
                    }
                    
                    // Normalize time (0 to 1)
                    const t = this.menuShotTimer / shot.duration;
                    if (this.camera) {
                        shot.update(t, this.camera);
                    }
                }

                // Ambient FX in Menu
                if (this.particleManager && Math.random() < 0.2) {
                    // Spawn random bubbles for atmosphere
                    const range = 60;
                    const pos = new THREE.Vector3(
                        (Math.random()-0.5)*range, 
                        -10 + Math.random()*20, 
                        (Math.random()-0.5)*range
                    );
                    this.particleManager.spawn('bubble', pos, { life: 3.0 + Math.random()*2.0, scale: 0.3 + Math.random()*0.4 });
                }

                // Update Background Systems
                if (this.waterOverlay) this.waterOverlay.update(dt);
                if (this.lightShafts) this.lightShafts.update(dt);
                if (this.stadium) this.stadium.update(dt);
                if (this.particleManager) this.particleManager.update(dt);

                // Render
                if (this.renderer && this.scene && this.camera) {
                    this.renderer.render(this.scene, this.camera);
                }
                return;
            }

// --- LOGIC UPDATE (State Dependent) ---
            if (this.state === 'active') {
                if (this.gameMode === 'practice') {
                    this.updatePractice(dt);
                } else {
                    this.time += dt;
                    this._updateTimer();
                    this._checkHalfTime();
                }

                this._checkGoals();
                
                // Update Techcopy Window
                if (this.techCopyState.active) {
                    this.techCopyState.timer -= dt;
                    
                    // Update UI Bar
                    if (this.ui.techTimerFill) {
                        const pct = Math.max(0, (this.techCopyState.timer / this.techCopyState.maxTime) * 100);
                        this.ui.techTimerFill.style.width = `${pct}%`;
                        
                        // Color shift based on urgency
                        if (pct < 30) this.ui.techTimerFill.style.background = '#ff0000';
                        else this.ui.techTimerFill.style.background = 'linear-gradient(90deg, #ffffff, #00ffff)';
                    }

                    if (this.techCopyState.timer <= 0) {
                        this.endTechCopyWindow(false);
                    }
                }
            }

            // --- VISUAL UPDATE (Always Run) ---
            // Update these in all states (Active, Goal, Halftime, GameOver) to keep FX alive
            if (this.state !== 'menu' && this.state !== 'intro') {
                if (this.miniMap) this.miniMap.update();
                if (this.floatingText) this.floatingText.update(dt);
                if (this.particleManager) this.particleManager.update(dt);
                this._updateParticles(dt); // Legacy sparks
                if (this.debugVisualizer) this.debugVisualizer.update();
            }
        }
            
        _updateOffscreenIndicator() {
            const p = this.teams.home ? this.teams.home.activePlayer : null;
            const indicator = this.ui.offscreenIndicator;
            
            if (!p || !p.mesh || !this.camera || !indicator) return;

            // 1. Get Player Position (Center Mass)
            const pos = p.mesh.position.clone();
            pos.y += 1.0; 
            
            // 2. Project to Normalized Device Coordinates (NDC) [-1, 1]
            this._tempVec.copy(pos).project(this.camera);
            
            // 3. Check if Behind Camera
            const camFwd = new THREE.Vector3();
            this.camera.getWorldDirection(camFwd);
            const toPlayer = pos.clone().sub(this.camera.position).normalize();
            const dot = camFwd.dot(toPlayer);
            const isBehind = dot < 0.2; // Buffer to prevent flipping at edge

            // 4. Check Bounds
            const isOffScreen = (
                this._tempVec.x < -0.9 || this._tempVec.x > 0.9 ||
                this._tempVec.y < -0.9 || this._tempVec.y > 0.9 ||
                isBehind
            );

            if (isOffScreen) {
                indicator.style.display = 'block';
                
                let x = this._tempVec.x;
                let y = this._tempVec.y;

                // If behind, invert coordinates to point correctly
                if (isBehind) {
                    x = -x;
                    y = -y;
                    // Fix singularity if exactly behind center
                    if (Math.abs(x) < 0.01 && Math.abs(y) < 0.01) y = -1; 
                }

                // Clamp to screen edges
                // We want to find the intersection of the vector (x,y) with the box [-0.9, 0.9]
                const padding = 0.9;
                
                // Normalize to get direction
                const mag = Math.sqrt(x*x + y*y);
                const nx = x / mag;
                const ny = y / mag;
                
                // Raycast to box edges
                // Vertical edges: x = +/- padding
                // Horizontal edges: y = +/- padding
                
                // Avoid divide by zero
                const tx = (Math.abs(nx) > 0.001) ? (nx > 0 ? padding : -padding) / nx : 999;
                const ty = (Math.abs(ny) > 0.001) ? (ny > 0 ? padding : -padding) / ny : 999;
                
                // Use the nearest intersection (smallest positive t)
                // Since we are projecting from center (0,0) to (nx,ny), t must be positive.
                const t = Math.min(Math.abs(tx), Math.abs(ty));
                
                const screenX = nx * t;
                const screenY = ny * t;

                // Convert NDC to Pixels
                const width = window.innerWidth;
                const height = window.innerHeight;
                
                const px = (screenX * 0.5 + 0.5) * width;
                const py = (-(screenY) * 0.5 + 0.5) * height;

                // Calculate Rotation
                // Arrow points UP by default.
                // We want it to point in direction (nx, ny) on screen.
                // Screen Y is down (inverted from WebGL Y).
                // So (0, 1) in NDC is UP. (0, -1) in NDC is DOWN.
                // atan2(y, x) gives angle from +X.
                // We want angle from +Y (Up).
                // Rotation = PI/2 - angle.
                
                const angle = Math.atan2(ny, nx);
                const rot = (Math.PI / 2) - angle;

                indicator.style.transform = `translate(${px}px, ${py}px) rotate(${rot}rad)`;
                
            } else {

                indicator.style.display = 'none';
            }
        }

        _updateTimer() {
            if (!this.ui.timer) return;
            // Clamp to half duration for display if we go slightly over before tick
            const t = Math.min(this.time, this.halfDuration);
            const minutes = Math.floor(t / 60);
            const seconds = Math.floor(t % 60);
            this.ui.timer.innerText = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
        _checkHalfTime() {
            if (this.time >= this.halfDuration) {
                this.endHalf();
            }
        }

endHalf() {
            this.state = 'halftime';
            
            // Stop all players
            if (this.teams.home) this.teams.home.players.forEach(p => p.setInput(0, 0));
            if (this.teams.away) this.teams.away.players.forEach(p => p.setInput(0, 0));

            if (this.half === 1) {
                this._showModal("HALF TIME", "PREPARING 2ND HALF...");
                
                // Optional: Play whistle sound here if available
                // if (this.audioManager) this.audioManager.playSFX('whistle');

                setTimeout(() => {
                    this._hideModal();
                    this.startSecondHalf();
                }, 4000);
            } else {
                // End of 2nd Half or Overtime Period
                if (this.score.home === this.score.away) {
                    // TIED - Go to Overtime (Golden Goal)
                    this._showModal("OVERTIME", "GOLDEN GOAL RULE ACTIVE");
                    setTimeout(() => {
                        this._hideModal();
                        this.startOvertime();
                    }, 4000);
                } else {
                    // Winner decided
                    this.endGame();
                }
            }
        }

        startSecondHalf() {
            this.half = 2;
            this.time = 0;
            this.ui.half.innerText = "2nd HALF";
            this.resetRound(null); // Neutral Blitz-off for 2nd half start
        }

        startOvertime() {
            this.half++;
            this.time = 0;
            this.isOvertime = true;
            this.ui.half.innerText = "OVERTIME";
            this.resetRound(null); // Neutral Blitz-off
        }

endGame() {
            this.state = 'gameover';
            
            // Stop players
            if (this.teams.home) this.teams.home.players.forEach(p => p.setInput(0, 0));
            if (this.teams.away) this.teams.away.players.forEach(p => p.setInput(0, 0));

            let msg = "DRAW";
            if (this.score.home > this.score.away) msg = "VICTORY";
            if (this.score.away > this.score.home) msg = "DEFEAT";
            
            // Populate End Game Menu
            if (this.ui.endMenu) {
                const titleEl = document.getElementById('end-result-title');
                const homeScoreEl = document.getElementById('end-score-home');
                const awayScoreEl = document.getElementById('end-score-away');
                
                if (titleEl) {
                    titleEl.innerText = msg;
                    titleEl.style.color = (msg === "VICTORY") ? "#00ffff" : ((msg === "DEFEAT") ? "#ff4444" : "#ffffff");
                }
                if (homeScoreEl) homeScoreEl.innerText = this.score.home;
                if (awayScoreEl) awayScoreEl.innerText = this.score.away;

                this.ui.endMenu.classList.add('active');
                this.setMenuMode(true); // Hide HUD
            }

            // Stop Music on Game Over
            if (this.audioManager) {
                this.audioManager.stopBGM();
            }
        }

        _hideEndMenu() {
            if (this.ui.endMenu) {
                this.ui.endMenu.classList.remove('active');
                this.setMenuMode(false); // Show HUD
            }
        }

        _showModal(title, subtext) {
            if (!this.ui.modal) return;
            
            this.ui.modal.querySelector('.modal-title').innerText = title;
            this.ui.modal.querySelector('#modal-score-home').innerText = this.score.home;
            this.ui.modal.querySelector('#modal-score-away').innerText = this.score.away;
            this.ui.modal.querySelector('#modal-msg').innerText = subtext;
            
            this.ui.modal.classList.add('active');
            
            // Hide HUD elements
            document.getElementById('hud-top').style.opacity = '0';
            document.getElementById('player-status-panel').style.opacity = '0';
        }

        _hideModal() {
            if (!this.ui.modal) return;
            this.ui.modal.classList.remove('active');
            
            // Show HUD elements
            document.getElementById('hud-top').style.opacity = '1';
            document.getElementById('player-status-panel').style.opacity = '1';
        }

_checkGoals() {
            const ball = this.entities.ball;
            if (!ball || !ball.mesh) return;

            const pos = ball.mesh.position;

            // Precise Goal Detection
            // Visual Goal is at Z = +/- 28.
            // We define a "Goal Mouth" box matching Goalie.js (Width 14, Height 8).
// We define a "Goal Mouth" box matching the visual net.
            // Arena Radius is 32. Goal is roughly 22m wide, 18m high.
// Arena Radius is 32. Goal is roughly 22m wide, 18m high.
            const halfWidth = 11.0; // Increased to 11 (Width 22) to catch corners
            const halfHeight = 9.0; // Increased to 9 (Height 18) to catch high shots
            const goalYOffset = -4.5; // Moved down to match visual model (-4.5m)

            const triggerZ = 45.0; // Trigger earlier (was 30) to ensure registration before bounce

            if (Math.abs(pos.z) > triggerZ) {
                // PREVENT OWN GOAL BY CARRIER (User Request)
                // If the ball is held by the team defending this goal, do not count it.
                if (ball.holder) {
                    // Home (Side 1) defends +Z. If pos.z > 0 (Home Goal) and holder is Home, ignore.
                    if (pos.z > 0 && ball.holder.team.side === 1) return;
                    // Away (Side -1) defends -Z. If pos.z < 0 (Away Goal) and holder is Away, ignore.
                    if (pos.z < 0 && ball.holder.team.side === -1) return;
                }

                // 2. Check Frame (Must be within width/height)
// 2. Check Frame (Must be within width/height, accounting for Y offset)
                if (Math.abs(pos.x) <= halfWidth && Math.abs(pos.y - goalYOffset) <= halfHeight) {
                    if (pos.z < 0) {
                        this.goalScored('home'); // Home attacks -Z
                    } else {
                        this.goalScored('away'); // Away attacks +Z
                    }
                }
            }
        }

goalScored(scorer) {
            if (this.state !== 'active') return;
            
            // IMPACT FRAME: GOAL
            this.triggerImpact(0.4, 'shatter'); // Massive freeze for goal
            
            // EXP REWARD: Goal
            // Find who scored (Last holder of ball)
            const ball = this.entities.ball;
            if (ball && ball.lastHolder && ball.lastHolder.team.id === scorer) {
                ball.lastHolder.gainExp(10);
            }

            this.state = 'goal';
            this.score[scorer]++;
            this._updateScoreUI();
            
            // 1. VISCERAL SHAKE & PARTICLES
            if (this.cameraManager) {
                this.cameraManager.addShake(2.0); // Heavy shake
            }
            if (this.particleManager && this.entities.ball && this.entities.ball.mesh) {
                const goalPos = this.entities.ball.mesh.position.clone();
                // Massive Goal Explosion
                this.particleManager.spawn('shockwave', goalPos, { scale: 15.0, life: 0.8 });
                this.particleManager.spawn('flash', goalPos, { scale: 10.0 });
                for(let i=0; i<30; i++) {
                    this.particleManager.spawn('debris', goalPos, { scale: 0.8 });
                }
            }
            // 2. SCREEN FLASH
            if (this.ui.flash) {
                this.ui.flash.style.opacity = '0.8';
                setTimeout(() => { this.ui.flash.style.opacity = '0'; }, 100);
            }

            // 3. GOLDEN GOAL CHECK
            if (this.isOvertime) {
                this.showAnnouncement("GOLDEN GOAL!", 'slam');
                // End game after short delay
                setTimeout(() => {
                    this.endGame();
                }, 3000);
                return;
            }

            // 4. SLAM ANNOUNCEMENT (Normal)
            this.showAnnouncement("GOAL!", 'slam');
            
            // Reset sequence
            // Scored-upon team gets ball
            const loser = scorer === 'home' ? 'away' : 'home';
            
            // FASTER FLOW: Reduced delay from 3000ms to 1200ms
            setTimeout(() => {
                this.resetRound(loser);
            }, 2000); // Slightly longer to appreciate the "GOAL" slam
        }

showAnnouncement(text, type = 'normal', duration = 2000) {
            const el = this.ui.announcement;
            if (!el) return;

            // Clear previous timeout
            if (this._announceTimeout) {
                clearTimeout(this._announceTimeout);
                this._announceTimeout = null;
            }

            // Reset Animation by cloning
            const newEl = el.cloneNode(true);
            el.parentNode.replaceChild(newEl, el);
            this.ui.announcement = newEl;

            newEl.innerText = text;
            newEl.style.display = 'block';
            
            // Apply Class based on type
            newEl.className = ''; // Reset classes
            if (type === 'slam') {
                newEl.classList.add('announcement-slam');
            } else {
                // Default style
                newEl.style.animation = 'none';
                newEl.offsetHeight; /* trigger reflow */
                newEl.style.animation = 'announceSlide 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
            }

            // Auto-hide
            if (duration > 0) {
                this._announceTimeout = setTimeout(() => {
                    this.hideAnnouncement();
                }, duration);
            }
        }

        hideAnnouncement() {
            if (this.ui.announcement) {
                this.ui.announcement.style.display = 'none';
            }
        }

resetRound(possessionTeamId) {
            this.state = 'reset';
            
            // Clear persistent visuals
            if (this.glyphManager) this.glyphManager.clear();
            if (this.particleManager) {
                // Optional: Clear particles if needed, though they self-expire quickly
            }
            
            // Reset Ball
            if (this.entities.ball) this.entities.ball.reset();
            if (this.entities.ball) this.entities.ball.reset();
            
            // Reset Teams
            if (this.teams.home) this.teams.home.resetPositions();
            if (this.teams.away) this.teams.away.resetPositions();
            
            // Clear ball holder
            if (this.entities.ball) this.entities.ball.drop();

            // CRITICAL: Snap camera to prevent disorientation
            if (this.cameraManager) {
                // Force update target first (usually ball)
                if (this.entities.ball && this.entities.ball.mesh) {
                    this.cameraManager.setTarget(this.entities.ball.mesh, this.entities.ball.velocity);
                    this.cameraManager.snapToTarget();
                }
            }

            // FASTER FLOW: Reduced delay from 2000ms to 100ms
            setTimeout(() => {
                this.startKickoff(possessionTeamId);
}, 100);
        }

startKickoff(possessionTeamId) {
            this.state = 'kickoff';
            
            // Stop all players immediately to prevent pre-movement
            if (this.teams.home) this.teams.home.players.forEach(p => p.setInput(0, 0));
            if (this.teams.away) this.teams.away.players.forEach(p => p.setInput(0, 0));

            this.showAnnouncement("BLITZ OFF!", 'slam');
            // If a team has possession (after goal), give to MF
            if (possessionTeamId) {
                const team = this.teams[possessionTeamId];
                if (team) {
                    const mf = team.players.find(p => p.role === 'MF');
                    if (mf && this.entities.ball) {
                        this.entities.ball.grab(mf);
                        
                        // CRITICAL: Snap camera to new holder to prevent swing/disorientation
                        if (this.cameraManager) {
                            this.cameraManager.setTarget(mf.mesh, mf.velocity);
                            this.cameraManager.snapToTarget();
                        }
                    }
                }
            } else {
                // Neutral kickoff - ensure camera is snapped to center ball
                if (this.cameraManager && this.entities.ball && this.entities.ball.mesh) {
                    this.cameraManager.setTarget(this.entities.ball.mesh, this.entities.ball.velocity);
                    this.cameraManager.snapToTarget();
                }
            }
            
            // FASTER FLOW: Reduced delay from 1000ms to 800ms
            setTimeout(() => {
                this.hideAnnouncement();
                this.state = 'active';
            }, 800);
        }
        
// Initial start
// Initial start
        startMatch(mode = 'normal') {
            this.gameMode = mode;
            console.log("Starting Match in mode:", mode);
            
            // Start Music
            if (this.audioManager) {
                this.audioManager.playBGM();
            }
            
            // Reset Score
            this.score.home = 0;
            this.score.away = 0;
            this._updateScoreUI();
            
            // Reset Time
            this.time = 0;
            this.half = 1;
            if (this.ui.half) this.ui.half.innerText = "1st";
            
            if (mode === 'practice') {
                if (this.ui.half) this.ui.half.innerText = "PRAC";
                
                // Start Practice Manager
                if (this.practiceManager) {
                    this.practiceManager.start();
                }

                // In practice, ensure AI is enabled for sparring
                if (this.teams.away) {
                    this.teams.away.aiEnabled = true;
                }
                
                // Skip intro for practice
                this.resetRound();
            } else {
                // Ensure Practice Manager is stopped if normal game
                if (this.practiceManager) this.practiceManager.stop();
                
                // Safety: Ensure all players are visible (in case Practice hid them)
                if (this.teams.away) {
                    this.teams.away.players.forEach(p => { if(p.mesh) p.mesh.visible = true; });
                    this.teams.away.aiEnabled = true; 
                }
                if (this.teams.home) {
                    this.teams.home.players.forEach(p => { if(p.mesh) p.mesh.visible = true; });
                }

                // Start Cinematic Intro
                this.startIntroSequence();
            }
        }

        startIntroSequence() {
            this.state = 'intro';
            this.introTimer = 0;
            this._introRoarTriggered = false;
            
            // Turn off lights
            if (this.stadium) {
                this.stadium.setAllLights(false);
            }
            
            // Hide UI
            document.getElementById('hud-top').style.opacity = '0';
            document.getElementById('player-status-panel').style.opacity = '0';
            
            // Reset positions so players are on field in dark
            if (this.teams.home) this.teams.home.resetPositions();
            if (this.teams.away) this.teams.away.resetPositions();
            if (this.entities.ball) this.entities.ball.reset();
        }
// Duplicate block removed

setMenuMode(isActive) {
            this.state = isActive ? 'menu' : 'active';
            
            if (isActive && this.audioManager) {
                this.audioManager.stopBGM();
            }
            
            // Hide HUD in menu
            const hudTop = document.getElementById('hud-top');
            const statusPanel = document.getElementById('player-status-panel');
            const controls = document.getElementById('action-container');
            const joystick = document.getElementById('joystick-hit-zone');
            
            const display = isActive ? 'none' : 'flex'; // or block/etc
            
            if (hudTop) hudTop.style.display = display;
            if (statusPanel) statusPanel.style.display = isActive ? 'none' : 'block'; // Status panel has specific logic
            if (controls) controls.style.display = isActive ? 'none' : 'flex';
            if (joystick) joystick.style.display = isActive ? 'none' : 'block';
            
            // If entering menu, reset camera to a nice angle?
            // Handled by update loop
        }
toggleDemoMode() {
            this.isDemoMode = !this.isDemoMode;
            console.log("Demo Mode:", this.isDemoMode);
            
            // Update UI Button
            const btn = document.getElementById('auto-toggle');
            if (btn) {
                btn.innerText = this.isDemoMode ? "AUTO PILOT" : "MANUAL";
                if (this.isDemoMode) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            }
            
            // Announcement
            const text = this.isDemoMode ? "AUTO PILOT" : "MANUAL";
            this.showAnnouncement(text);
            
            // Visual Flair: Spawn text above active player
            if (this.isDemoMode && this.floatingText && this.teams.home && this.teams.home.activePlayer && this.teams.home.activePlayer.mesh) {
                this.floatingText.spawn("AI ENGAGED", this.teams.home.activePlayer.mesh.position, "goal");
            }

            // Auto-hide announcement
setTimeout(() => {
                if (this.ui.announcement && this.ui.announcement.innerText === text) {
                    this.hideAnnouncement();
                }
            }, 1500);
        }

        // --- TECHCOPY SYSTEM ---

        triggerTechEvent(sourcePlayer, techName) {
            if (!sourcePlayer || !sourcePlayer.team) return;

            // Find opposing team
            const oppTeamId = sourcePlayer.team.id === 'home' ? 'away' : 'home';
            const oppTeam = this.teams[oppTeamId];
            if (!oppTeam) return;

            // Find who is marking this source
            const learners = oppTeam.players.filter(p => p.marking === sourcePlayer);
            
            if (learners.length === 0) return;

            // Only show UI if the learning team is Human (Home)
            // (Or if we are in Demo mode and want to see it happen for Home team)
            if (oppTeam.isHuman) {
                // Filter out those who already know it
                const validLearners = learners.filter(p => !p.learnedTechs.includes(techName));
                if (validLearners.length > 0) {
                    this.startTechCopyWindow(techName, validLearners);
                }
            }
        }

startTechCopyWindow(techName, learners) {
            this.techCopyState.active = true;
            this.techCopyState.maxTime = 0.6; // 0.6s window
            this.techCopyState.timer = this.techCopyState.maxTime;
            this.techCopyState.tech = techName;
            this.techCopyState.learners = learners;
            
            // Show UI
            if (this.ui.techFlash) {
                this.ui.techFlash.style.display = 'flex';
                this.ui.techFlash.style.background = ""; // Reset background
                this.ui.techFlash.querySelector('.tech-text').innerText = "TECHCOPY!";
                
                if (this.ui.techSub) {
                    this.ui.techSub.innerText = techName.replace('_', ' ');
                }
                
                // Reset bar
                if (this.ui.techTimerFill) {
                    this.ui.techTimerFill.style.width = '100%';
                }
            }
        }

attemptTechCopy() {
            if (!this.techCopyState.active) return false;
            
            // Success!
            const tech = this.techCopyState.tech;
            const learners = this.techCopyState.learners;
            
            learners.forEach(p => {
                // Double check to prevent duplicates
                if (!p.learnedTechs.includes(tech)) {
                    p.learnedTechs.push(tech);
                    console.log(`${p.role} learned ${tech}!`);
                    
                    // 1. Floating Text
                    if (this.floatingText && p.mesh) {
                        this.floatingText.spawn(`LEARNED!`, p.mesh.position, "tech");
                    }
                    
                    // 2. Particle Effect (Spiral)
                    if (this.particleManager && p.mesh) {
                        // Spawn multiple particles for a swirl effect
                        for(let i=0; i<10; i++) {
                            setTimeout(() => {
                                this.particleManager.spawn('learned', p.mesh.position);
                            }, i * 50);
                        }
                    }
                }
            });
            
            this.endTechCopyWindow(true);
            return true;
        }

endTechCopyWindow(success) {
            this.techCopyState.active = false;
            if (this.ui.techFlash) {
                if (success) {
                    this.ui.techFlash.querySelector('.tech-text').innerText = "SUCCESS!";
                    // Flash success color (White flash)
                    this.ui.techFlash.style.background = "rgba(255, 255, 255, 0.8)";
                    
                    // Hide after short delay to show the success flash
                    setTimeout(() => { 
                        this.ui.techFlash.style.display = 'none'; 
                    }, 300);
                } else {
                    // Failed / Missed
                    this.ui.techFlash.style.display = 'none';
                }
            }
        }
_updatePlayerStatusUI() {
            if (!this.teams.home || !this.teams.home.activePlayer) return;
            
            const p = this.teams.home.activePlayer;
            const ui = this.ui.statusPanel;
            
// UI Updates (Action Button Context)
                ui.container.style.display = 'block';
                
                // Name & Level
                if (ui.name) ui.name.innerText = `${p.characterName || p.role} LV${p.level}`;
                
                // HP
                if (ui.hpBar) {
                    const hpPct = Math.max(0, Math.min(100, (p.stats.HP / p.stats.maxHP) * 100));
                    ui.hpBar.style.width = `${hpPct}%`;
                    // Color shift
                    if (hpPct < 25) ui.hpBar.style.background = 'linear-gradient(90deg, #ff0000, #ff4444)';
                    else if (hpPct < 50) ui.hpBar.style.background = 'linear-gradient(90deg, #ffff00, #ffff88)';
                    else ui.hpBar.style.background = 'linear-gradient(90deg, #00ff00, #ccffcc)';
                }
                if (ui.hpText) ui.hpText.innerText = `${Math.floor(p.stats.HP)}/${p.stats.maxHP}`;
                
                // EXP
                if (ui.expBar) {
                    const expPct = Math.max(0, Math.min(100, (p.exp / p.nextLevelExp) * 100));
                    ui.expBar.style.width = `${expPct}%`;
ui.expBar.style.width = `${expPct}%`;
                }
        }

_initParticles() {
            this.activeSparks = [];
            this.sparkPool = [];
            const poolSize = 40; // Sufficient for continuous grinding
            
            for (let i = 0; i < poolSize; i++) {
                const sprite = new THREE.Sprite(_sparkMaterial.clone());
                sprite.visible = false;
                this.scene.add(sprite);
                this.sparkPool.push(sprite);
            }
        }

        spawnClash(pos, intensity = 1.0) {
            // Find free spark
            const spark = this.sparkPool.find(s => !s.visible);
            if (!spark) return; // Pool exhausted
            
            spark.position.copy(pos);
            spark.visible = true;
            
            // Randomize rotation
            spark.material.rotation = Math.random() * Math.PI;
            
            // Initialize Active State
            this.activeSparks.push({
                mesh: spark,
                age: 0,
                life: 0.15 + Math.random() * 0.15, // Fast, punchy sparks
                maxScale: 2.5 * intensity,
                velocity: new THREE.Vector3(
                    (Math.random()-0.5)*8, 
                    (Math.random()-0.5)*8, 
                    (Math.random()-0.5)*8
                )
            });
        }

        _updateParticles(dt) {
            for (let i = this.activeSparks.length - 1; i >= 0; i--) {
                const p = this.activeSparks[i];
                p.age += dt;
                
                if (p.age >= p.life) {
                    p.mesh.visible = false;
                    this.activeSparks.splice(i, 1);
                    continue;
                }
                
                const t = p.age / p.life;
                
                // Expand
                const currentScale = 0.5 + (p.maxScale - 0.5) * t;
                p.mesh.scale.setScalar(currentScale);
                
                // Fade out
                p.mesh.material.opacity = 1.0 - (t * t); // Quadratic fade
                
                // Move
                p.mesh.position.addScaledVector(p.velocity, dt);
                p.mesh.material.rotation += 10.0 * dt;
            }
        }

// Helper for impact frames

triggerImpact(duration, type = 'default') {
            this.impactPause = duration;
            
            const container = document.getElementById('game-container');
            if (!container) return;

            // Reset classes to ensure animation restarts
            container.classList.remove('impact-fx', 'impact-heavy', 'impact-shatter');
            
            // Force reflow
            void container.offsetWidth;

            let className = 'impact-fx';
            if (type === 'heavy') className = 'impact-heavy';
            if (type === 'shatter') className = 'impact-shatter';

            container.classList.add(className);

            // Auto-remove class after duration
            setTimeout(() => {
                container.classList.remove(className);
            }, duration * 1000 + 100);
        }
    }

    window.flux.GameManager = GameManager;
})();