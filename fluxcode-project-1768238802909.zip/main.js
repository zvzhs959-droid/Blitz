(function() {
    // Namespace
    window.flux = window.flux || {};
    window.flux._runtimeUpdaters = window.flux._runtimeUpdaters || [];

    // Config
const _config = {
        internalWidth: 360,
        internalHeight: 640,
        bgColor: 0x001e36,
        fogColor: 0x001e36,
        fogDensity: 0.0001, // Drastically reduced to ensure visibility
        arenaRadius: 48.0
    };

    // Globals
// Globals
    const _input = { x: 0, y: 0 }; // Input state
    
    // Shader Uniforms
    const _arenaUniforms = {
        uTime: { value: 0 },
        uImpactPos: { value: new THREE.Vector3() },
        uImpactStr: { value: 0.0 }
    };
    const _particleUniforms = {
        uTime: { value: 0 }
    };

    // Expose Impact Trigger
    window.flux.triggerArenaImpact = function(pos, strength) {
        _arenaUniforms.uImpactPos.value.copy(pos);
        _arenaUniforms.uImpactStr.value = strength * 2.0; // Scale up for visibility
    };
// _input already declared above
    const _tempVec1 = new THREE.Vector3(); // Reusable for physics/logic
    const _tempVec2 = new THREE.Vector3(); // Reusable for physics/logic
    let _scene, _camera, _renderer, _clock;
    let _homeTeam, _awayTeam;
    let _ball;
    let _gameManager;
    let _menuManager;
    let _audioManager;

    let _cameraManager;
    let _waterOverlay;
    let _lightShafts;
    let _stadium;
    let _glyphManager;

    // IMPROVED: Settings object
    const _settings = {
        joystickSensitivity: 1.0,
        aimAssist: true,
        cameraShake: true,
        hitStop: true,
        invertCamera: false,
        autoRecenter: true
    };

    // ---------------------------------------------------------------------
    // Debug IO Bridge (exposed for DevTools JSON snapshots)
    // ---------------------------------------------------------------------
    const _debugIO = window.flux._debugIO = window.flux._debugIO || {};
    _debugIO.settings = _settings;
    _debugIO.input = _debugIO.input || {};
    _debugIO.perf = _debugIO.perf || { frame: 0, rawDt: 0, dt: 0, fps: 0, avgFps: 0 };


    // ---------------------------------------------------------------------
    // Touch helpers (multi-touch safe)
    // ---------------------------------------------------------------------
    function _findTouchById(touchList, id) {
        if (id === null || id === undefined) return null;
        if (!touchList) return null;
        for (let i = 0; i < touchList.length; i++) {
            const t = touchList[i];
            if (t && t.identifier === id) return t;
        }
        return null;
    }

    function _endedTouchById(changedTouches, id) {
        if (id === null || id === undefined) return null;
        if (!changedTouches) return null;
        for (let i = 0; i < changedTouches.length; i++) {
            const t = changedTouches[i];
            if (t && t.identifier === id) return t;
        }
        return null;
    }


    function init() {
        _container = document.getElementById('game-container');

        // 1. Scene
        _scene = new THREE.Scene();
        _scene.background = new THREE.Color(_config.bgColor);
        _scene.fog = new THREE.FogExp2(_config.fogColor, _config.fogDensity);

        // 2. Camera
        const aspect = _config.internalWidth / _config.internalHeight;
_camera = new THREE.PerspectiveCamera(60, aspect, 0.1, 500);
_camera.position.set(0, 14, 22);
        _camera.lookAt(0, 0, 0);
        _scene.add(_camera); // Ensure camera is in scene for children to render

        // 3. Renderer
// 3. Renderer
        _renderer = new THREE.WebGLRenderer({ 
            antialias: false,
            powerPreference: "high-performance",
            precision: "mediump", // Mobile optimization: faster shaders
            stencil: false,       // Disable stencil buffer if not used
            depth: true
        });
        _renderer.setPixelRatio(1); // Force 1:1 pixel ratio, we handle scaling via setSize
        _renderer.autoClear = false; // We manage clearing via background or manual calls if needed (though scene.background handles color)
        // Expose renderer for DevTools
        if (_gameManager) _gameManager.renderer = _renderer; 
        else window.flux.gameInstance = { renderer: _renderer }; // Temp hook
_container.appendChild(_renderer.domElement);

// --- Video Overlay Enforcement ---
        // --- Overlay Video Logic Removed (Switched to GIF) ---
        // 5. Environment
        createParticles();
        createArena();
createArena();
        createHolographicRings();
// 5.5 Game Manager
_gameManager = new window.flux.GameManager(_scene, 'ui-layer', _camera, _renderer);
        
        // 5.5.1 Audio Manager
        _audioManager = new window.flux.AudioManager();
        _gameManager.audioManager = _audioManager;

        // 5.6 Camera Manager
        _cameraManager = new window.flux.CameraManager(_camera, _scene);
        _gameManager.cameraManager = _cameraManager;

        // 5.7 Dev Tools
if (window.flux.DevTools) {
            new window.flux.DevTools(_gameManager);
        }
// 5.8 Water Overlay, Light Shafts, Stadium, Glyphs
        _waterOverlay = new window.flux.WaterOverlay(_camera);
        _lightShafts = new window.flux.LightShafts(_scene);
        _stadium = new window.flux.Stadium(_scene);
        _glyphManager = new window.flux.GlyphManager(_scene);
        
if (_gameManager) {
            _gameManager.glyphManager = _glyphManager;
            _gameManager.waterOverlay = _waterOverlay;
            _gameManager.lightShafts = _lightShafts;
            _gameManager.stadium = _stadium;
        }
        // 6. Teams Setup
        _homeTeam = new window.flux.Team(_scene, 'home', 1, 0x00aaff, true);
        _awayTeam = new window.flux.Team(_scene, 'away', -1, 0xff6666, false);

        // 7. Ball
        _ball = new window.flux.Ball(_scene);

        // IMPROVED: Link ball to camera for smart framing
        _cameraManager.setBall(_ball);

        // 8. Team Roster Models
        const roles = ['LF', 'RF', 'MF', 'LD', 'RD', 'GL'];
        const homeRoster = {
            LF: { name: 'Tidus', url: 'https://cdn.tinyglb.com/models/da788bef258c4f0b8d9ef1acc19c5567.glb' },
            RF: { name: 'Wakka', url: 'https://cdn.tinyglb.com/models/59114c98951647c9b8da74b0bd3636cb.glb' },
            MF: { name: 'Letty', url: 'https://cdn.tinyglb.com/models/43ace34c6fd94215967e842bf909da5e.glb' },
            LD: { name: 'Datto', url: 'https://cdn.tinyglb.com/models/e6d67ecb2e4c4715bd73a40795e1d3d5.glb' },
            RD: { name: 'Jassu', url: 'https://cdn.tinyglb.com/models/8216459567354e63958d4108d828de98.glb' },
            GL: { name: 'Botta', url: 'https://cdn.tinyglb.com/models/ad155efedc0d48fdad09da3e1cae9c97.glb' }
        };

const applyStats = (p, role, isHome) => {
const teamLevel = isHome ? 25 : 8; // Nerfed CPU level significantly (was 15)
            window.flux.Team.generateStats(p, role, teamLevel, isHome);

            if (p.characterName.includes('Tidus')) {
                p.stats.SH += 5;
                p.stats.SP += 3;
            } else if (p.characterName.includes('Wakka')) {
                p.stats.SH += 3;
                p.stats.EN += 5;
            } else if (p.characterName.includes('Brother')) {
                p.stats.SP = 99;
            }

            p._updateDerivedStats();
        };

        let homeLoaded = 0;
        const roleGltfs = {};

        const finalizeTeams = () => {
            roles.forEach(role => {
                const gltf = roleGltfs[role] || roleGltfs.LF;

                const p = (role === 'GL')
                    ? new window.flux.Goalie(_scene, role)
                    : new window.flux.AIPlayer(_scene, role);

                const entry = homeRoster[role];
                p.characterName = entry ? `CPU ${entry.name}` : 'CPU';
                applyStats(p, role, false);

                if (gltf && gltf.scene) {
                    const clone = THREE.SkeletonUtils.clone(gltf.scene);
                    p.setMesh(clone, gltf.animations || []);
                } else {
                    console.warn('Missing GLTF for away role:', role);
                }

                _awayTeam.addPlayer(p);
            });

            const allPlayers = [..._homeTeam.players, ..._awayTeam.players];
            allPlayers.forEach(p => {
                if (p.ballRef === null) p.ballRef = _ball;
            });

            _homeTeam.activePlayer = _homeTeam.players.find(p => p.role === 'MF');

            if (_homeTeam.activePlayer) {
                _homeTeam.activePlayer.techs.tackle = 'venom';
                _homeTeam.activePlayer.techs.shoot = 'sphere';
                console.log('Equipped Home MF with Venom Tackle & Sphere Shot');
            }

const awayMF = _awayTeam.players.find(p => p.role === 'MF');
            // Removed guaranteed Wither tackle for Away MF to reduce difficulty
            _awayTeam.setFormation('Counter');

            const awayGL = _awayTeam.players.find(p => p.role === 'GL');
            // Removed guaranteed Super Goalie for Away GL to make scoring easier

            _homeTeam.assignMarks(_awayTeam);
            _awayTeam.assignMarks(_homeTeam);

            document.getElementById('loading').style.display = 'none';
            if (_gameManager) {
                _gameManager.registerTeams(_homeTeam, _awayTeam, _ball);

                _menuManager = new window.flux.MenuManager(_gameManager);
                _menuManager.show();
            }
        };

roles.forEach(role => {
            const entry = homeRoster[role];
            if (!entry) return;

            const onComplete = () => {
                homeLoaded++;
                if (homeLoaded >= roles.length) {
                    finalizeTeams();
                }
            };

            window.flux.AssetLoader.loadModel(entry.url, (gltf) => {
                roleGltfs[role] = gltf;

                const p = (role === 'GL')
                    ? new window.flux.Goalie(_scene, role)
                    : new window.flux.AIPlayer(_scene, role);

                p.characterName = entry.name;
                applyStats(p, role, true);

                const clone = THREE.SkeletonUtils.clone(gltf.scene);
                p.setMesh(clone, gltf.animations);
                _homeTeam.addPlayer(p);

                onComplete();
            }, undefined, (err) => {
                console.error('Failed to load model', entry.name, entry.url, err);
                
                // Fallback Mesh (Red Box)
                const fallbackGeo = new THREE.BoxGeometry(1, 2, 1);
                const fallbackMat = new THREE.MeshBasicMaterial({ color: 0xff0000, wireframe: true });
                const fallbackMesh = new THREE.Mesh(fallbackGeo, fallbackMat);
                
                // Store dummy in roleGltfs for away team cloning
                roleGltfs[role] = { scene: fallbackMesh, animations: [] };

                const p = (role === 'GL')
                    ? new window.flux.Goalie(_scene, role)
                    : new window.flux.AIPlayer(_scene, role);

                p.characterName = entry.name + " (Error)";
                applyStats(p, role, true);
                
                p.setMesh(fallbackMesh.clone(), []);
                _homeTeam.addPlayer(p);

                onComplete();
            });
        });

        // 8. Input
        setupInputs();

        // 9. Loop
        _clock = new THREE.Clock();
        requestAnimationFrame(animate);

        // Handle resize
        window.addEventListener('resize', onResize);
        onResize();
    }

function createParticles() {
        const count = 1500; // Increased count
        const geometry = new THREE.BufferGeometry();
        const vertices = [];
        const offsets = []; // Random offsets for independent bobbing

        for (let i = 0; i < count; i++) {
            vertices.push(
                (Math.random() - 0.5) * 80, // Wider spread X
                (Math.random() - 0.5) * 50, // Wider spread Y
                (Math.random() - 0.5) * 80  // Wider spread Z
            );
            offsets.push(Math.random() * 100);
        }

        geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        geometry.setAttribute('aOffset', new THREE.Float32BufferAttribute(offsets, 1));

        const material = new THREE.ShaderMaterial({
            uniforms: _particleUniforms,
            transparent: true,
            depthWrite: false,
            blending: THREE.AdditiveBlending,
vertexShader: `
                uniform float uTime;
                attribute float aOffset;
                varying float vAlpha;
                void main() {
                    vec3 pos = position;
                    // Bobbing motion: Sine wave based on time + random offset
                    float bob = sin(uTime * 0.5 + aOffset) * 2.0;
                    pos.y += bob;
                    
                    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
                    gl_Position = projectionMatrix * mvPosition;
                    
                    // Size attenuation - Small and shimmery
                    float sizeBase = 2.0 + sin(uTime * 3.0 + aOffset) * 1.0; 
                    gl_PointSize = sizeBase * (20.0 / -mvPosition.z);
                    
                    // Fade based on distance/height
                    vAlpha = 0.5 + 0.5 * sin(uTime * 2.0 + aOffset);
                }
            `,
            fragmentShader: `
                varying float vAlpha;
                void main() {
                    // Soft glow particle (Dust mote)
                    vec2 coord = gl_PointCoord - vec2(0.5);
                    float dist = length(coord);
                    if(dist > 0.5) discard;
                    
                    // Soft falloff for shimmer
                    float strength = 1.0 - (dist * 2.0);
                    strength = pow(strength, 2.0);
                    
                    // Cyan/Blue tint, additive feel
                    gl_FragColor = vec4(0.7, 0.9, 1.0, vAlpha * strength * 0.8);
                }
            `
        });

        const points = new THREE.Points(geometry, material);
        points.frustumCulled = false;
        _scene.add(points);
    }

function createArena() {
        // Group for rotation
        window.flux.arenaGroup = new THREE.Group();
        _scene.add(window.flux.arenaGroup);

        const geometry = new THREE.SphereGeometry(_config.arenaRadius, 32, 32);
        
        // --- 1. Base Sphere (Faint Grid) ---
        const texLoader = new THREE.TextureLoader();
        const arenaTex = texLoader.load('https://i.postimg.cc/W1LsH68Q/file-0000000023ec71f596593829e8118760-(1).png');
        arenaTex.magFilter = THREE.NearestFilter;
        arenaTex.minFilter = THREE.NearestFilter;
        arenaTex.wrapS = THREE.RepeatWrapping;
        arenaTex.wrapT = THREE.RepeatWrapping;
        arenaTex.repeat.set(6, 4);

        const material = new THREE.MeshBasicMaterial({
            map: arenaTex,
            color: 0x446688,
            wireframe: false,
            transparent: true,
            opacity: 0.15, 
            blending: THREE.AdditiveBlending,
            side: THREE.BackSide,
            depthWrite: false
        });
            
        const arena = new THREE.Mesh(geometry, material);
        window.flux.arenaGroup.add(arena);
        window.flux.arenaMesh = arena;

        // --- 2. Inner Hex Grid (Warp Effect) ---
        // Reuse existing hex generation logic but attach to group
        const hexTex = (() => {
            const c = document.createElement('canvas');
            c.width = 512; c.height = 512;
            const ctx = c.getContext('2d');
            ctx.clearRect(0,0,512,512);
            ctx.strokeStyle = 'rgba(0, 255, 255, 0.5)';
            ctx.lineWidth = 2;
            const r = 64;
            const w = r * 2;
            const h = Math.sqrt(3) * r;
            for(let y = -1; y < 512/h + 2; y++) {
                for(let x = -1; x < 512/(w*0.75) + 2; x++) {
                    const cx = x * w * 0.75;
                    const cy = y * h + (x%2===0 ? 0 : h/2);
                    ctx.beginPath();
                    for(let i=0; i<6; i++) {
                        const ang = Math.PI/3 * i;
                        ctx.lineTo(cx + Math.cos(ang)*r, cy + Math.sin(ang)*r);
                    }
                    ctx.closePath();
                    ctx.stroke();
                }
            }
            return new THREE.CanvasTexture(c);
        })();
        hexTex.wrapS = THREE.RepeatWrapping;
        hexTex.wrapT = THREE.RepeatWrapping;
        hexTex.repeat.set(4, 2);

        const arenaUniforms = THREE.UniformsUtils.merge([
            THREE.UniformsLib['common'],
            _arenaUniforms,
            { 
                tMap: { value: hexTex },
                uOpacity: { value: 0.1 } 
            }
        ]);

        const material2 = new THREE.ShaderMaterial({
            uniforms: arenaUniforms,
            transparent: true,
            side: THREE.BackSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            vertexShader: `
                uniform float uTime;
                uniform vec3 uImpactPos;
                uniform float uImpactStr;
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    vec3 pos = position;
                    float dist = distance(pos, uImpactPos);
                    float radius = 20.0;
                    if (dist < radius) {
                        float t = dist / radius;
                        float bulge = (1.0 - t) * (1.0 - t);
                        vec3 normal = normalize(pos);
                        pos += normal * (bulge * uImpactStr);
                    }
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
                }
            `,
            fragmentShader: `
                uniform sampler2D tMap;
                uniform float uImpactStr;
                uniform float uOpacity;
                varying vec2 vUv;
                void main() {
                    vec4 texColor = texture2D(tMap, vUv);
                    float alpha = uOpacity * texColor.a;
                    alpha += uImpactStr * 0.02; 
                    vec3 color = texColor.rgb * vec3(0.2, 0.8, 1.0);
                    gl_FragColor = vec4(color, alpha);
                }
            `
        });

        const arena2 = new THREE.Mesh(geometry, material2);
        arena2.scale.setScalar(0.98);
        window.flux.arenaGroup.add(arena2);
        window.flux.arenaMesh2 = arena2;

        // --- 3. TRIBAL STRIP (Equator) ---
        const tribalTex = (() => {
            const c = document.createElement('canvas');
            c.width = 1024; c.height = 128;
            const ctx = c.getContext('2d');
            ctx.clearRect(0,0,1024,128);
            
            // Background Pattern
            ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
            ctx.fillRect(0, 10, 1024, 108);

            // Detailed Tribal Glyphs
            ctx.fillStyle = '#ffffff';
            const blockW = 64;
            for(let x=0; x<1024; x+=blockW) {
                // Outer Box
                ctx.fillRect(x+4, 15, blockW-8, 98);
                // Inner Cut
                ctx.clearRect(x+12, 25, blockW-24, 78);
                // Center Dot
                ctx.fillRect(x+28, 50, 8, 28);
                // Connectors
                ctx.fillRect(x, 60, 12, 8);
                ctx.fillRect(x+blockW-12, 60, 12, 8);
            }
            return new THREE.CanvasTexture(c);
        })();
        tribalTex.wrapS = THREE.RepeatWrapping;
        tribalTex.wrapT = THREE.ClampToEdgeWrapping;
        tribalTex.repeat.set(4, 1);

        // Custom Shader for Color Shifting
        window.flux.tribalUniforms = {
            uTime: { value: 0 },
            uColor: { value: new THREE.Color(0x00ffff) }, // Default Cyan
            tTex: { value: tribalTex }
        };

        const tribalMat = new THREE.ShaderMaterial({
            uniforms: window.flux.tribalUniforms,
            transparent: true,
            side: THREE.DoubleSide,
            blending: THREE.AdditiveBlending,
            depthWrite: false,
            vertexShader: `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
                }
            `,
            fragmentShader: `
                uniform float uTime;
                uniform vec3 uColor;
                uniform sampler2D tTex;
                varying vec2 vUv;
                void main() {
                    vec4 tex = texture2D(tTex, vec2(vUv.x * 2.0 + uTime * 0.05, vUv.y));
                    float alpha = tex.a * 0.8;
                    // Pulse
                    float pulse = 0.8 + 0.2 * sin(uTime * 2.0 + vUv.x * 10.0);
                    gl_FragColor = vec4(uColor * pulse, alpha);
                }
            `
        });

        const tribalGeo = new THREE.CylinderGeometry(_config.arenaRadius * 0.95, _config.arenaRadius * 0.95, 12, 64, 1, true);
        const tribalMesh = new THREE.Mesh(tribalGeo, tribalMat);
        tribalMesh.rotation.x = 0; // Upright cylinder matches sphere equator
        window.flux.arenaGroup.add(tribalMesh);

        // --- 4. HOOKED ARROWS (Above/Below Strip) ---
        const arrowTex = (() => {
            const c = document.createElement('canvas');
            c.width = 512; c.height = 64;
            const ctx = c.getContext('2d');
            ctx.clearRect(0,0,512,64);
            
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 4;
            ctx.lineCap = 'round';
            ctx.shadowBlur = 5;
            ctx.shadowColor = '#ffffff';

            const step = 64;
            for(let x=0; x<512; x+=step) {
                // Double Hook Arrow
                ctx.beginPath();
                // Top Hook
                ctx.moveTo(x+20, 10); ctx.lineTo(x+32, 20); ctx.lineTo(x+44, 10);
                // Shaft
                ctx.moveTo(x+32, 20); ctx.lineTo(x+32, 44);
                // Bottom Hook
                ctx.moveTo(x+20, 54); ctx.lineTo(x+32, 44); ctx.lineTo(x+44, 54);
                ctx.stroke();
            }
            return new THREE.CanvasTexture(c);
        })();
        arrowTex.wrapS = THREE.RepeatWrapping;
        arrowTex.repeat.set(4, 1);

        const arrowMat = new THREE.MeshBasicMaterial({
            map: arrowTex,
            color: 0x00ffff,
            transparent: true,
            opacity: 0.6,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide,
            depthWrite: false
        });

        // Top Ring
        const arrowGeoTop = new THREE.CylinderGeometry(_config.arenaRadius * 0.92, _config.arenaRadius * 0.92, 8, 64, 1, true);
        const arrowMeshTop = new THREE.Mesh(arrowGeoTop, arrowMat);
        arrowMeshTop.position.y = 12;
        window.flux.arenaGroup.add(arrowMeshTop);

        // Bottom Ring
        const arrowMeshBot = new THREE.Mesh(arrowGeoTop, arrowMat);
        arrowMeshBot.position.y = -12;
        window.flux.arenaGroup.add(arrowMeshBot);

        // --- 5. TOP GLYPHS (Dome) ---
        const topGlyphTex = (() => {
            const c = document.createElement('canvas');
            c.width = 512; c.height = 512;
            const ctx = c.getContext('2d');
            ctx.clearRect(0,0,512,512);
            
            ctx.strokeStyle = 'rgba(100, 200, 255, 0.5)';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(256, 256, 200, 0, Math.PI*2);
            ctx.stroke();
            
            // Intricate pattern
            for(let i=0; i<8; i++) {
                const a = (i/8)*Math.PI*2;
                const x = 256 + Math.cos(a)*150;
                const y = 256 + Math.sin(a)*150;
                ctx.beginPath();
                ctx.arc(x, y, 40, 0, Math.PI*2);
                ctx.stroke();
                // Connector
                ctx.beginPath();
                ctx.moveTo(256, 256);
                ctx.lineTo(x, y);
                ctx.stroke();
            }
            return new THREE.CanvasTexture(c);
        })();

        const topGlyphMat = new THREE.MeshBasicMaterial({
            map: topGlyphTex,
            transparent: true,
            opacity: 0.4,
            blending: THREE.AdditiveBlending,
            side: THREE.DoubleSide,
            depthWrite: false
        });

        const topGlyphGeo = new THREE.PlaneGeometry(60, 60);
        const topGlyph = new THREE.Mesh(topGlyphGeo, topGlyphMat);
        topGlyph.rotation.x = -Math.PI / 2;
        topGlyph.position.y = 35; // Near top of dome
        window.flux.arenaGroup.add(topGlyph);

        // --- NEW: FFX GOAL MODELS ---
        const goalUrl = 'https://cdn.tinyglb.com/models/a516bd90fa7c4dedb5dcbfdf803f13d5.glb';
        
        const onGoalLoaded = (model, isFallback) => {
            const goalA = model;
            // Moved down ~15ft (4.5m) total as requested, pushed back to edge
            goalA.position.set(0, -4.5, -46);
            
            if (!isFallback) {
                goalA.scale.setScalar(54.0); // Increased 50% (was 36.0)
            }
            // Setup Goal A
            goalA.traverse(c => {
                if(c.isMesh) {
                    c.frustumCulled = false; // CRITICAL: Prevent culling
                    c.renderOrder = 0;
                    
                    // Ensure material is visible
                    if (c.material) {
                        c.material.color.setHex(0xffffff); // White to show original texture/colors (was blue)
                        c.material.transparent = false;
                        c.material.opacity = 1.0;
                        c.material.side = THREE.DoubleSide;
                        c.material.depthWrite = true;
                        c.material.depthTest = true;
                    }
                }
            });
            // Add goals to SCENE, not arenaGroup (they shouldn't rotate with the sphere)
            _scene.add(goalA);

            // Setup Goal B
            const goalB = isFallback ? goalA.clone() : THREE.SkeletonUtils.clone(goalA);

            goalB.position.set(0, -4.5, 46); // Moved closer (was 45) and down
            goalB.rotation.y = Math.PI;
            // Ensure Goal B meshes are also persistent
            goalB.traverse(c => {
                if(c.isMesh) c.frustumCulled = false;
            });

            _scene.add(goalB);
        };

        window.flux.AssetLoader.loadModel(goalUrl, (gltf) => {
            onGoalLoaded(gltf.scene, false);
        }, undefined, (err) => {
            console.warn("Goal model failed to load. Using fallback.", err);
            const geo = new THREE.BoxGeometry(75, 45, 10); // Fallback massive box (Scaled 1.5x)
            const fallbackMat = new THREE.MeshBasicMaterial({ color: 0xffffff, wireframe: true });
            const fallback = new THREE.Mesh(geo, fallbackMat);
            onGoalLoaded(fallback, true);
        });

        // --- NEW: MASSIVE FIELD MARKINGS ---
        createFieldMarkings();
    }

function createFieldMarkings() {
        const size = 1024;
        const c = document.createElement('canvas');
        c.width = size; c.height = size;
        const ctx = c.getContext('2d');
        const cx = size/2; const cy = size/2;

        const draw = () => {
            ctx.clearRect(0, 0, size, size);

            // Glow Settings
            ctx.shadowBlur = 15;
            ctx.shadowColor = '#00ffff';
            ctx.strokeStyle = 'rgba(100, 255, 255, 0.9)';
            ctx.lineWidth = 4;
            ctx.lineCap = 'round';

            // 1. Outer Runic Ring
            ctx.beginPath();
            ctx.arc(cx, cy, 480, 0, Math.PI*2);
            ctx.stroke();

            // 2. Complex Geometric Star (The "Cool Big Glyph")
            ctx.save();
            ctx.translate(cx, cy);
            
            // Layer A: 3 Overlapping Squares (12 points)
            ctx.strokeStyle = 'rgba(0, 200, 255, 0.6)';
            ctx.lineWidth = 2;
            for(let i=0; i<3; i++) {
                ctx.rotate(Math.PI / 6);
                ctx.strokeRect(-350, -350, 700, 700);
            }
            
            // Layer B: Inner Circles
            ctx.strokeStyle = 'rgba(100, 255, 255, 0.8)';
            ctx.lineWidth = 5;
            ctx.beginPath(); ctx.arc(0, 0, 320, 0, Math.PI*2); ctx.stroke();
            ctx.beginPath(); ctx.arc(0, 0, 100, 0, Math.PI*2); ctx.stroke();

            // Layer C: Central Emblem (Blitzball-ish)
            ctx.beginPath();
            ctx.moveTo(0, -80); ctx.lineTo(60, 40); ctx.lineTo(-60, 40); ctx.closePath();
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(0, 80); ctx.lineTo(-60, -40); ctx.lineTo(60, -40); ctx.closePath();
            ctx.stroke();

            ctx.restore();

            // 3. Midfield Line
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.5)';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.moveTo(0, cy); ctx.lineTo(size, cy);
            ctx.stroke();

            // 4. Goal Boxes (Trapezoids)
            const drawGoalBox = (yPos, dir) => {
                ctx.beginPath();
                ctx.moveTo(cx - 150, yPos);
                ctx.lineTo(cx + 150, yPos);
                ctx.lineTo(cx + 225, yPos + (dir * 120));
                ctx.lineTo(cx - 225, yPos + (dir * 120));
                ctx.closePath();
                ctx.stroke();
            };
            drawGoalBox(50, 1); // Top
            drawGoalBox(size-50, -1); // Bottom

            // 5. Runes Text Ring
            ctx.font = '36px Spira, monospace'; 
            ctx.fillStyle = 'rgba(0, 255, 255, 0.8)';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            
            const runes = "YEVON SIN ZANARKAND ETERNAL CALM SPHERE POOL BLITZ ACE ";
            const runeCount = 40;
            for(let i=0; i<runeCount; i++) {
                const angle = (i / runeCount) * Math.PI * 2;
                const r = 440;
                const x = cx + Math.cos(angle) * r;
                const y = cy + Math.sin(angle) * r;
                
                ctx.save();
                ctx.translate(x, y);
                ctx.rotate(angle + Math.PI/2);
                const char = runes[i % runes.length];
                ctx.fillText(char, 0, 0);
                ctx.restore();
            }
        };

        // Attempt to load font first
        document.fonts.load('36px Spira').then(() => {
            draw();
        }).catch(() => {
            draw();
        });

        const tex = new THREE.CanvasTexture(c);
        tex.anisotropy = 16;

        // Floor Plane (Deep)
        const geo = new THREE.PlaneGeometry(90, 90);
        const mat = new THREE.MeshBasicMaterial({
            map: tex,
            transparent: true,
            opacity: 0.9,
            side: THREE.DoubleSide,
            depthWrite: false,
            blending: THREE.AdditiveBlending
        });

        const field = new THREE.Mesh(geo, mat);
        field.rotation.x = -Math.PI / 2;
        field.position.y = -8.0; // Sunk deep
        _scene.add(field);
    }

function createHolographicRings() {
        // Floating Holographic Rings (Mid-height)
        const ringGeo = new THREE.TorusGeometry(20, 0.1, 16, 100);
        const ringMat = new THREE.MeshBasicMaterial({ color: 0x00ffff, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending });
        const ring1 = new THREE.Mesh(ringGeo, ringMat);
        ring1.rotation.x = Math.PI / 2;
        ring1.position.y = 0;
        _scene.add(ring1);
        
        const ring2 = new THREE.Mesh(ringGeo, ringMat);
        ring2.rotation.x = Math.PI / 2;
        ring2.scale.setScalar(1.2);
        ring2.position.y = 4.0;
        _scene.add(ring2);

        // Animate Rings (integrated into main loop to avoid a second RAF on mobile)
        let _ringTime = 0;
        const _ringUpdate = (dt) => {
            _ringTime += dt;
            if (ring1) {
                ring1.rotation.z += dt * 0.9;
                ring1.scale.setScalar(1.0 + Math.sin(_ringTime * 0.5) * 0.05);
            }
            if (ring2) {
                ring2.rotation.z -= dt * 0.75;
                ring2.position.y = 4.0 + Math.cos(_ringTime * 0.7) * 1.0;
            }
        };
        if (window.flux && window.flux._runtimeUpdaters) window.flux._runtimeUpdaters.push(_ringUpdate);
    }

    // --- INPUT SYSTEM ---
// --- INPUT SYSTEM ---
const _keys = {};
// Globals moved to below helper

    // Helper: Analyze curve geometry for analog control
    const analyzeSwipeCurve = (points) => {
        if (points.length < 3) return { intensity: 0, speed: 0, dx: 0, dy: 0 };
        
        const pStart = points[0];
        const pEnd = points[points.length - 1];
        const midIdx = Math.floor(points.length / 2);
        const pMid = points[midIdx];

        const dx = pEnd.x - pStart.x;
        const dy = pEnd.y - pStart.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        const dt = pEnd.t - pStart.t;
        const speed = (dt > 0) ? dist / dt : 0; // px/ms

        if (dist < 50) return { intensity: 0, speed: speed, dx, dy };

        const vSM_x = pMid.x - pStart.x;
        const vSM_y = pMid.y - pStart.y;

        // Cross product gives signed area/curvature direction
        const cross = (dx * vSM_y) - (dy * vSM_x);
        // Normalize by distance squared to get a curvature ratio independent of scale
const intensity = cross / (dist * dist);

        return { intensity, speed, dx, dy };
    };
    let _swipePoints = []; // Track swipe history for curves
    const _aimInput = { x: 0, y: 0, active: false }; // NEW: Aim joystick

    const _actionBuffer = { active: false, timestamp: 0, duration: 300 };

    const _camFwd = new THREE.Vector3();
    const _camRight = new THREE.Vector3();
    const _upAxis = new THREE.Vector3(0, 1, 0);

    function setupInputs() {
        // Keyboard
        window.addEventListener('keydown', (e) => {
            _keys[e.key] = true;
            if (e.code === 'Space' && _homeTeam && _homeTeam.activePlayer && _ball) {
                _homeTeam.activePlayer.throwBall(_ball);
            }
            // NEW: Tackle on Shift
            if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
                if (_homeTeam && _homeTeam.activePlayer) {
                    const p = _homeTeam.activePlayer;
                    if (!p.hasBall) {
                        p.dash(p.inputVector.x, p.inputVector.z);
                    }
                }
            }
            updateInputVector();
        });
        window.addEventListener('keyup', (e) => { _keys[e.key] = false; updateInputVector(); });

        // --- FLOATING JOYSTICK (Movement) ---
        const hitZone = document.getElementById('joystick-hit-zone');
        const visuals = document.getElementById('joystick-visual-container');
        const base = document.getElementById('joystick-base');
        const knob = document.getElementById('joystick-knob');

        let startX = 0, startY = 0;
        let dragging = false;
        const maxDist = 40;

        let moveTouchId = null;
        const moveDeadzonePx = 6;

        // Expose move joystick state for snapshots
        const _dbg = window.flux._debugIO = window.flux._debugIO || {};
        _dbg.settings = _settings;
        _dbg.input = _dbg.input || {};
        _dbg.input.move = _dbg.input.move || {};
        _dbg.input.move.vector = _input;
        _dbg.input.move.dragging = dragging;
        _dbg.input.move.touchId = moveTouchId;


        const handleStart = (clientX, clientY) => {
            dragging = true;
            startX = clientX;

            if (_dbg && _dbg.input && _dbg.input.move) {
                _dbg.input.move.dragging = dragging;
            }

            startY = clientY;

            visuals.style.display = 'block';
            visuals.style.left = `${clientX}px`;
            visuals.style.top = `${clientY}px`;

            knob.style.transform = `translate(-50%, -50%)`;

            createRipple(clientX, clientY);

            _input.x = 0;
            _input.y = 0;
            updateInputVector();
        };

        const handleMove = (clientX, clientY) => {
            if (!dragging) return;

            let dx = clientX - startX;
            let dy = clientY - startY;

            const dist = Math.sqrt(dx*dx + dy*dy);


            // Deadzone to prevent drift from tiny thumb jitter
            if (dist < moveDeadzonePx) {
                dx = 0;
                dy = 0;
            }

            if (dist > maxDist) {
                dx = (dx / dist) * maxDist;
                dy = (dy / dist) * maxDist;
            }

            knob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;

            _input.x = (dx / maxDist) * _settings.joystickSensitivity;
            _input.y = (dy / maxDist) * _settings.joystickSensitivity;
            updateInputVector();
        };

        const handleEnd = () => {
            if (!dragging) return;
            dragging = false;

            moveTouchId = null;

            visuals.style.display = 'none';

            if (_dbg && _dbg.input && _dbg.input.move) {
                _dbg.input.move.dragging = dragging;
                _dbg.input.move.touchId = moveTouchId;
            }


            _input.x = 0;
            _input.y = 0;
            updateInputVector();
        };

        if (hitZone) {
            hitZone.addEventListener('touchstart', (e) => {
                if (e.cancelable) e.preventDefault();
                const t = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0] : e.touches[0];
                moveTouchId = t ? t.identifier : null;
                if (_dbg && _dbg.input && _dbg.input.move) {
                    _dbg.input.move.touchId = moveTouchId;
                }
                handleStart(t.clientX, t.clientY);
            }, { passive: false });

            window.addEventListener('touchmove', (e) => {
                if (!dragging) return;
                if (e.cancelable) e.preventDefault();
                const t = _findTouchById(e.touches, moveTouchId);
                if (!t) return;
                handleMove(t.clientX, t.clientY);
            }, { passive: false });

            window.addEventListener('touchend', (e) => {
                if (!dragging) return;
                const tEnd = _endedTouchById(e.changedTouches, moveTouchId);
                if (!tEnd) return; // Ignore other fingers lifting
                handleEnd();
            });
            window.addEventListener('touchcancel', (e) => {
                if (!dragging) return;
                const tEnd = _endedTouchById(e.changedTouches, moveTouchId);
                if (!tEnd) return;
                handleEnd();
            });

            hitZone.addEventListener('mousedown', (e) => {
                handleStart(e.clientX, e.clientY);
            });
            window.addEventListener('mousemove', (e) => {
                if (dragging) handleMove(e.clientX, e.clientY);
            });
            window.addEventListener('mouseup', handleEnd);
        }

        // --- NEW: AIM JOYSTICK (Right side) ---
        setupAimJoystick();

        // --- NEW: TACKLE BUTTON ---
        setupTackleButton();

        // Swipe Detection
// Swipe Detection
        let swipeStart = { x: 0, y: 0, t: 0 };
        let swipeTouchId = null;
        
        // Expose swipe/throw gesture state for snapshots
        _dbg.input.swipe = _dbg.input.swipe || {};
        _dbg.input.swipe.start = swipeStart;
        _dbg.input.swipe.touchId = swipeTouchId;
        _dbg.input.swipe.points = _swipePoints;
const onSwipeStart = (x, y) => {
            swipeStart.x = x;
            swipeStart.y = y;
            swipeStart.t = Date.now();
            _swipePoints = [{x, y, t: Date.now()}];
        };

const onSwipeMove = (x, y) => {
            if (_swipePoints.length > 0) {
                _swipePoints.push({x, y, t: Date.now()});
                createSwipeTrailDot(x, y); // Visual Feedback
            }
        };

const onSwipeEnd = (x, y) => {
            if (_swipePoints.length < 2) return;
            _swipePoints.push({x, y, t: Date.now()});

            const { intensity, speed, dx, dy } = analyzeSwipeCurve(_swipePoints);
            const dist = Math.sqrt(dx*dx + dy*dy);

            if (_homeTeam && _homeTeam.activePlayer && _camera) {
                const p = _homeTeam.activePlayer;

                // --- CURVE BALL DETECTION (Immediate Throw) ---
// --- CURVE BALL DETECTION (Immediate Throw) ---
                if (p.hasBall && !p.isThrowing && !p.isCharging) {
                    // Analog Curve Check: Threshold 0.25 requires a deliberate arc (The "Feat")
                    if (Math.abs(intensity) > 0.25 && dist > 100) {
                        _camera.getWorldDirection(_camFwd);
                        _camFwd.y = 0; _camFwd.normalize();
                        _camRight.crossVectors(_camFwd, _upAxis).normalize();

                        const worldX = (_camRight.x * dx) + (_camFwd.x * -dy);
                        const worldZ = (_camRight.z * dx) + (_camFwd.z * -dy);
                        const throwDir = new THREE.Vector3(worldX, 0, worldZ).normalize();

                        // Map intensity to spin - Drastically reduced sensitivity
                        const rawSpin = Math.abs(intensity) * 300.0; 
                        const speedFactor = Math.min(1.5, speed / 1.0);
                        const spinPower = Math.min(400.0, rawSpin * speedFactor);
                        const spinSign = Math.sign(intensity); 
                        const spinVec = new THREE.Vector3(0, spinPower * spinSign, 0);


                        p.setOverrideAim(throwDir.x, throwDir.z);
                        p.throwBall(window.flux.gameInstance.entities.ball, 'SH', 1.0, spinVec);
                        
                        if (window.flux.gameInstance.floatingText) {
                            window.flux.gameInstance.floatingText.spawn("CURVE", p.mesh.position, "tech");
                        }
                        createRipple(x, y);
                        _swipePoints = [];
                        return; 
                    }
                }

                // --- STANDARD DASH / AIM ---
                _camera.getWorldDirection(_camFwd);
                _camFwd.y = 0;
                if (_camFwd.lengthSq() < 0.001) _camFwd.set(0, 0, -1);
                else _camFwd.normalize();

                _camRight.crossVectors(_camFwd, _upAxis).normalize();

const worldX2 = (_camRight.x * dx) + (_camFwd.x * -dy);
                const worldZ2 = (_camRight.z * dx) + (_camFwd.z * -dy);

                if (p.isThrowing) {
p.setOverrideAim(worldX2, worldZ2);
                    if (window.flux.gameInstance.floatingText) {
                        window.flux.gameInstance.floatingText.spawn("AIM!", p.mesh.position, "default");
                    }
                } else {
if (dist > 50) p.dash(worldX2, worldZ2);
                }

                createRipple(x, y);
            }
_swipePoints = [];
        };

        window.addEventListener('touchstart', (e) => {
            if (e.target.closest('#joystick-hit-zone') ||
                e.target.closest('#action-button') ||
                e.target.closest('#tackle-button') ||
                e.target.closest('#aim-joystick-zone') ||
                e.target.closest('#auto-toggle') ||
                e.target.closest('#settings-button')) return;

            const t = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0] : e.touches[0];
            swipeTouchId = t ? t.identifier : null;
// onSwipeStart(t.clientX, t.clientY); // Fixed syntax error
            if (_dbg && _dbg.input && _dbg.input.swipe) { _dbg.input.swipe.touchId = swipeTouchId; }
            onSwipeStart(t.clientX, t.clientY);
            createRipple(t.clientX, t.clientY);
        }, { passive: false });

window.addEventListener('touchmove', (e) => {
            if (e.target.closest('#joystick-hit-zone') ||
                e.target.closest('#action-button') ||
                e.target.closest('#tackle-button') ||
                e.target.closest('#aim-joystick-zone')) return;
            const t = _findTouchById(e.touches, swipeTouchId);
            if (!t) return;
            onSwipeMove(t.clientX, t.clientY);
        }, { passive: false });

        window.addEventListener('touchend', (e) => {
            if (e.target.closest('#joystick-hit-zone') ||
                e.target.closest('#action-button') ||
                e.target.closest('#tackle-button') ||
                e.target.closest('#aim-joystick-zone') ||
                e.target.closest('#auto-toggle') ||
                e.target.closest('#settings-button')) return;
            const tEnd = _endedTouchById(e.changedTouches, swipeTouchId);
            if (!tEnd) return; // Ignore other fingers lifting
            onSwipeEnd(tEnd.clientX, tEnd.clientY);
            swipeTouchId = null;
            if (_dbg && _dbg.input && _dbg.input.swipe) { _dbg.input.swipe.touchId = swipeTouchId; }
        });

                window.addEventListener('touchcancel', (e) => {
if (e.target.closest('#joystick-hit-zone') ||
                e.target.closest('#action-button') ||
                e.target.closest('#tackle-button') ||
                e.target.closest('#aim-joystick-zone') ||
                e.target.closest('#auto-toggle') ||
                e.target.closest('#settings-button')) return;
            const tEnd = _endedTouchById(e.changedTouches, swipeTouchId);
            if (!tEnd) return; // Ignore other fingers lifting
            onSwipeEnd(tEnd.clientX, tEnd.clientY);
            swipeTouchId = null;
            if (_dbg && _dbg.input && _dbg.input.swipe) { _dbg.input.swipe.touchId = swipeTouchId; }
        
        });
// Mouse Swipe
        window.addEventListener('mousedown', (e) => {
            if (e.target.closest('#joystick-hit-zone') ||
                e.target.closest('#action-button') ||
                e.target.closest('#tackle-button') ||
                e.target.closest('#aim-joystick-zone') ||
                e.target.closest('#auto-toggle') ||
                e.target.closest('#settings-button')) return;

            onSwipeStart(e.clientX, e.clientY);
            createRipple(e.clientX, e.clientY);
        });

        window.addEventListener('mousemove', (e) => {
             if (e.target.closest('#joystick-hit-zone') ||
                e.target.closest('#action-button') ||
                e.target.closest('#tackle-button') ||
                e.target.closest('#aim-joystick-zone')) return;
            // Only track if mouse is down (simulating drag)
            if (e.buttons === 1) {
                onSwipeMove(e.clientX, e.clientY);
            }
        });


        window.addEventListener('mouseup', (e) => {
            if (e.target.closest('#joystick-hit-zone') ||
                e.target.closest('#action-button') ||
                e.target.closest('#tackle-button') ||
                e.target.closest('#aim-joystick-zone') ||
                e.target.closest('#auto-toggle') ||
                e.target.closest('#settings-button')) return;
            onSwipeEnd(e.clientX, e.clientY);
        });

        // Action Button (Shoot/Pass)
        const actionBtn = document.getElementById('action-button');

const setupButton = (btn) => {
            if (!btn) return;

            let btnStartX = 0;
            let btnStartY = 0;
            let isDragging = false;
            let swipePoints = [];
            let actionTouchId = null;

            const attemptAction = () => {
                if (!_homeTeam || !_homeTeam.activePlayer) return false;
                const p = _homeTeam.activePlayer;

                if (p.hasBall && !p.isCharging && !p.isThrowing && p.status.nap <= 0) {
                    p.startCharge();
                    btn.classList.add('active');
                    return true;
                }
                return false;
            };

            const handleStart = (e) => {
                if (e.cancelable) e.preventDefault();

                if (_gameManager && _gameManager.techCopyState.active) {
                    _gameManager.attemptTechCopy();
                    btn.classList.add('active');
                    setTimeout(() => btn.classList.remove('active'), 100);
                    return;
                }

                if (_gameManager && _gameManager.isDemoMode) return;

                let clientX = e.clientX;
                let clientY = e.clientY;
                if (e.changedTouches && e.changedTouches.length) {
                    const t = e.changedTouches[0];
                    actionTouchId = t.identifier;
                    clientX = t.clientX;
                    clientY = t.clientY;
                } else {
                    actionTouchId = null; // mouse
                }
                btnStartX = clientX;
                btnStartY = clientY;
                isDragging = true;
                swipePoints = [{x: clientX, y: clientY, t: Date.now()}];

                _actionBuffer.active = true;
                _actionBuffer.timestamp = Date.now();

                if (attemptAction()) {
                    _actionBuffer.active = false;
                }

                // Attach global listeners to track swipe outside button
                window.addEventListener('touchmove', handleMove, { passive: false });
                window.addEventListener('touchend', handleEnd);
                window.addEventListener('touchcancel', handleEnd);
                window.addEventListener('mousemove', handleMove);
                window.addEventListener('mouseup', handleEnd);
            };

            const handleMove = (e) => {
                if (!isDragging) return;

                // Touch path (multi-touch safe)
                if (e.touches && actionTouchId !== null) {
                    const t = _findTouchById(e.touches, actionTouchId);
                    if (!t) return;
                    swipePoints.push({x: t.clientX, y: t.clientY, t: Date.now()});
                    return;
                }

                // Mouse path
                const clientX = e.clientX;
                const clientY = e.clientY;
                swipePoints.push({x: clientX, y: clientY, t: Date.now()});
            };

const handleEnd = (e) => {
                let dx = 0;
                let dy = 0;
                let validEnd = false;

                // 1. Check Touch
                if (e.changedTouches && actionTouchId !== null) {
                    const tEnd = _endedTouchById(e.changedTouches, actionTouchId);
                    if (tEnd) {
                        dx = tEnd.clientX - btnStartX;
                        dy = tEnd.clientY - btnStartY;
                        validEnd = true;
                        actionTouchId = null;
                    }
                } 
                // 2. Check Mouse
                else if (!e.changedTouches && isDragging) {
                    dx = e.clientX - btnStartX;
                    dy = e.clientY - btnStartY;
                    validEnd = true;
                }

                if (!validEnd) return;

                // Cleanup listeners
                window.removeEventListener('touchmove', handleMove);
                window.removeEventListener('touchend', handleEnd);
                window.removeEventListener('touchcancel', handleEnd);
                window.removeEventListener('mousemove', handleMove);
                window.removeEventListener('mouseup', handleEnd);

                if (!isDragging) return;
                isDragging = false;
                
                const wasBuffered = _actionBuffer.active;
                _actionBuffer.active = false;

                if (_homeTeam && _homeTeam.activePlayer) {
                    const p = _homeTeam.activePlayer;
                    
                    // Curve Analysis
                    let curveData = null;
                    let spinVec = null;

                    // Calculate curve if we have enough data
// Calculate curve if we have enough data
                    if (swipePoints.length > 2) {
                        const analysis = analyzeSwipeCurve(swipePoints);
                        // High threshold for button release too
                        if (Math.abs(analysis.intensity) > 0.25) {
                            curveData = analysis;
                            
                            // Calculate spin vector for mouse/touch unified (Conservative values)
                            const spinPower = Math.min(400.0, Math.abs(analysis.intensity) * 1500.0);
                            const spinSign = Math.sign(analysis.intensity);
                            spinVec = new THREE.Vector3(0, spinPower * spinSign, 0);
                        }
}

                    // EXECUTE
                    if (p.isCharging) {
                        // Normal Release
                        if (spinVec) {
                            // Unified spin passing
                            p.releaseCharge(dx, dy, { intensity: curveData.intensity, speed: curveData.speed }); 
                        } else {
                            p.releaseCharge(dx, dy, curveData);
                        }
                        btn.classList.remove('active');
                    } 
                    else if (wasBuffered && p.hasBall && !p.isThrowing && p.status.nap <= 0) {
                        // Buffered Tap (Instant Shot)
                        // Force start and release immediately
                        p.startCharge();
                        p.releaseCharge(dx, dy, curveData);
                        btn.classList.remove('active');
                    }
                }
            };

            btn.addEventListener('touchstart', handleStart, { passive: false });
            btn.addEventListener('mousedown', handleStart);
        };
        setupButton(actionBtn);

// Auto Toggle
        const autoBtn = document.getElementById('auto-toggle');
        if (autoBtn) {
            const handleToggle = () => {
                if (_gameManager) {
                    _gameManager.toggleDemoMode();
                    if (_homeTeam && _homeTeam.activePlayer) {
                        _homeTeam.activePlayer.setInput(0, 0);
                    }
                }
            };

            autoBtn.addEventListener('click', handleToggle);
autoBtn.addEventListener('touchstart', (e) => {
                e.preventDefault();
                handleToggle();
            }, { passive: false });
        }

        // NEW: Settings Button
        setupSettingsButton();
    }

    // NEW: Aim Joystick Setup
// NEW: Aim Joystick Setup
function setupAimJoystick() {
        const aimKnob = document.getElementById('aim-joystick-knob');
        const aimVisuals = document.getElementById('aim-joystick-visual');
        const aimZone = document.getElementById('aim-joystick-zone');
        if (!aimZone) return;
        let aimStartX = 0, aimStartY = 0;
        let aimDragging = false;
        const aimMaxDist = 35;
        let aimTouchId = null;

        

        // Expose aim joystick state for snapshots
        const _dbg = window.flux._debugIO = window.flux._debugIO || {};
        _dbg.settings = _settings;
        _dbg.input = _dbg.input || {};
        _dbg.input.aim = _dbg.input.aim || {};
        _dbg.input.aim.vector = _aimInput;
        _dbg.input.aim.dragging = aimDragging;
        _dbg.input.aim.touchId = aimTouchId;
const handleAimStart = (clientX, clientY) => {
            aimDragging = true;
            aimStartX = clientX;

            if (_dbg && _dbg.input && _dbg.input.aim) { _dbg.input.aim.dragging = aimDragging; }

            aimStartY = clientY;
            _aimInput.active = true;

            if (aimVisuals) {
                aimVisuals.style.display = 'block';
                aimVisuals.style.left = `${clientX}px`;
                aimVisuals.style.top = `${clientY}px`;
            }
            if (aimKnob) {
                aimKnob.style.transform = `translate(-50%, -50%)`;
            }
        };

        const handleAimMove = (clientX, clientY) => {
            if (!aimDragging) return;

            let dx = clientX - aimStartX;
            let dy = clientY - aimStartY;

            const dist = Math.sqrt(dx*dx + dy*dy);

            if (dist > aimMaxDist) {
                dx = (dx / dist) * aimMaxDist;
                dy = (dy / dist) * aimMaxDist;
            }

            if (aimKnob) {
                aimKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
            }

            // Normalize and transform to world space
            _aimInput.x = dx / aimMaxDist;
            _aimInput.y = dy / aimMaxDist;

            // Apply aim to player if charging
            if (_homeTeam && _homeTeam.activePlayer) {
                const p = _homeTeam.activePlayer;
                if (p.isCharging || p.isThrowing) {
                    // Transform screen aim to world space
                    _camera.getWorldDirection(_camFwd);
                    _camFwd.y = 0;
                    if (_camFwd.lengthSq() < 0.001) _camFwd.set(0, 0, -1);
                    else _camFwd.normalize();
                    _camRight.crossVectors(_camFwd, _upAxis).normalize();

                    const worldX = (_camRight.x * _aimInput.x) + (_camFwd.x * -_aimInput.y);
                    const worldZ = (_camRight.z * _aimInput.x) + (_camFwd.z * -_aimInput.y);

                    if (Math.abs(worldX) > 0.1 || Math.abs(worldZ) > 0.1) {
                        p.setOverrideAim(worldX, worldZ);
                    }
                }
            }
        };

const handleAimEnd = () => {
            if (!aimDragging) return;
            aimDragging = false;
            _aimInput.active = false;
            _aimInput.x = 0;
            _aimInput.y = 0;

            if (aimVisuals) {
                aimVisuals.style.display = 'none';
            }

            // Clear player aim override
            if (_homeTeam && _homeTeam.activePlayer) {
                _homeTeam.activePlayer.overrideAimVector = null;
            }
        };

        aimZone.addEventListener('touchstart', (e) => {
            if (e.cancelable) e.preventDefault();
            const t = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0] : e.touches[0];
            aimTouchId = t ? t.identifier : null;
            if (_dbg && _dbg.input && _dbg.input.aim) { _dbg.input.aim.touchId = aimTouchId; }
            handleAimStart(t.clientX, t.clientY);
        }, { passive: false });

        window.addEventListener('touchmove', (e) => {
            if (!aimDragging) return;
            if (e.cancelable) e.preventDefault();
            const t = _findTouchById(e.touches, aimTouchId);
            if (!t) return;
            handleAimMove(t.clientX, t.clientY);
        }, { passive: false });

        window.addEventListener('touchend', (e) => {
            if (!aimDragging) return;
            const tEnd = _endedTouchById(e.changedTouches, aimTouchId);
            if (!tEnd) return;
            aimTouchId = null;
            handleAimEnd();
            if (_dbg && _dbg.input && _dbg.input.aim) { _dbg.input.aim.touchId = aimTouchId; _dbg.input.aim.dragging = aimDragging; }
            handleAimEnd();
        });

                window.addEventListener('touchcancel', (e) => {
            if (!aimDragging) return;
                        const tEnd = _endedTouchById(e.changedTouches, aimTouchId);
                        if (!tEnd) return;
                        aimTouchId = null;
                        handleAimEnd();
                        if (_dbg && _dbg.input && _dbg.input.aim) { _dbg.input.aim.touchId = aimTouchId; _dbg.input.aim.dragging = aimDragging; }
                        handleAimEnd();
        });
// Mouse support for desktop testing
        aimZone.addEventListener('mousedown', (e) => {
            handleAimStart(e.clientX, e.clientY);
        });
        window.addEventListener('mousemove', (e) => {
            if (aimDragging) handleAimMove(e.clientX, e.clientY);
        });
        window.addEventListener('mouseup', (e) => {
            if (aimDragging) handleAimEnd();
        });
    }

    // NEW: Tackle Button Setup
    function setupTackleButton() {
        const tackleBtn = document.getElementById('tackle-button');
        if (!tackleBtn) return;

const handleTackle = (e) => {
            if (e.cancelable) e.preventDefault();
            e.stopPropagation(); // Prevent bubbling to joystick

            if (_gameManager && _gameManager.isDemoMode) return;

            if (_homeTeam && _homeTeam.activePlayer) {
                const p = _homeTeam.activePlayer;

                // Visual Feedback immediately
                tackleBtn.classList.add('active');
                setTimeout(() => tackleBtn.classList.remove('active'), 150);

                // If we don't have the ball, dash/tackle
                if (!p.hasBall) {
                    // Get current movement direction or forward
                    let dashX = p.inputVector.x;
                    let dashZ = p.inputVector.z;

                    // If not moving, dash forward relative to player facing
                    if (Math.abs(dashX) < 0.1 && Math.abs(dashZ) < 0.1) {
                        const fwd = new THREE.Vector3(0, 0, 1).applyQuaternion(p.mesh.quaternion);
                        dashX = fwd.x;
                        dashZ = fwd.z;
                    }

                    p.dash(dashX, dashZ);

                    if (window.flux.gameInstance.floatingText) {
                        // Only show text if dash actually happened (cooldown check inside dash)
                        if (p.isDashing) {
                            window.flux.gameInstance.floatingText.spawn("TACKLE!", p.mesh.position, "tech");
                        }
                    }
                } else if (p.isEngaged) {
                    // Break tackle if engaged
                    p.dash(p.inputVector.x, p.inputVector.z);
                }
            }
        };

        tackleBtn.addEventListener('touchstart', handleTackle, { passive: false });
        tackleBtn.addEventListener('mousedown', handleTackle);
    }

    // NEW: Settings Button Setup
// NEW: Settings Button Setup
function setupSettingsButton() {
        const settingsBtn = document.getElementById('settings-button');
        const settingsPanel = document.getElementById('settings-panel');
        const settingsClose = document.getElementById('settings-close');

        if (!settingsBtn || !settingsPanel) return;

        settingsBtn.addEventListener('click', () => {
            settingsPanel.style.display = settingsPanel.style.display === 'none' ? 'block' : 'none';
        });

        if (settingsClose) {
            settingsClose.addEventListener('click', () => {
                settingsPanel.style.display = 'none';
            });
        }

        // Sensitivity slider
        const sensitivitySlider = document.getElementById('sensitivity-slider');
        if (sensitivitySlider) {
            sensitivitySlider.value = _settings.joystickSensitivity * 100;
            sensitivitySlider.addEventListener('input', (e) => {
                _settings.joystickSensitivity = e.target.value / 100;
            });
        }

        // Aim assist toggle
        const aimAssistToggle = document.getElementById('aim-assist-toggle');
        if (aimAssistToggle) {
            aimAssistToggle.checked = _settings.aimAssist;
            aimAssistToggle.addEventListener('change', (e) => {
                _settings.aimAssist = e.target.checked;
            });
        }

        // Camera shake toggle
        const shakeToggle = document.getElementById('shake-toggle');
        if (shakeToggle) {
            shakeToggle.checked = _settings.cameraShake;
            shakeToggle.addEventListener('change', (e) => {
                _settings.cameraShake = e.target.checked;
            });
        }

        // Volume slider
        const volumeSlider = document.getElementById('volume-slider');
        if (volumeSlider && _audioManager) {
            volumeSlider.addEventListener('input', (e) => {
                const vol = e.target.value / 100;
                _audioManager.setVolume(vol);
            });
        }

        // Exit to Menu
        const exitBtn = document.getElementById('exit-to-menu-btn');
        if (exitBtn) {
            exitBtn.addEventListener('click', () => {
                if (_menuManager) {
                    _menuManager.show();
                    if (_gameManager) {
                        _gameManager.state = 'menu';
                        // Stop practice if running
                        if (_gameManager.practiceManager) {
                            _gameManager.practiceManager.stop();
                        }
                    }
                    settingsPanel.style.display = 'none';
                }
            });
        }
    }

    function updateInputVector() {
        let x = _input.x || 0;
        let z = _input.y || 0;

        if (_keys['w'] || _keys['ArrowUp']) z -= 1;
        if (_keys['s'] || _keys['ArrowDown']) z += 1;
        if (_keys['a'] || _keys['ArrowLeft']) x -= 1;
        if (_keys['d'] || _keys['ArrowRight']) x += 1;

        const lenSq = x*x + z*z;
        if (lenSq > 1) {
            const len = Math.sqrt(lenSq);
            x /= len;
            z /= len;
        }

        if (isNaN(x)) x = 0;
        if (isNaN(z)) z = 0;

        if (_camera) {
            _camera.getWorldDirection(_camFwd);
            _camFwd.y = 0;

            if (_camFwd.lengthSq() < 0.001) {
                _camFwd.set(0, 0, -1);
            } else {
                _camFwd.normalize();
            }

            _camRight.crossVectors(_camFwd, _upAxis).normalize();
        } else {
            _camFwd.set(0, 0, -1);
            _camRight.set(1, 0, 0);
        }

        let worldX = (_camFwd.x * -z) + (_camRight.x * x);
        let worldZ = (_camFwd.z * -z) + (_camRight.z * x);

        if (isNaN(worldX) || isNaN(worldZ)) {
            worldX = 0;
            worldZ = 0;
        }

if (_homeTeam && _homeTeam.activePlayer) {
            // FIX: Only allow movement if game is active or in practice
            const gm = window.flux.gameInstance;
            const canMove = gm && !gm.isDemoMode && (gm.state === 'active');
            
            if (canMove) {
                _homeTeam.activePlayer.setInput(worldX, worldZ);
            } else {
                _homeTeam.activePlayer.setInput(0, 0);
            }
        }
}

    function createRipple(x, y) {
        const ripple = document.createElement('div');
        ripple.className = 'touch-ripple';
        ripple.style.left = `${x}px`;
        ripple.style.top = `${y}px`;
        document.getElementById('ui-layer').appendChild(ripple);

        setTimeout(() => {
            if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
        }, 600);

    }

    // NEW: Visual Swipe Trail
    function createSwipeTrailDot(x, y) {
        const dot = document.createElement('div');
        dot.className = 'swipe-trail-dot';
        dot.style.left = `${x - 6}px`; // Center (12px width)
        dot.style.top = `${y - 6}px`;
        document.getElementById('ui-layer').appendChild(dot);
        
        // CSS animation handles removal, but we clean up DOM to be safe
        setTimeout(() => {
            if (dot.parentNode) dot.parentNode.removeChild(dot);
        }, 500);
    }

    function onResize() {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        if (_camera) {
            _camera.aspect = width / height;
            _camera.updateProjectionMatrix();
        }
        
        // Strictly 0.50 as requested
        const resScale = 0.50;
        
        _config.internalWidth = Math.floor(width * resScale);
        _config.internalHeight = Math.floor(height * resScale);

        if (_renderer) {
            _renderer.setSize(_config.internalWidth, _config.internalHeight, false);
        }
    }

function animate() {
        requestAnimationFrame(animate);

        const rawDt = _clock.getDelta();
        // Clamp dt to prevent spirals of death (max 0.1s)
        const dt = Math.min(rawDt, 0.1) * (window.flux.timeScale !== undefined ? window.flux.timeScale : 0.8);

        

        // Perf stats for DevTools snapshots
        if (window.flux && window.flux._debugIO && window.flux._debugIO.perf) {
            const perf = window.flux._debugIO.perf;
            perf.frame = (perf.frame || 0) + 1;
            perf.rawDt = rawDt;
            perf.dt = dt;
            const fps = dt > 0 ? (1 / dt) : 0;
            perf.fps = fps;
            perf.avgFps = (perf.avgFps && perf.avgFps > 0) ? (perf.avgFps * 0.9 + fps * 0.1) : fps;
        }
// Impact Frames
        if (_gameManager && _gameManager.impactPause > 0) {
            _gameManager.impactPause -= dt;
            if (_renderer && _scene && _camera) {
                _renderer.render(_scene, _camera);
            }
            return;
        }

        updateInputVector();

        // Action Buffer Processing
        if (_actionBuffer.active) {
            if (Date.now() - _actionBuffer.timestamp > _actionBuffer.duration) {
                _actionBuffer.active = false;
            } else {
                if (_homeTeam && _homeTeam.activePlayer) {
                    const p = _homeTeam.activePlayer;

                    if (p.hasBall && !p.isCharging && !p.isThrowing && p.status.nap <= 0) {
                        p.startCharge();
                        const btn = document.getElementById('action-button');
                        if (btn) btn.classList.add('active');
                        _actionBuffer.active = false;
                    }
                }
            }
        }

        // Menu State Handling
        if (_gameManager && _gameManager.state === 'menu' && _camera) {
            const time = Date.now() * 0.0005;
            const radius = 50;
            _camera.position.x = Math.sin(time) * radius;
            _camera.position.z = Math.cos(time) * radius;
            _camera.position.y = 20;
            _camera.lookAt(0, 0, 0);

            if (_renderer && _scene) {
                _renderer.render(_scene, _camera);
            }
            return;
        }

// Stable sub-stepping (prevents dt spikes from making physics/camera feel floaty on mobile)
        const _maxStep = 1 / 60;
        const _steps = Math.min(4, Math.max(1, Math.ceil(dt / _maxStep)));
        const _stepDt = dt / _steps;

        for (let _si = 0; _si < _steps; _si++) {
            const _sdt = _stepDt;

            if (_gameManager) _gameManager.update(_sdt);

            // If in Asset Forge mode, skip game logic and standard rendering
            // DevTools handles the rendering in its hooked update function
            if (_gameManager && _gameManager.isForgeMode) {
                // Forge mode handles its own rendering loop in DevTools hook
                return;
            }

            // Update Entities
            if (_homeTeam) {
                _homeTeam.update(_sdt);
                _homeTeam.players.forEach(p => checkBallGrab(p));
            }

            if (_awayTeam) {
                _awayTeam.update(_sdt);
                _awayTeam.players.forEach(p => checkBallGrab(p));
            }

            if (_ball) {
                _ball.update(_sdt);
            }

            // Ball Lab runtime (trajectory preview / record-replay)
            if (window.flux && window.flux.ballLab && typeof window.flux.ballLab.update === 'function') {
                window.flux.ballLab.update(_sdt);
            }

            // Update Camera
            updateCameraLogic(_sdt);

            // Update Visuals
            if (_waterOverlay) _waterOverlay.update(_sdt);
            if (_lightShafts) _lightShafts.update(_sdt);

// Runtime updaters (FX, arena rings, etc.)
            if (window.flux && window.flux._runtimeUpdaters && window.flux._runtimeUpdaters.length) {
                for (let ui = 0; ui < window.flux._runtimeUpdaters.length; ui++) {
                    const fn = window.flux._runtimeUpdaters[ui];
                    if (typeof fn === 'function') fn(_sdt);
                }
            }

            // Update Glyph Manager (Critical for visual cleanup)
            if (_glyphManager) _glyphManager.update(_sdt);

// Update Global Uniforms
            if (_arenaUniforms) {
                _arenaUniforms.uTime.value += _sdt;
                _arenaUniforms.uImpactStr.value *= Math.max(0, 1.0 - _sdt * 4.0);
            }
            
            // --- NEW: Arena Rotation & Color Shift ---
            if (window.flux.arenaGroup) {
                // Rotate sphere slowly to show water movement
                window.flux.arenaGroup.rotation.y += _sdt * 0.05;
            }

            if (window.flux.tribalUniforms) {
                window.flux.tribalUniforms.uTime.value += _sdt;
                
                // Possession Color Logic
                let targetColor = new THREE.Color(0x00ffff); // Default Cyan (Home/Neutral)
                
                if (_ball && _ball.holder) {
                    if (_ball.holder.team && _ball.holder.team.side === -1) {
                        targetColor.setHex(0xff8800); // Orange (Away)
                    }
                }
                
                // Smooth Lerp
                window.flux.tribalUniforms.uColor.value.lerp(targetColor, _sdt * 2.0);
            }

if (_particleUniforms) {
                _particleUniforms.uTime.value += _sdt;
            }
        } // Close sub-step loop

        if (_renderer && _scene && _camera) {
            _renderer.render(_scene, _camera);
        }
        // UI Updates
        updateUI();
    }

    function updateUI() {
        if (!_homeTeam || !_homeTeam.activePlayer) return;

        const btn = document.getElementById('action-button');
        const lbl = document.getElementById('action-label');
        const tackleBtn = document.getElementById('tackle-button');
        const p = _homeTeam.activePlayer;

        if (btn && lbl) {
            const btnText = btn.querySelector('.btn-text');

            if (p.hasBall) {
                if (btnText && btnText.innerText !== "ACTION") {
                    btnText.innerText = "ACTION";
                    btn.classList.add('shoot-mode');
                    lbl.innerText = "OFFENSE";
                    lbl.classList.add('shoot-label');
                }

                const isHighEnergy = (p.stats.HP / p.stats.maxHP) > 0.4;
                if (isHighEnergy) {
                    if (!btn.classList.contains('limit-ready')) btn.classList.add('limit-ready');
                } else {
                    if (btn.classList.contains('limit-ready')) btn.classList.remove('limit-ready');
                }

            } else {
                if (btnText && btnText.innerText !== "SWIM") {
                    btnText.innerText = "SWIM";
                    btn.classList.remove('shoot-mode');
                    btn.classList.remove('limit-ready');
                    lbl.innerText = "NORMAL";
                    lbl.classList.remove('shoot-label');
                }
            }
        }

        // Update tackle button visibility
        if (tackleBtn) {
            if (!p.hasBall || p.isEngaged) {
                tackleBtn.style.display = 'flex';
                // Update tackle button text based on context
                const tackleText = tackleBtn.querySelector('.btn-text');
                if (tackleText) {
                    if (p.isEngaged && p.hasBall) {
                        tackleText.innerText = 'BREAK';
                        tackleBtn.classList.add('urgent');
                    } else {
                        tackleText.innerText = 'TACKLE';
                        tackleBtn.classList.remove('urgent');
                    }
                }
            } else {
                tackleBtn.style.display = 'none';
            }
        }

        // Update distance to goal indicator
        const distIndicator = document.getElementById('goal-distance');
        if (distIndicator && p.mesh) {
            const goalZ = (p.team && p.team.side === 1) ? -28 : 28;
            const dist = Math.abs(p.mesh.position.z - goalZ);
            distIndicator.innerText = `${Math.floor(dist)}m`;
        }
    }

function updateCameraLogic(dt) {
        if (!_cameraManager || !_ball) return;

        let targetMesh = _ball.mesh;
        let targetVel = _ball.velocity;
        let targetInput = null;
        let isAiming = false;

        if (_ball.holder && _ball.holder.mesh) {
            targetMesh = _ball.holder.mesh;
            targetVel = _ball.holder.velocity;
            if (_ball.holder.inputVector) {
                targetInput = _ball.holder.inputVector;
            }
// Check aiming state (Charging or Throwing)
            if (_ball.holder.isCharging || _ball.holder.isThrowing) {
                isAiming = true;
            }
        }

        _cameraManager.setTarget(targetMesh, targetVel, targetInput, isAiming);
        _cameraManager.update(dt);
    }

function checkBallGrab(entity) {
        if (!entity.canCatch) return;
        if (_ball && !_ball.isCatchable()) return;
        if (entity.stunTimer > 0 || (entity.status && entity.status.nap > 0)) return;
        if (_ball.state !== 'free') return;
        if (!_ball.mesh || !entity.mesh) return;

        const ballPos = _ball.mesh.position;
        const entPos = entity.mesh.position;

        const dx = ballPos.x - entPos.x;
        const dz = ballPos.z - entPos.z;
        const distXZ = Math.sqrt(dx*dx + dz*dz);
        const distY = Math.abs(ballPos.y - entPos.y);

        // --- RELAXED TOLERANCES FOR EASIER PICKUP ---
        const touchRadius = 1.5; // Increased from 1.0 (Auto-grab radius)
        let magnetRadius = 3.5;  // Increased from 1.8 (Magnetic radius)
        let interactionRadius = 6.0; // Increased from 3.5 (Turn-to radius)
        let catchHeight = 6.0;   // Increased from 3.0 (Vertical reach)

        if (entity.isDashing) {
            magnetRadius = 4.5;
            interactionRadius = 7.0;
            catchHeight = 7.0;
        }

        if (distXZ > interactionRadius || distY > catchHeight) return;

        // Optimization: Use shared vectors to avoid GC
        _tempVec1.copy(ballPos).sub(entPos).normalize(); // toBall
        _tempVec2.set(0, 0, 1).applyQuaternion(entity.mesh.quaternion).normalize(); // playerForward

        const facingDot = _tempVec2.dot(_tempVec1);

        const coneThreshold = -0.4; // More generous cone (was -0.2)
        const isInCone = facingDot > coneThreshold;
        
        // AUTO-TURN: If near but facing wrong way, turn towards ball
        if (distXZ < interactionRadius && !isInCone) {
            const targetAngle = Math.atan2(_tempVec1.x, _tempVec1.z);
            const q = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0), targetAngle);
            entity.mesh.quaternion.slerp(q, 0.2); // Faster turn (was 0.1)
            if (entity.syncRotation) entity.syncRotation();
        }

        // GRAB LOGIC
        // 1. Touch: Very close (ignore facing - prevents running over ball)
        // 2. Magnet: Close and facing
        const isTouch = distXZ < touchRadius;
        const isMagnet = distXZ < magnetRadius && isInCone;

        if (isTouch || isMagnet) {
            // BLAST THROUGH LOGIC
            const ballSpeed = _ball.velocity.length();
            let catchChance = 1.0;

            // If ball is moving fast (e.g. > 20), check CA
            if (ballSpeed > 20.0) {
                const ca = entity.getStat('CA');
                // Difficulty scales with speed. 
                const difficulty = ballSpeed * 1.2; 
                
                if (difficulty > ca) {
                    catchChance = 0.4 + (ca / difficulty) * 0.6;
                    
                    // Point Blank Penalty: Harder to react if ball is right on top of you moving fast
                    if (distXZ < 1.2) {
                        catchChance *= 0.6; // Blast through likely
                    }
                    
                    if (entity.isDashing) catchChance += 0.2;
                }
            } else if (_ball.powerType === 'SH' && _ball.power > 15.0) {
                // Shot power check
                const ca = entity.getStat('CA');
                if (_ball.power > ca * 1.2) {
                    const chance = Math.min(0.7, (_ball.power - ca) * 0.04);
                    catchChance = 1.0 - chance;
                }
            }

            let fumble = false;
            if (Math.random() > catchChance) {
                fumble = true;
            }

            if (fumble) {
                if (window.flux.gameInstance.floatingText) {
                    // Visual feedback for blast through
                    window.flux.gameInstance.floatingText.spawn("BLAST THROUGH!", entPos, "damage");
                }
                
                // Deflect slightly but keep moving fast (Blast Through)
                // Don't stop it completely like a block, just perturb it
                _ball.velocity.multiplyScalar(0.85); 
                _ball.velocity.x += (Math.random()-0.5) * 5.0;
                _ball.velocity.y += (Math.random()) * 5.0; // Pop up
                _ball.velocity.z += (Math.random()-0.5) * 5.0;
                
                _ball.power *= 0.7;

                entity.canCatch = false;
                // Stun briefly
                entity.stunTimer = 0.5;
                if(entity.play) entity.play('react', 0.1);
                
                setTimeout(() => { entity.canCatch = true; }, 1000);

            } else {
                _ball.magnetize(entity);
            }
        }
    }

    // Start
    init();
})();