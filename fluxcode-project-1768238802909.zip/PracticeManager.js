(function() {
    window.flux = window.flux || {};

    class PracticeManager {
        constructor(gameManager) {
            this.game = gameManager;
            this.isRunning = false;
            this.currentDrill = null;
            this.drillState = {}; 
            
this.drills = {
                'free': { name: 'FREE ROAM', setup: this._setupFree.bind(this), loop: this._loopFree.bind(this) },
                'ball_lab': { name: 'BALL LAB', setup: this._setupBallLab.bind(this), loop: this._loopBallLab.bind(this) },
                'shooting': { name: 'SHOOTING DRILL', setup: this._setupShooting.bind(this), loop: this._loopShooting.bind(this) },
                'passing': { name: 'PASSING DRILL', setup: this._setupPassing.bind(this), loop: this._loopPassing.bind(this) },
                'defense': { name: 'DEFENSE DRILL', setup: this._setupDefense.bind(this), loop: this._loopDefense.bind(this) },
                'curve': { name: 'CURVE SHOT', setup: this._setupCurve.bind(this), loop: this._loopCurve.bind(this) },
                'rapid_fire': { name: 'RAPID FIRE', setup: this._setupRapidFire.bind(this), loop: this._loopRapidFire.bind(this) }
            };

this.ui = document.getElementById('practice-overlay');
            this.gestureHint = document.getElementById('gesture-hint');
            
            this.options = {
                infStats: true,
                aiDummy: true,
                showHitboxes: false
            };
            
this.targetRing = null;
            this.ghostBalls = []; // Array to track visual copies of thrown balls
            this._initVisuals();
            this._setupEvents();
        }

        _initVisuals() {
            // Create a glowing ring for targets
            const geometry = new THREE.RingGeometry(1.5, 1.8, 32);
            geometry.rotateX(-Math.PI / 2);
            const material = new THREE.MeshBasicMaterial({ 
                color: 0x00ffff, 
                side: THREE.DoubleSide, 
                transparent: true, 
                opacity: 0.6,
                blending: THREE.AdditiveBlending,
                depthWrite: false
            });
            this.targetRing = new THREE.Mesh(geometry, material);
            this.targetRing.visible = false;
            // Add to scene via game manager reference
            if (this.game.scene) this.game.scene.add(this.targetRing);
        }

        start() {
this.isRunning = true;
            this._showPanel();
            // If menu requested a specific drill (e.g., Ball Lab), honor it once.
            const req = window.flux && window.flux.requestedPracticeDrill;
            if (req && this.drills[req]) {
                this.setDrill(req);
                window.flux.requestedPracticeDrill = null;
            } else {
                this.setDrill('free');
            }
            
            // Ensure HUD is visible
            const hud = document.getElementById('ui-layer');
            if(hud) hud.style.visibility = 'visible';
        }

        stop() {

            this.isRunning = false;
            this._hidePanel();
            this._hideRestoreBtn();
this._clearDrill();
            
// Clear Ghost Balls
            this.ghostBalls.forEach(b => {
                if (b.mesh) this.game.scene.remove(b.mesh);
                if (b.trail) {
                    this.game.scene.remove(b.trail.mesh);
                    if (b.trail.mesh.geometry) b.trail.mesh.geometry.dispose();
                }
            });
            this.ghostBalls = [];
            if (this.targetRing) this.targetRing.visible = false;

            // Restore Away Team Visibility for Normal Match
            if (this.game.teams.away) {
                this.game.teams.away.players.forEach(p => {
                    if(p.mesh) {
                        p.mesh.visible = true;
                        p.mesh.position.y = 0; // Ensure they aren't stuck under floor
                    }
                });
            }

            // Disable debug visuals if they were on
            if (this.game.debugVisualizer) {
                this.game.debugVisualizer.enabled = false;
                this.game.debugVisualizer.showHitboxes = false;
            }
        }

        setDrill(key) {
            if (!this.drills[key]) return;
            this._clearDrill();
            this.currentDrill = key;
            
            // Update UI
            if (this.ui) {
                this.ui.querySelectorAll('.drill-btn').forEach(btn => {
                    btn.classList.toggle('active', btn.dataset.drill === key);
                });
            }

            // Run Setup
            this.drills[key].setup();
            
            // Announcement
            if (this.game.showAnnouncement) {
                this.game.showAnnouncement(this.drills[key].name, 'normal');
            }
        }

        update(dt) {
            if (!this.isRunning) return;

            // Common Practice Logic (Infinite Stats)
            if (this.options.infStats) {
                this._applyInfiniteStats();
            }

            // Drill Logic
            if (this.currentDrill && this.drills[this.currentDrill].loop) {
                this.drills[this.currentDrill].loop(dt);
            }
            
            // Visuals Animation
// Visuals Animation
            if (this.targetRing && this.targetRing.visible) {
                this.targetRing.rotation.z += dt; // Spin
                const s = 1.0 + Math.sin(Date.now() * 0.005) * 0.1;
                this.targetRing.scale.set(s, s, s);
            }

// Update Ghost Balls
            for (let i = this.ghostBalls.length - 1; i >= 0; i--) {
                const b = this.ghostBalls[i];
                b.life -= dt;
                
                // --- PHYSICS & VISUALS DELEGATION ---
                if (window.flux.Ball && window.flux.Ball.prototype.updateFree) {
                    window.flux.Ball.prototype.updateFree.call(b, dt);
                    window.flux.Ball.prototype.updateVisuals.call(b, dt);
                }

                // Update Trail
                if (b.trail) {
                    const trailPos = b.mesh.position.clone();
                    if (b.deformNode) trailPos.y += b.deformNode.position.y;
                    b.trail.update(trailPos);
                }

                // --- GOAL DETECTION FOR GHOST BALLS ---
                const pos = b.mesh.position;
                // Check Z depth (Goal is at +/- 28, trigger at 29)
                if (Math.abs(pos.z) > 29.0) {
                    // Goal Box Dimensions (Matches GameManager)
                    const halfWidth = 11.0;
                    const halfHeight = 9.0;
                    const goalYOffset = -4.5;
                    
                    if (Math.abs(pos.x) <= halfWidth && Math.abs(pos.y - goalYOffset) <= halfHeight) {
                        // GOAL!
                        if (this.game.particleManager) {
                            // Spawn Goal FX
                            this.game.particleManager.spawn('shockwave', pos, { scale: 8.0, life: 0.5 });
                            this.game.particleManager.spawn('flash', pos, { scale: 5.0 });
                            // Debris
                            for(let k=0; k<10; k++) this.game.particleManager.spawn('debris', pos, { scale: 0.5 });
                        }
                        if (this.game.floatingText) {
                            this.game.floatingText.spawn("GOAL", pos, "goal");
                        }
                        // Kill ball immediately
                        b.life = 0;
                    }
                }

                // Cleanup
                if (b.life <= 0 || b.mesh.position.y < -10) {
                    this.game.scene.remove(b.mesh);
                    if (b.trail) {
                        this.game.scene.remove(b.trail.mesh);
                        if (b.trail.mesh.geometry) b.trail.mesh.geometry.dispose();
                    }
                    this.ghostBalls.splice(i, 1);
                }
            }
        }

        _setupEvents() {

            // Minimize / Restore
            const minBtn = this.ui.querySelector('#p-minimize');
            if (minBtn) {
                minBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this._hidePanel();
                    this._showRestoreBtn();
                });
            }

            const restoreBtn = document.getElementById('practice-restore-btn');
            if (restoreBtn) {
                restoreBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this._showPanel();
                    this._hideRestoreBtn();
                });
            }

            // Drill Buttons
            this.ui.querySelectorAll('.drill-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this.setDrill(btn.dataset.drill);
                });
            });

            // Reset Ball
            const resetBtn = this.ui.querySelector('#p-reset-ball');
            if (resetBtn) {
                resetBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    this._resetBallToPlayer();
                });
            }

            // Exit
            const exitBtn = this.ui.querySelector('#p-exit');
            if (exitBtn) {
                exitBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    if (window.flux.gameInstance && window.flux.gameInstance.menuManager) {
                        window.flux.gameInstance.menuManager.show();
                        window.flux.gameInstance.state = 'menu';
                        this.stop();
                    }
                });
            }

            // Options Toggles
            this._bindToggle('opt-inf-stat', 'infStats');
            this._bindToggle('opt-ai-dummy', 'aiDummy', (val) => {
                // Update AI Dummy state immediately
                if (this.game.teams.away) {
                    this.game.teams.away.aiEnabled = !val; // If dummy is TRUE, AI is FALSE
                }
            });
            this._bindToggle('opt-hitboxes', 'showHitboxes', (val) => {
                if (this.game.debugVisualizer) {
                    this.game.debugVisualizer.enabled = val;
                    this.game.debugVisualizer.showHitboxes = val;
                }
            });

            // Keyboard Shortcut for Reset (R)
// Keyboard Shortcut for Reset (R)
            window.addEventListener('keydown', (e) => {
                if (this.isRunning && e.key.toLowerCase() === 'r' && !e.repeat) {
                    this._resetBallToPlayer();
                }
            });
        }

_bindToggle(id, optionKey, callback) {
            const el = this.ui.querySelector(`#${id}`);
            if (!el) return;

            // Helper to update visuals
            const updateVisual = () => {
                const isActive = this.options[optionKey];
                el.classList.toggle('active', isActive);
                const box = el.querySelector('.checkbox');
                if (box) box.innerText = isActive ? '▣' : '□';
            };

            // Initialize visual state immediately
            updateVisual();

            el.addEventListener('click', (e) => {
                e.stopPropagation();
                this.options[optionKey] = !this.options[optionKey];
                
                updateVisual();

                if (callback) callback(this.options[optionKey]);
            });
        }


        _setupBallLab() {
            this._setInstruction("BALL LAB: Open DevTools → Ball Lab. Use Shot Cannon + trajectory preview + record/replay.");
            this.drillState.resetting = false;
            this.drillState._autoResetTimer = 0;

            const home = this.game.teams.home;
            const away = this.game.teams.away;
            const p = home ? home.activePlayer : null;
            if (!p) return;

            // Solo mode: hide everyone except the active player
            if (home && home.players) {
                home.players.forEach(mate => {
                    if (mate.mesh) mate.mesh.visible = (mate === p);
                });
            }
            if (away && away.players) {
                away.players.forEach(opp => {
                    if (opp.mesh) opp.mesh.visible = false;
                });
            }

            // Place active player at center facing the away goal
            if (p.mesh) {
                p.mesh.position.set(0, 0, 0);
                p.mesh.lookAt(0, 0, -28);
                p.velocity.set(0, 0, 0);
                if (p.syncRotation) p.syncRotation();
            }

            // Big stats so you can test extremes
            if (p.stats) {
                p.stats.SH = 99;
                p.stats.PA = 99;
                p.stats.EN = 99;
                p.stats.maxHP = Math.max(p.stats.maxHP || 999, 999);
                p.stats.HP = p.stats.maxHP;
            }

            // A clear target marker (purely visual)
            if (this.targetRing) {
                this.targetRing.visible = true;
                this.targetRing.position.set(0, 0.1, -18);
                this.targetRing.material.color.setHex(0xff00ff);
            }

            this._resetBallToPlayer();
        }

        _loopBallLab(dt) {
            const b = this.game.entities.ball;
            const p = this.game.teams.home.activePlayer;
            if (!b || !p) return;

            // Auto-reset ball back to player once it comes to rest,
            // so you can spam variations without touching anything.
            if (b.state === 'free') {
                const stopped = (b.velocity.lengthSq() < 0.01) && (b.power <= 0.01);
                if (stopped) {
                    this.drillState._autoResetTimer = (this.drillState._autoResetTimer || 0) + dt;
                    if (this.drillState._autoResetTimer > 0.45) {
                        this._resetBallToPlayer();
                        this.drillState._autoResetTimer = 0;
                    }
                } else {
                    this.drillState._autoResetTimer = 0;
                }
            } else {
                this.drillState._autoResetTimer = 0;
            }

            // Slight target bob (helps depth perception)
            if (this.targetRing && this.targetRing.visible) {
                this.targetRing.position.y = 0.1 + Math.sin(Date.now() * 0.003) * 0.05;
            }
        }

        _applyInfiniteStats() {
            const home = this.game.teams.home;
            if (home) {
                home.players.forEach(p => {
                    p.stats.HP = p.stats.maxHP;
                    p.currentEN = p.stats.EN;
                    p.status.venom = 0;
                    p.status.nap = 0;
                    p.stunTimer = 0;
                });
            }
        }

        _clearDrill() {

            // Reset positions, clear dummies, reset score
            if (this.drillState.hintTimeout) clearTimeout(this.drillState.hintTimeout);
            this.drillState = { score: 0, timer: 0, stage: 0, resetting: false };
            if (this.gestureHint) this.gestureHint.style.display = 'none';
            this._updateScoreUI(0);
            
            // Clear Glyphs
            if (this.game.glyphManager) this.game.glyphManager.clear();
            
            if (this.targetRing) this.targetRing.visible = false;

            // Reset teams to default positions

            // Reset teams to default positions
            this.game.teams.home.resetPositions();
            this.game.teams.away.resetPositions();
            
            // Apply AI Dummy setting
            if (this.game.teams.away) {
                this.game.teams.away.aiEnabled = !this.options.aiDummy;
            }
            // Hide away team by default in drills unless specified
            this.game.teams.away.players.forEach(p => {
                if(p.mesh) p.mesh.visible = false;
                p.mesh.position.set(0, -100, 0); // Move away
                p.velocity.set(0,0,0);
            });
            
            // Ensure Home team is visible
            this.game.teams.home.players.forEach(p => {
                if(p.mesh) p.mesh.visible = true;
            });
        }

        _resetBallToPlayer() {
            const p = this.game.teams.home.activePlayer;
            const b = this.game.entities.ball;
            if (p && b) {
                b.reset();
                b.grab(p);
                if (this.game.floatingText) this.game.floatingText.spawn("RESET", p.mesh.position, "tech");
                
                // Snap camera
                if (this.game.cameraManager) this.game.cameraManager.snapToTarget();
            }
        }

        _updateScoreUI(val) {
            const el = this.ui.querySelector('#drill-score');
            if (el) el.innerText = `SCORE: ${val}`;
        }

        _setInstruction(text) {
             const el = this.ui.querySelector('#drill-instruction');
             if (el) el.innerText = text;
        }

        // --- DRILLS ---

        _setupFree() {
            this._setInstruction("Free practice. Infinite HP/EN.");
            // Show everyone
            this.game.teams.away.players.forEach(p => {
                if(p.mesh) p.mesh.visible = true;
                p.mesh.position.copy(p.homePosition);
            });
            this._resetBallToPlayer();
        }
        _loopFree(dt) {}

        _setupShooting() {

            this._setInstruction("Score on the Goalie!");
            this.drillState.resetting = false; // Clear reset flag
            
            // Setup: Active Player at 18m, Goalie in net.
            const p = this.game.teams.home.activePlayer;
            const g = this.game.teams.away.players.find(x => x.role === 'GL');
            
            if (p && p.mesh) {
                p.mesh.position.set(0, 0, -10); // 18m out (Home attacks -Z)
                p.mesh.lookAt(0, 0, -28);
                p.velocity.set(0,0,0);
            }
            if (g && g.mesh) {
                g.mesh.visible = true;
                g.mesh.position.set(0, 0, -27);
                g.mesh.lookAt(0, 0, 0);
                g.velocity.set(0,0,0);
            }
            
            this._resetBallToPlayer();
        }
        
        _loopShooting(dt) {
            if (this.drillState.resetting) return;

            // Check if goal scored (GameManager handles the actual goal event, but we track reset)
            if (this.game.state === 'goal') {
                this.drillState.resetting = true;
                this.drillState.score++;
                this._updateScoreUI(this.drillState.score);
                this.game.state = 'active'; // Hijack state back
                setTimeout(() => this._setupShooting(), 1000);
                return;
            }
            
            // If goalie catches
            const g = this.game.teams.away.players.find(x => x.role === 'GL');
            if (g && g.hasBall) {
                 this.drillState.resetting = true;
                 if (this.game.floatingText) this.game.floatingText.spawn("SAVED", g.mesh.position, "damage");
                 setTimeout(() => this._setupShooting(), 1000);
            }
        }

        _setupPassing() {

             this._setInstruction("Pass to the moving target!");
             this.drillState.resetting = false;

             // Setup: Active Player center. 1 Teammate running patterns.
             const p = this.game.teams.home.activePlayer;
             const target = this.game.teams.home.players.find(x => x !== p && x.role !== 'GL');
             
             this.drillState.target = target;
             
             if (p) {
                 p.mesh.position.set(0, 0, 10);
                 p.velocity.set(0,0,0);
             }
             if (target) {
                 target.mesh.position.set(0, 0, -10);
                 target.mesh.visible = true;
                 target.velocity.set(0,0,0);
             }
             
             this._resetBallToPlayer();
        }

        _loopPassing(dt) {
            if (this.drillState.resetting) return;

            const target = this.drillState.target;
            if (!target) return;
            
            // Move target in circle
            this.drillState.timer += dt;
            target.mesh.position.x = Math.sin(this.drillState.timer) * 10;
            target.mesh.position.z = -10 + Math.cos(this.drillState.timer * 0.5) * 5;
            target.mesh.lookAt(0,0,10);

            // Update Ring
            if (this.targetRing) {
                this.targetRing.visible = true;
                this.targetRing.position.copy(target.mesh.position);
                this.targetRing.position.y = 0.1;
                this.targetRing.material.color.setHex(0x00ffff); // Cyan
            }

            if (target.hasBall) {
                this.drillState.resetting = true;
                this.drillState.score++;
                this._updateScoreUI(this.drillState.score);
                if (this.game.floatingText) this.game.floatingText.spawn("NICE PASS!", target.mesh.position, "heal");
                
                // Reset
                setTimeout(() => {
                    target.loseBall();
                    this._setupPassing(); // Re-setup to reset positions
                }, 800);
            }
        }
        
        _setupDefense() {

            this._setInstruction("Tackle the attacker!");
            this.drillState.resetting = false;

            const p = this.game.teams.home.activePlayer;
            const attacker = this.game.teams.away.players.find(x => x.role === 'MF');
            
            this.drillState.attacker = attacker;
            
            if (p) {
                p.mesh.position.set(0, 0, 20); // Near own goal
                p.velocity.set(0,0,0);
            }
            if (attacker) {
                attacker.mesh.visible = true;
                attacker.mesh.position.set(0, 0, -10);
                attacker.velocity.set(0,0,0);
                // Give ball to attacker
                const b = this.game.entities.ball;
                b.reset();
                b.grab(attacker);
            }
        }
        
        _loopDefense(dt) {
            if (this.drillState.resetting) return;

            const attacker = this.drillState.attacker;
            const p = this.game.teams.home.activePlayer;
            
            if (!attacker || !p) return;
            
            // Attacker runs to goal (+Z)
            const goalPos = new THREE.Vector3(0, 0, 28);
            const dir = goalPos.clone().sub(attacker.mesh.position).normalize();
            
            // Update Ring on Attacker
            if (this.targetRing) {
                this.targetRing.visible = true;
                this.targetRing.position.copy(attacker.mesh.position);
                this.targetRing.position.y = 0.1;
                this.targetRing.material.color.setHex(0xff0000); // Red for enemy
            }

            if (attacker.hasBall) {
                attacker.setInput(dir.x, dir.z);
            } else {
                // Ball lost (Tackled)
                if (p.hasBall || this.game.entities.ball.state === 'free') {
                    this.drillState.resetting = true;
                    this.drillState.score++;
                    this._updateScoreUI(this.drillState.score);
                    if (this.game.floatingText) this.game.floatingText.spawn("STOPPED!", p.mesh.position, "block");
                    setTimeout(() => this._setupDefense(), 1000);
                }
            }
            
            // Fail condition: Attacker scores (GameManager handles goal check)
             if (this.game.state === 'goal') {
                this.drillState.resetting = true;
                this.game.state = 'active';
                if (this.game.floatingText) this.game.floatingText.spawn("FAILED", p.mesh.position, "damage");
                setTimeout(() => this._setupDefense(), 1000);
            }
}

        _setupCurve() {
this._setInstruction("Swipe a CURVE ( ) ) to bypass the defender!");
            this.drillState.resetting = false;

            // Show gesture hint
            if (this.gestureHint) {
                this.gestureHint.style.display = 'flex';
                this.gestureHint.classList.add('active');
                
                // Clear any existing timeout
                if (this.drillState.hintTimeout) clearTimeout(this.drillState.hintTimeout);
                
                // Auto hide after 4s
                this.drillState.hintTimeout = setTimeout(() => {
                    if (this.gestureHint) {
                        this.gestureHint.style.display = 'none';
                        this.gestureHint.classList.remove('active');
                    }
                }, 4000);
            }

            const p = this.game.teams.home.activePlayer;
            // Use a defender dummy
            const defender = this.game.teams.away.players.find(x => x.role === 'LD');
            this.drillState.defender = defender;

            if (p) {
                p.mesh.position.set(0, 0, 15);
                p.mesh.lookAt(0, 0, -28);
                p.velocity.set(0,0,0);
            }

            if (defender) {
                defender.mesh.visible = true;
                defender.mesh.position.set(0, 0, 5); // 10m in front of player
                defender.mesh.lookAt(0, 0, 15); // Face player
                defender.velocity.set(0,0,0);
                // Boost BL to ensure straight shots are blocked
                defender.stats.BL = 99; 
                // Ensure they don't move
                defender.aiState = 'IDLE';
            }

            // Target Ring behind defender
            if (this.targetRing) {
                this.targetRing.visible = true;
                this.targetRing.position.set(0, 0.1, -10);
                this.targetRing.material.color.setHex(0x00ffff);
            }

            this._resetBallToPlayer();
        }

_loopCurve(dt) {
            if (this.drillState.resetting) return;

            const ball = this.game.entities.ball;
            const defender = this.drillState.defender;

            // Check if ball passed the defender line (z < 0)
            if (ball.mesh.position.z < 0) {
                // Success zone (Within 5m width)
                if (Math.abs(ball.mesh.position.x) < 5) {
                    this.drillState.resetting = true;
                    this.drillState.score++;
                    this._updateScoreUI(this.drillState.score);
                    if (this.game.floatingText) this.game.floatingText.spawn("CURVED!", ball.mesh.position, "tech");
                    setTimeout(() => this._setupCurve(), 1000);
                    return;
                }
            }

            // Check if blocked (Ball stopped or power drained significantly near defender)
            if (defender && ball.mesh.position.distanceTo(defender.mesh.position) < 3.0) {
                if (ball.power <= 0 || ball.velocity.length() < 1.0) {
                    this.drillState.resetting = true;
                    if (this.game.floatingText) this.game.floatingText.spawn("BLOCKED", defender.mesh.position, "damage");
                    
                    // Re-show hint on failure to guide player
                    if (this.gestureHint) {
                        this.gestureHint.style.display = 'flex';
                        this.gestureHint.classList.add('active');
                        clearTimeout(this.drillState.hintTimeout);
                        this.drillState.hintTimeout = setTimeout(() => {
                            if (this.gestureHint) {
                                this.gestureHint.style.display = 'none';
                                this.gestureHint.classList.remove('active');
                            }
                        }, 4000);
                    }

                    setTimeout(() => this._setupCurve(), 1000);
                    return;
                }
            }

            // Missed / Out of bounds
            if (ball.mesh.position.z < -15) {
                 this.drillState.resetting = true;
                 if (this.game.floatingText) this.game.floatingText.spawn("MISSED", ball.mesh.position, "damage");
                 
                 // Re-show hint on miss
                 if (this.gestureHint) {
                    this.gestureHint.style.display = 'flex';
                    this.gestureHint.classList.add('active');
                    clearTimeout(this.drillState.hintTimeout);
                    this.drillState.hintTimeout = setTimeout(() => {
                        if (this.gestureHint) {
                            this.gestureHint.style.display = 'none';
                            this.gestureHint.classList.remove('active');
                        }
                    }, 4000);
                 }

                 setTimeout(() => this._setupCurve(), 1000);
            }
        }

_setupRapidFire() {
            this._setInstruction("UNLIMITED AMMO! Spam throws!");
            this.drillState.resetting = false;

            // Find Tidus or default to LF
            let p = this.game.teams.home.players.find(x => x.characterName && x.characterName.includes('Tidus'));
            if (!p) p = this.game.teams.home.players.find(x => x.role === 'LF');
            
            // Set active player
            if (p) {
                this.game.teams.home.setActivePlayer(p);
                p.mesh.position.set(0, 0, 0);
                p.mesh.lookAt(0, 0, -28);
                p.velocity.set(0,0,0);
                
                // Boost stats for fun
                p.stats.SH = 99;
                p.stats.PA = 99;
            }

            // HIDE EVERYONE (Alone Mode)
            this.game.teams.home.players.forEach(mate => {
                if (mate !== p && mate.mesh) mate.mesh.visible = false;
            });
            this.game.teams.away.players.forEach(opp => {
                if (opp.mesh) opp.mesh.visible = false;
            });

            this._resetBallToPlayer();
        }

_loopRapidFire(dt) {
            const p = this.game.teams.home.activePlayer;
            const b = this.game.entities.ball;

            if (!p || !b) return;

            // Detect if ball was just thrown (is free)
            if (b.state === 'free') {
                // 1. Spawn Ghost Ball (Visual Copy)
                // Clone the mesh hierarchy to preserve Deform/Spin nodes
                const ghostMesh = b.mesh.clone();
                
                // Ensure visibility and add to scene
                this.game.scene.add(ghostMesh);
                
                // Re-bind internal references for the physics engine
                // Hierarchy: Mesh -> DeformNode -> SpinNode
                const deformNode = ghostMesh.children[0];
                const spinNode = deformNode ? deformNode.children[0] : null;

                // Determine Trail Color based on Tech
                let trailColor = 0xff4400; // Default SH (Orange)
                if (b.technique) {
                    if (b.technique.type === 'venom') trailColor = 0xaa00ff;
                    else if (b.technique.type === 'wither') trailColor = 0x888888;
                    else if (b.technique.type === 'nap') trailColor = 0x000088;
                    else if (b.technique.type === 'sphere') trailColor = 0x00ffff;
                    else if (b.technique.type === 'jecht') trailColor = 0xff0000;
                    else if (b.technique.type === 'invisible') trailColor = 0x444444;
                } else if (b.powerType === 'PA') {
                    trailColor = 0x00aaff; // Pass (Blue)
                }

                // Create Trail
                const trail = new window.flux.TrailRenderer(this.game.scene);
                trail.active = true;
                trail.setColor(trailColor);
                trail.reset(ghostMesh.position);

                // Create a "Mock" Ball object that satisfies Ball.js physics requirements
                const ghostBall = {
                    mesh: ghostMesh,
                    deformNode: deformNode,
                    spinNode: spinNode,
                    velocity: b.velocity.clone(),
                    angularVelocity: b.angularVelocity ? b.angularVelocity.clone() : new THREE.Vector3(),
                    accumulatedRotation: b.accumulatedRotation ? b.accumulatedRotation.clone() : new THREE.Quaternion(),
                    state: 'free',
                    power: b.power,
                    powerType: b.powerType,
                    technique: b.technique,
                    isInvisible: b.isInvisible,
                    life: 5.0, // Enough time to reach goal
                    trail: trail,
                    _bubbleTimer: 0,
                    _ghost: true,
                    // Mock methods
                    reset: () => {}, 
                    drop: () => {},
                    reveal: () => {}
                };

                // Apply visibility
                ghostMesh.visible = !b.isInvisible;

                this.ghostBalls.push(ghostBall);

// 2. Reset Real Ball to Player INSTANTLY
                b.velocity.set(0, 0, 0);
                b.angularVelocity.set(0, 0, 0);
                
                // FIX: Force ball position to be explicitly in front of the player
                // This prevents any logic from thinking the ball is behind and triggering a turn
                const fwd = new THREE.Vector3(0, 0, 1).applyQuaternion(p.mesh.quaternion);
                b.mesh.position.copy(p.mesh.position).add(fwd.multiplyScalar(0.8));
                b.mesh.position.y += 1.0;

                // Manual Attach (Bypass 'catch' animation)
                b.holder = p;
                b.state = 'held';
                p.hasBall = true;
                
                // Reset Player Throw State so they can fire again immediately
                p.isThrowing = false;
                p.catchCooldown = 0;

                // Sync rotation to prevent snapping
                if (p.syncRotation) p.syncRotation();
            }
            
            // Ensure infinite stats
            p.currentEN = p.stats.EN;
            p.stats.HP = p.stats.maxHP;
        }

        _showPanel() {
            if (this.ui) this.ui.classList.add('active');
        }

        _hidePanel() {
            if (this.ui) this.ui.classList.remove('active');
        }

        _showRestoreBtn() {
            const btn = document.getElementById('practice-restore-btn');
            if (btn) btn.style.display = 'block';
        }

        _hideRestoreBtn() {
            const btn = document.getElementById('practice-restore-btn');
            if (btn) btn.style.display = 'none';
        }
    }
window.flux.PracticeManager = PracticeManager;
})();