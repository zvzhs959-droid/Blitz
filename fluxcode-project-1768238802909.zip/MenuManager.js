(function() {
    window.flux = window.flux || {};

    class MenuManager {
        constructor(gameManager) {
            this.game = gameManager;
            this.container = document.getElementById('main-menu');
            this.items = document.querySelectorAll('.menu-item');
            
            this.setupEvents();
        }

        setupEvents() {
            this.items.forEach(item => {
                item.addEventListener('click', (e) => {
                    e.stopPropagation(); // Prevent click-through
                    this.handleSelection(item.dataset.action);
                });
                
                item.addEventListener('mouseenter', () => {
                    // Optional: Play hover sound
                });
            });
        }

        handleSelection(action) {
            console.log("Menu Selection:", action);
            if (action === 'normal') {
                this.hide();
                this.game.startMatch('normal');
            } else if (action === 'practice') {
                this.hide();
                this.game.startMatch('practice');
            } else if (action === 'ball_lab') {
                this.hide();
                window.flux = window.flux || {};
                window.flux.requestedPracticeDrill = 'ball_lab';
                this.game.startMatch('practice');
            } else if (action === 'options') {
                console.log("Options clicked (Not implemented)");
            }
        }

        show() {
            if (this.container) {
                this.container.classList.add('active');
                this.game.setMenuMode(true);
            }
        }

        hide() {
            if (this.container) {
                this.container.classList.remove('active');
                this.game.setMenuMode(false);
            }
        }
    }

    window.flux.MenuManager = MenuManager;
})();