(function() {
    window.flux = window.flux || {};

// Formation Definitions (Coordinates for Side 1: Defends +Z, Attacks -Z)
    // X: Left(-)/Right(+), Z: Forward(-)/Back(+)
    const FORMATIONS = {
        'Normal': {
            'GL': { x: 0, z: 25 },
            'LD': { x: -8, z: 15 }, 'RD': { x: 8, z: 15 },
            'MF': { x: 0, z: 5 },
            'LF': { x: -10, z: -10 }, 'RF': { x: 10, z: -10 }
        },
        'Center Attack': {
            'GL': { x: 0, z: 25 },
            'LD': { x: -8, z: 15 }, 'RD': { x: 8, z: 15 },
            'MF': { x: 0, z: 0 },
            'LF': { x: -4, z: -15 }, 'RF': { x: 4, z: -15 }
        },
        'Right Side': {
            'GL': { x: 0, z: 25 },
            'LD': { x: 0, z: 15 }, 'RD': { x: 12, z: 15 },
            'MF': { x: 10, z: 5 },
            'LF': { x: 5, z: -10 }, 'RF': { x: 15, z: -10 }
        },
        'Left Side': {
            'GL': { x: 0, z: 25 },
            'LD': { x: -12, z: 15 }, 'RD': { x: 0, z: 15 },
            'MF': { x: -10, z: 5 },
            'LF': { x: -15, z: -10 }, 'RF': { x: -5, z: -10 }
        },
        'All-Out Defense': {
            'GL': { x: 0, z: 25 },
            'LD': { x: -6, z: 20 }, 'RD': { x: 6, z: 20 },
            'MF': { x: 0, z: 10 },
            'LF': { x: -10, z: 5 }, 'RF': { x: 10, z: 5 }
        },
        'Flat Line': {
            'GL': { x: 0, z: 25 },
            'LD': { x: -8, z: 0 }, 'RD': { x: 8, z: 0 },
            'MF': { x: 0, z: 0 },
            'LF': { x: -15, z: 0 }, 'RF': { x: 15, z: 0 }
        },
        'Counter': {
            'GL': { x: 0, z: 25 },
            'LD': { x: -8, z: 20 }, 'RD': { x: 8, z: 20 },
            'MF': { x: 0, z: 15 },
            'LF': { x: -12, z: -20 }, 'RF': { x: 12, z: -20 }
        },
        'Double Sides': {
            'GL': { x: 0, z: 25 },
            'LD': { x: -18, z: 15 }, 'RD': { x: 18, z: 15 },
            'MF': { x: 0, z: 5 },
            'LF': { x: -18, z: -10 }, 'RF': { x: 18, z: -10 }
        }
    };



    // --- Enemy Indicator (Red Arrow Sprite) ---
    // Shared texture/material so we don't create 6 canvases.
const _enemyArrowTexture = (() => {
        const c = document.createElement('canvas');
        c.width = 64;
        c.height = 64;
        const ctx = c.getContext('2d');
        ctx.clearRect(0, 0, c.width, c.height);
        
        // Arrow pointing DOWN
        ctx.beginPath();
        ctx.moveTo(6, 12);   
        ctx.lineTo(58, 12);  
        ctx.lineTo(32, 52);  
        ctx.closePath();
        ctx.fillStyle = '#ff0000';
        ctx.fill();
        ctx.lineWidth = 4;
        ctx.strokeStyle = 'rgba(255,255,255,0.95)';
        ctx.stroke();
        return new THREE.CanvasTexture(c);
    })();

const _playerArrowTexture = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        ctx.clearRect(0, 0, c.width, c.height);
        
        // Arrow pointing DOWN
        ctx.beginPath();
        ctx.moveTo(6, 12);   
        ctx.lineTo(58, 12);  
        ctx.lineTo(32, 52);  
        ctx.closePath();
        ctx.fillStyle = '#00ff00'; // Green
        ctx.fill();
        ctx.lineWidth = 4;
        ctx.strokeStyle = 'rgba(255,255,255,0.95)';
        ctx.stroke();
        return new THREE.CanvasTexture(c);
    })();

    const _teammateArrowTexture = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        ctx.clearRect(0, 0, c.width, c.height);
        
        // Arrow pointing DOWN
        ctx.beginPath();
        ctx.moveTo(6, 12);   
        ctx.lineTo(58, 12);  
        ctx.lineTo(32, 52);  
        ctx.closePath();
        ctx.fillStyle = '#ffffff'; // White
        ctx.fill();
        ctx.lineWidth = 4;
        ctx.strokeStyle = 'rgba(0,0,0,0.5)';
        ctx.stroke();
        return new THREE.CanvasTexture(c);
    })();

    const _enemyArrowMaterial = new THREE.SpriteMaterial({ map: _enemyArrowTexture, transparent: true, depthTest: false, depthWrite: false });
    const _playerArrowMaterial = new THREE.SpriteMaterial({ map: _playerArrowTexture, transparent: true, depthTest: false, depthWrite: false });
    const _teammateArrowMaterial = new THREE.SpriteMaterial({ map: _teammateArrowTexture, transparent: true, depthTest: false, depthWrite: false });
class Team {
        /**
         * Generates and applies stats to a player based on role and level.
         * Centralizes balancing to ensure high-level play feels distinct.
         */
        static generateStats(player, role, level = 1, isHuman = false) {
            // 1. Define Role Baselines (Level 1)
            // Balanced to be weak but functional at Level 1
            const base = {
                HP: 100, SP: 55, EN: 10, AT: 5, PA: 5, BL: 5, SH: 5, CA: 5
            };

            // Role Specializations
            switch(role) {
                case 'LF': case 'RF': // Strikers
                    base.SH += 10; base.SP += 5; base.EN += 5;
                    break;
                case 'MF': // Playmakers
                    base.PA += 10; base.AT += 8; base.EN += 8; base.SP += 2;
                    break;
                case 'LD': case 'RD': // Defenders
                    base.AT += 12; base.BL += 10; base.PA += 5;
                    break;
                case 'GL': // Goalie
                    base.CA += 10; base.SP += 5; base.PA += 15; // Strong arm
                    break;
            }

            // 2. Scaling Factors (Per Level)
            // Designed so Level 50 is "God Tier" and Level 1 is "Rookie"
            const growth = {
                HP: 15,    // +1500 HP at Lvl 99
                SP: 0.5,   // +50 SP at Lvl 99 (Speed demon)
                Primary: 0.8, // +80 Stat at Lvl 99
                Secondary: 0.5 // +50 Stat at Lvl 99
            };

            // Helper to scale
            const scale = (val, rate) => Math.floor(val + ((level - 1) * rate));

            // Apply Scaling
            player.stats.HP = scale(base.HP, growth.HP);
            
            // SP: Cap at 99, but ensure high levels feel FAST
            player.stats.SP = Math.min(99, scale(base.SP, growth.SP));

            // Stat distribution based on role priorities
            if (['LF', 'RF'].includes(role)) {
                player.stats.SH = Math.min(99, scale(base.SH, growth.Primary));
                player.stats.EN = Math.min(99, scale(base.EN, growth.Primary));
                player.stats.AT = Math.min(99, scale(base.AT, growth.Secondary));
                player.stats.PA = Math.min(99, scale(base.PA, growth.Secondary));
                player.stats.BL = Math.min(99, scale(base.BL, growth.Secondary));
            } else if (role === 'MF') {
                player.stats.PA = Math.min(99, scale(base.PA, growth.Primary));
                player.stats.AT = Math.min(99, scale(base.AT, growth.Primary));
                player.stats.EN = Math.min(99, scale(base.EN, growth.Primary));
                player.stats.SH = Math.min(99, scale(base.SH, growth.Secondary));
                player.stats.BL = Math.min(99, scale(base.BL, growth.Secondary));
            } else if (['LD', 'RD'].includes(role)) {
                player.stats.AT = Math.min(99, scale(base.AT, growth.Primary));
                player.stats.BL = Math.min(99, scale(base.BL, growth.Primary));
                player.stats.PA = Math.min(99, scale(base.PA, growth.Secondary));
                player.stats.EN = Math.min(99, scale(base.EN, growth.Secondary));
                player.stats.SH = Math.min(99, scale(base.SH, 0.2)); // Defenders bad at shooting
            } else if (role === 'GL') {
                player.stats.CA = Math.min(99, scale(base.CA, growth.Primary));
                player.stats.PA = Math.min(99, scale(base.PA, growth.Secondary));
                player.stats.SH = Math.min(99, scale(base.SH, 0.3));
            }

            // 3. Human Player Bonus (The "Hero" Feel)
            // Gives the player a slight edge to make gameplay feel punchy
// 3. Human Player Bonus (The "Hero" Feel)
            // Gives the player a slight edge to make gameplay feel punchy
            if (isHuman) {
                player.stats.HP += 300; // Tankier (was 150)
                player.stats.SP += 8;   // Faster (was 5)
                player.stats.EN += 10;   // Harder to tackle (was 5)
                
                // Key Stat Boost
                if (role === 'LF' || role === 'RF') player.stats.SH += 5;
                if (role === 'MF') player.stats.PA += 5;
                if (role === 'LD' || role === 'RD') player.stats.AT += 5;
                if (role === 'GL') player.stats.CA += 5;
            }

            // 4. Finalize
            player.stats.maxHP = player.stats.HP;
            player.level = level;
            player._updateDerivedStats();
        }

constructor(scene, id, side, color, isHuman) {
            this.scene = scene;
            this.id = id; // 'home' or 'away'
            this.side = side; // 1 (Defends +Z) or -1 (Defends -Z)
            this.color = color;
            this.isHuman = isHuman;
            this.aiEnabled = true; // Master switch for AI logic
            
            this.players = [];
            this.activePlayer = null; // The player currently controlled/focused
            
            // Formation Anchors
            this.currentFormation = 'Normal';
            
            // Player Indicator (Green Arrow)
            if (this.isHuman) {
                this.playerArrow = new THREE.Sprite(_playerArrowMaterial);
                this.playerArrow.scale.set(0.8, 0.8, 1.0);
                this.playerArrow.renderOrder = 1000; // On top
            }
        }

        assignMarks(opposingTeam) {
            // Simple auto-assign logic: Mark the player in the "matching" position
            // LF<->RD, RF<->LD, MF<->MF, LD<->RF, RD<->LF, GL<->LF
            this.players.forEach(p => {
                let targetRole = 'MF';
                switch (p.role) {
                    case 'LF': targetRole = 'RD'; break;
                    case 'RF': targetRole = 'LD'; break;
                    case 'MF': targetRole = 'MF'; break;
                    case 'LD': targetRole = 'RF'; break;
                    case 'RD': targetRole = 'LF'; break;
                    case 'GL': targetRole = 'LF'; break;
                }

                const target = opposingTeam.players.find(op => op.role === targetRole);
                if (target) {
                    p.marking = target;
                    // console.log(`${this.id} ${p.role} marked ${target.role}`);
                }
            });
        }

        addPlayer(player) {
            this.players.push(player);
            player.team = this;

            // Calculate Home Position based on Formation
            this._updatePlayerHomePosition(player);

            // Enemy indicator: red arrows over the Away team (so enemies are readable)
// Enemy indicator: red arrows over the Away team
            if (this.id === 'away' && player.mesh) {
                const arrow = new THREE.Sprite(_enemyArrowMaterial);
                arrow.scale.set(0.8, 0.8, 1.0);
                arrow.position.set(0, 3.2, 0); // above head
                arrow.renderOrder = 999;
                player.mesh.add(arrow);
                player.enemyArrow = arrow;
            }

            // Teammate indicator: White arrows for inactive humans
            if (this.isHuman && player.mesh) {
                const arrow = new THREE.Sprite(_teammateArrowMaterial);
                arrow.scale.set(0.6, 0.6, 1.0);
                arrow.position.set(0, 3.2, 0);
                arrow.renderOrder = 999;
                arrow.visible = false; // Hidden by default, managed by setActivePlayer
                player.mesh.add(arrow);
                player.teammateArrow = arrow;
            }
        }

        setFormation(name) {
            if (!FORMATIONS[name]) return;
            this.currentFormation = name;
            // console.log(`Team ${this.id} switched to ${name}`);
            
            this.players.forEach(p => {
                this._updatePlayerHomePosition(p);
            });
        }

_updatePlayerHomePosition(player) {
            const data = FORMATIONS[this.currentFormation];
            if (!data) return;

            const offset = data[player.role];
            if (offset) {
                // X Position:
                // Formations: -X is Left, +X is Right.
                // Home Team (Side 1) faces -Z. Left is -X. Use offset.x as is.
                let xPos = offset.x;
                let zPos = offset.z * this.side;

                player.homePosition.set(xPos, 0, zPos);
                
                // Away Team (Side -1) faces +Z. Left is +X. Flip X.
                if (this.side === -1) {
                    player.homePosition.x *= -1; 
                }
            }
            
            // Set initial position
            if (player.mesh) {
                player.mesh.position.copy(player.homePosition);
                // Face center (0,0,0)
                player.mesh.lookAt(0, 0, 0);
            }
        }

        update(dt) {
            // Update all players
            for (let i = 0; i < this.players.length; i++) {
                this.players[i].update(dt);
            }

            // Auto-switch active player if Human
            if (this.isHuman) {
                this.updateActivePlayerSelection();
            }
        }

        updateActivePlayerSelection() {
            const ball = window.flux.gameInstance.entities.ball;
            if (!ball) return;

            // 1. OFFENSE: If we have the ball, active player is the holder
            if (ball.holder && ball.holder.team === this) {
                if (this.activePlayer !== ball.holder) {
                    this.setActivePlayer(ball.holder);
                }
                return;
            }

            // 2. DEFENSE: Select closest to ball
            // Optimization: Only check every few frames or if distance is significant
            let closest = null;
            let minDst = Infinity;

            for (const p of this.players) {
                if (p.role === 'GL') continue; // Don't auto-switch to goalie usually
                if (!p.mesh) continue;

                const d = p.mesh.position.distanceTo(ball.mesh.position);
                if (d < minDst) {
                    minDst = d;
                    closest = p;
                }
            }

            if (closest && closest !== this.activePlayer) {
                this.setActivePlayer(closest);
            }
        }

setActivePlayer(player) {
            // Reset input on previous
            if (this.activePlayer) {
                this.activePlayer.setInput(0, 0);
            }
            this.activePlayer = player;

            // Visual Indicators
            if (this.isHuman) {
                // 1. Green Arrow for Active
                if (this.playerArrow && player.mesh) {
                    player.mesh.add(this.playerArrow);
                    this.playerArrow.position.set(0, 3.5, 0); // Float above head
                }

                // 2. White Arrows for Others
                this.players.forEach(p => {
                    if (p.teammateArrow) {
                        p.teammateArrow.visible = (p !== player);
                    }
                });
            }
        }

resetPositions() {
            for (const p of this.players) {
                if (p.mesh) {
                    p.mesh.position.copy(p.homePosition);
                    
                    // Reset Physics
                    p.velocity.set(0, 0, 0);
                    p.inputVector.set(0, 0, 0);
                    p.isDashing = false;
                    p.isThrowing = false;
p.loseBall(); // Drop ball if holding
                    p.canCatch = true; // Force reset capability
                    
                    // Reset Stats
                    p.currentEN = p.stats.EN;
                    
// Orientation: Face Center
                    p.mesh.lookAt(0, 0, 0);
                    if (p.syncRotation) p.syncRotation();
                    
                    // Reset Animation
                    p.play('idle', 0.1);
                }
            }
            // Reset active player to MF
            const mf = this.players.find(p => p.role === 'MF');
            if (mf) this.setActivePlayer(mf);
        }
    }

    window.flux.Team = Team;
})();