(function() {
    window.flux = window.flux || {};

    // Reusable vectors
    const _aiVec = new THREE.Vector3();
    const _targetPos = new THREE.Vector3();
    const _scanDir = new THREE.Vector3();
    const _scanToOpp = new THREE.Vector3();
    const _tempVec1 = new THREE.Vector3();
    const _tempVec2 = new THREE.Vector3();

    class AIPlayer extends window.flux.Player {
        constructor(scene, role) {
            super(scene, role);
            this.ballRef = null;
            
            // Stats are managed by Team/Main or default Player values.
            this._updateDerivedStats();

            // State Machine
            this.aiState = 'IDLE';
            this.decisionTimer = 0;
            this.decisionInterval = 0.5; // Slower decisions

            // --- PERCEPTION SYSTEM (Reaction Time) ---
            this.perceivedTargetPos = new THREE.Vector3();
            this.reactionSpeed = 1.5; 
            this.anticipationTime = 0.2; 
            
            // Role Config
            this.isForward = ['LF', 'RF'].includes(role);
            this.isMidfielder = role === 'MF';
            this.isDefender = ['LD', 'RD'].includes(role);

            this.techImmunityTimer = 0;
            this._assignDefaultTechs();
        }

        _assignDefaultTechs() {
            const tackleTechs = ['venom', 'wither', 'drain'];
            const shootTechs = ['venom', 'sphere', 'invisible'];
            const passTechs = ['venom', 'wither', 'nap'];
            const passiveTechs = ['brawler', 'elite_defense'];

            const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
            const chance = (prob) => Math.random() < prob;

            if (this.isDefender) {
                if (chance(0.3)) this.techs.tackle = pick(tackleTechs);
                if (chance(0.1)) this.techs.pass = pick(passTechs);
                if (chance(0.2)) this.techs.passive = pick(passiveTechs);
            } else if (this.isMidfielder) {
                if (chance(0.2)) this.techs.tackle = pick(tackleTechs);
                if (chance(0.2)) this.techs.pass = pick(passTechs);
                if (chance(0.1)) this.techs.shoot = pick(shootTechs);
                if (chance(0.1)) this.techs.passive = pick(passiveTechs);
            } else if (this.isForward) {
                if (chance(0.3)) this.techs.shoot = pick(shootTechs);
                if (chance(0.1)) this.techs.tackle = pick(tackleTechs);
                if (chance(0.1)) this.techs.passive = pick(passiveTechs);
            }
        }

        update(dt) {
            // Safety: Auto-link ball if missing
            if (!this.ballRef && window.flux.gameInstance && window.flux.gameInstance.entities) {
                this.ballRef = window.flux.gameInstance.entities.ball;
            }

            const game = window.flux.gameInstance;
            const isDemo = game && game.isDemoMode;
            
            const isIncapacitated = (this.stunTimer > 0) || (this.status.nap > 0);
            
            const isHumanTeam = this.team && this.team.isHuman;
            const isActivePlayer = this.team && (this.team.activePlayer === this);
            const shouldRunAI = (!isHumanTeam || isDemo || (isHumanTeam && !isActivePlayer));
            
            const isTeamAIEnabled = this.team ? this.team.aiEnabled : true;

            if (isIncapacitated) {
                this.setInput(0, 0);
            } else if (shouldRunAI && isTeamAIEnabled) {
                // --- PERCEPTION UPDATE ---
                if (this.ballRef && this.ballRef.mesh) {
                    let realTarget = this.ballRef.mesh.position.clone();

                    if (this.ballRef.holder && this.ballRef.holder.mesh) {
                        realTarget = this.ballRef.holder.mesh.position.clone();
                        if (this.ballRef.holder.velocity) {
                            realTarget.addScaledVector(this.ballRef.holder.velocity, this.anticipationTime);
                        }
                    } else if (this.ballRef.velocity) {
                        realTarget.addScaledVector(this.ballRef.velocity, this.anticipationTime * 0.5);
                    }

                    const alpha = Math.min(1.0, dt * this.reactionSpeed);
                    this.perceivedTargetPos.lerp(realTarget, alpha);
                }

                // 1. Decision Making
                this.decisionTimer += dt;
                if (this.decisionTimer > this.decisionInterval) {
                    this.decisionTimer = 0;
                    this._evaluateState();
                }

                // 2. Execute State
                this._executeState(dt);
                
                // 3. Interception Logic
                if (this.techImmunityTimer > 0) this.techImmunityTimer -= dt;
                this._applyInterceptionPressure(dt);

            } else {
                // AI Disabled or Human Controlled
                const isDrivenByHuman = isHumanTeam && isActivePlayer && !isDemo;
                if (!isDrivenByHuman) {
                    this.setInput(0, 0);
                }
                // Passive interception still applies
                this._applyInterceptionPressure(dt);
            }

            // 4. Base Update
            super.update(dt);
        }

        _evaluateState() {
            if (!this.ballRef) return;
            const ball = this.ballRef;

            if (this.hasBall) {
                this.aiState = 'ATTACK_CARRY';
                return;
            }

            if (!ball.holder) {
                this.aiState = 'RETURN_HOME';
                const bias = (this.aiState === 'CHASE') ? 0.8 : 1.0;
                const myDist = this.mesh.position.distanceTo(ball.mesh.position) * bias;
                
                let isClosest = true;
                if (this.team && this.team.players) {
                    for (const p of this.team.players) {
                        if (p === this) continue;
                        if (!p.mesh) continue;
                        if (p.role === 'GL') continue;
                        if (p.status && p.status.nap > 0) continue;

                        const pDist = p.mesh.position.distanceTo(ball.mesh.position);
                        if (pDist < myDist) {
                            isClosest = false;
                            break;
                        }
                    }
                }

                if (isClosest) {
                    this.aiState = 'CHASE';
                }
                return;
            }

            if (ball.holder.team === this.team) {
                this.aiState = 'SUPPORT';
                return;
            }

            if (ball.holder.team !== this.team) {
                this.aiState = 'DEFEND';
                return;
            }
        }

        _executeState(dt) {
            if (!this.ballRef) {
                this.setInput(0, 0);
                return;
            }

            switch (this.aiState) {
                case 'ATTACK_CARRY': this._stateAttackCarry(dt); break;
                case 'SUPPORT': this._stateSupport(dt); break;
                case 'DEFEND': this._stateDefend(dt); break;
                case 'CHASE': this._stateChase(dt); break;
                case 'RETURN_HOME': 
                default: this._stateReturnHome(dt); break;
            }
        }

        _stateAttackCarry(dt) {
            const attackDir = (this.team.side === 1) ? -1 : 1;
            const goalZ = 46 * attackDir;
            
            _targetPos.set(0, 0, goalZ);
            this._avoidGoalCrease(_targetPos);
            this._moveTo(_targetPos);

            const distToGoal = Math.abs(this.mesh.position.z - goalZ);
            
            if (distToGoal < 20.0 && !this.isThrowing) {
                this._smartThrow(this.ballRef, 'SH'); 
                return;
            }
            
            const isSurrounded = this._isSurrounded();
            const lowEN = this.currentEN < 10;
            const isPlaymaker = this.isMidfielder;
            
            if ((isSurrounded || lowEN || isPlaymaker) && !this.isThrowing) {
                const bestMate = this._findBestPassTarget();
                if (bestMate) {
                    let shouldPass = false;
                    if (isSurrounded || lowEN) {
                        shouldPass = true;
                    } else if (isPlaymaker) {
                        const myDist = Math.abs(this.mesh.position.z - goalZ);
                        const mateDist = Math.abs(bestMate.mesh.position.z - goalZ);
                        if (mateDist < myDist - 5.0) shouldPass = true;
                    }
                    
                    if (shouldPass) {
                        this.mesh.lookAt(bestMate.mesh.position);
                        this._smartThrow(this.ballRef, 'PA');
                        return;
                    }
                }
            }
            
            if (isSurrounded && !this.isThrowing) {
                this._smartThrow(this.ballRef, 'SH');
            }
        }

        _isSurrounded() {
            let count = 0;
            const game = window.flux.gameInstance;
            if (!game) return false;
            const oppTeam = (this.team.id === 'home') ? game.teams.away : game.teams.home;
            
            for(let p of oppTeam.players) {
                if (p.mesh && p.mesh.position.distanceTo(this.mesh.position) < 4.0) {
                    count++;
                }
            }
            return count >= 2;
        }

        _smartThrow(ball, forcedType = null) {
            let type = forcedType;
            if (!type) {
                _tempVec1.set(0, 0, 1).applyQuaternion(this.mesh.quaternion);
                const attackDir = (this.team && this.team.side === 1) ? -1 : 1;
                const isAimingGoal = (_tempVec1.z * attackDir > 0.5);
                type = isAimingGoal ? 'SH' : 'PA';
            }

            const techName = (type === 'SH') ? this.techs.shoot : this.techs.pass;
            let baseCost = (type === 'SH') ? 20 : 10;
            let techCost = 0;
            
            if (techName) {
                if (techName.includes('nap')) techCost = 30;
                else if (techName.includes('sphere') || techName.includes('invisible')) techCost = 25;
                else techCost = 20;
            }

            const totalCost = baseCost + techCost;
            let tempTech = null;
            if (techName && this.stats.HP < totalCost && this.stats.HP >= baseCost) {
                if (type === 'SH') {
                    tempTech = this.techs.shoot;
                    this.techs.shoot = null;
                } else {
                    tempTech = this.techs.pass;
                    this.techs.pass = null;
                }
            }

            this.throwBall(ball, type);

            if (tempTech) {
                if (type === 'SH') this.techs.shoot = tempTech;
                else this.techs.pass = tempTech;
            }
        }

        _stateChase(dt) {
            _targetPos.copy(this.perceivedTargetPos);
            const ball = this.ballRef;
            if (ball.velocity.lengthSq() > 1.0) {
                _targetPos.addScaledVector(ball.velocity, 0.3);
            }
            this._avoidGoalCrease(_targetPos);
            this._moveTo(_targetPos);
        }

        _stateReturnHome(dt) {
            _targetPos.copy(this.homePosition);
            this._avoidGoalCrease(_targetPos);
            this._moveTo(_targetPos);
        }

        _stateSupport(dt) {
            const ball = this.ballRef;
            const carrier = ball.holder;
            
            if (!carrier || !carrier.mesh) {
                this._stateReturnHome(dt);
                return;
            }

            const ballPos = carrier.mesh.position;
            const attackDir = (this.team.side === 1) ? -1 : 1;
            const goalZ = (this.team.side === 1) ? -46 : 46;

            const pressure = this._calculatePressureOnPlayer(carrier);

            _targetPos.copy(this.homePosition);
            _targetPos.z += ballPos.z * 0.6;

            if (this.isForward) {
                let targetZ = ballPos.z + (attackDir * 15.0); 
                if (pressure > 0.8) {
                    targetZ = ballPos.z + (attackDir * 8.0);
                }
                const time = Date.now() * 0.001;
                const weave = Math.sin(time + this.mesh.id) * 6.0;
                _targetPos.x = this.homePosition.x + weave;
                _targetPos.z = targetZ;

            } else if (this.isMidfielder) {
                if (pressure > 0.8) {
                    const side = (this.mesh.position.x > ballPos.x) ? 1 : -1;
                    _targetPos.x = ballPos.x + (side * 10.0);
                    _targetPos.z = ballPos.z - (attackDir * 2.0);
                } else {
                    const midZ = (ballPos.z + goalZ) * 0.45;
                    _targetPos.z = midZ;
                    if (ballPos.x < -5) _targetPos.x = 5;
                    else if (ballPos.x > 5) _targetPos.x = -5;
                    else _targetPos.x = (this.homePosition.x > 0 ? 8 : -8);
                }

            } else {
                const safetyDist = 12.0;
                _targetPos.z = ballPos.z - (attackDir * safetyDist);
                if (this.team.side === 1) _targetPos.z = Math.min(38, _targetPos.z);
                else _targetPos.z = Math.max(-38, _targetPos.z);
                _targetPos.x = ballPos.x * 0.6 + this.homePosition.x * 0.4;
            }

            if (this._isPathBlocked(_targetPos, ballPos)) {
                _tempVec1.copy(_targetPos); _tempVec1.x -= 8.0;
                _tempVec2.copy(_targetPos); _tempVec2.x += 8.0;
                
                const blockedL = this._isPathBlocked(_tempVec1, ballPos);
                const blockedR = this._isPathBlocked(_tempVec2, ballPos);
                
                if (!blockedL && !blockedR) {
                    if (Math.abs(_targetPos.x - _tempVec1.x) < Math.abs(_targetPos.x - _tempVec2.x)) {
                        _targetPos.copy(_tempVec1);
                    } else {
                        _targetPos.copy(_tempVec2);
                    }
                } else if (!blockedL) {
                    _targetPos.copy(_tempVec1);
                } else if (!blockedR) {
                    _targetPos.copy(_tempVec2);
                } else {
                    _targetPos.lerp(ballPos, 0.4);
                }
            }

            this._avoidTeammates(_targetPos);
            this._avoidGoalCrease(_targetPos);
            this._moveTo(_targetPos);
        }

        _stateDefend(dt) {
            const targetPos = this.perceivedTargetPos;
            const distToBall = this.mesh.position.distanceTo(targetPos);
            
            let pressRange = this.isDefender ? 12.0 : 8.0;
            if (this.techs.tackle && this.stats.HP > 20) {
                pressRange += 5.0; 
            }

            let amIClosest = true;
            const myDistSq = distToBall * distToBall;
            
            if (this.team && this.team.players) {
                for(const mate of this.team.players) {
                    if (mate === this || !mate.mesh) continue;
                    if (mate.role === 'GL' || mate.status.nap > 0 || mate.stunTimer > 0) continue;
                    
                    const dSq = mate.mesh.position.distanceToSquared(targetPos);
                    if (dSq < myDistSq) {
                        amIClosest = false;
                        break;
                    }
                }
            }

            if (amIClosest) {
                pressRange = 100.0;
            } else {
                const distToMyGoal = Math.abs(targetPos.z - (this.team.side === 1 ? 46 : -46));
                if (distToMyGoal < 40.0) {
                    pressRange = 15.0;
                } else {
                    pressRange = 8.0;
                }
            }
            
            if (distToBall < pressRange) {
                if (distToBall < 3.0 && !this.isDashing && this.currentEN > 5 && Math.random() < 0.02) {
                    const dir = _tempVec1.subVectors(targetPos, this.mesh.position).normalize();
                    if (this.ballRef && this.ballRef.velocity) {
                        dir.addScaledVector(this.ballRef.velocity, 0.1).normalize();
                    }
                    this.dash(dir.x, dir.z);
                    return;
                }

                _targetPos.copy(targetPos);
                this._avoidGoalCrease(_targetPos);
                this._moveTo(_targetPos);
                return;
            }

            if (this.marking && this.marking.mesh) {
                const markPos = this.marking.mesh.position;
                const myGoalZ = (this.team.side === 1) ? 46 : -46;
                _tempVec1.set(0, 0, myGoalZ - markPos.z);
                _tempVec1.normalize();
                _targetPos.copy(markPos).addScaledVector(_tempVec1, 3.5);
                this._avoidGoalCrease(_targetPos);
                this._moveTo(_targetPos);
                return;
            }

            _targetPos.copy(this.homePosition);
            _targetPos.z += this.ballRef.mesh.position.z * 0.6;
            
            if (this.isDefender) {
                const myGoalZ = (this.team.side === 1) ? 46 : -46;
                const midpoint = (this.ballRef.mesh.position.z + myGoalZ) * 0.5;
                _targetPos.z = (_targetPos.z + midpoint) * 0.5;
            }

            _targetPos.z = Math.max(-44.0, Math.min(44.0, _targetPos.z));
            this._avoidGoalCrease(_targetPos);
            this._moveTo(_targetPos);
        }

        _avoidGoalCrease(targetPos) {
            const creaseRadius = 10.0;
            const goals = [{ x: 0, z: -46 }, { x: 0, z: 46 }];

            goals.forEach(goal => {
                const dx = targetPos.x - goal.x;
                const dz = targetPos.z - goal.z;
                const distSq = dx*dx + dz*dz;

                if (distSq < creaseRadius * creaseRadius) {
                    const dist = Math.sqrt(distSq);
                    if (dist > 0.001) {
                        const ratio = creaseRadius / dist;
                        targetPos.x = goal.x + dx * ratio;
                        targetPos.z = goal.z + dz * ratio;
                    } else {
                        targetPos.z = goal.z + (goal.z > 0 ? -creaseRadius : creaseRadius);
                    }
                }
            });

            const arenaRadius = 45.0;
            const dSq = targetPos.x * targetPos.x + targetPos.z * targetPos.z;
            if (dSq > arenaRadius*arenaRadius) {
                const d = Math.sqrt(dSq);
                const r = arenaRadius / d;
                targetPos.x *= r;
                targetPos.z *= r;
            }
        }

        _findBestPassTarget() {
            let bestTarget = null;
            let maxScore = -Infinity;
            const goalZ = (this.team.side === 1) ? -46 : 46;

            for (const mate of this.team.players) {
                if (mate === this) continue;
                if (!mate.mesh) continue;
                if (mate.status.nap > 0) continue;
                if (mate.stunTimer > 0) continue;
                
                const dist = this.mesh.position.distanceTo(mate.mesh.position);
                if (dist < 4.0) continue;
                if (dist > 30.0) continue;
                
                if (this._isPathBlocked(mate.mesh.position)) continue; 
                
                let score = 0;
                const myDistToGoal = Math.abs(this.mesh.position.z - goalZ);
                const mateDistToGoal = Math.abs(mate.mesh.position.z - goalZ);
                const progress = myDistToGoal - mateDistToGoal;
                
                score += progress * 1.5; 
                if (mateDistToGoal < 15.0) score += 10.0;
                if (mateDistToGoal < 8.0) score += 15.0;

                const openness = this._calculateOpenness(mate);
                score += openness * 3.0;

                if (mate.isForward) score += 5.0;
                score -= dist * 0.5;

                if (score > maxScore) {
                    maxScore = score;
                    bestTarget = mate;
                }
            }
            return bestTarget;
        }

        _calculateOpenness(player) {
            let minDefDist = 999;
            const game = window.flux.gameInstance;
            if (!game) return 0;
            const oppTeam = (this.team.id === 'home') ? game.teams.away : game.teams.home;

            for (const opp of oppTeam.players) {
                if (!opp.mesh || opp.status.nap > 0 || opp.stunTimer > 0) continue;
                const d = player.mesh.position.distanceTo(opp.mesh.position);
                if (d < minDefDist) minDefDist = d;
            }
            return Math.min(minDefDist, 8.0);
        }

        _isPathBlocked(targetPos, startPos = null) {
            const start = startPos || this.mesh.position;
            const end = targetPos;
            const dist = start.distanceTo(end);
            
            _scanDir.subVectors(end, start).normalize();
            
            const game = window.flux.gameInstance;
            if (!game) return false;
            const oppTeam = (this.team.id === 'home') ? game.teams.away : game.teams.home;
            const safetyRadius = 2.5; 

            for (const opp of oppTeam.players) {
                if (!opp.mesh || opp.status.nap > 0 || opp.stunTimer > 0) continue;
                
                _scanToOpp.subVectors(opp.mesh.position, start);
                const projection = _scanToOpp.dot(_scanDir);
                
                if (projection > 0 && projection < dist) {
                    const perpDistSq = _scanToOpp.lengthSq() - (projection * projection);
                    if (perpDistSq < (safetyRadius * safetyRadius)) {
                        return true;
                    }
                }
            }
            return false;
        }

        _moveTo(target) {
            _aiVec.subVectors(target, this.mesh.position);
            _aiVec.y = 0;
            
            const distSq = _aiVec.lengthSq();
            if (distSq > 1.0) {
                _aiVec.normalize();
                this.setInput(_aiVec.x, _aiVec.z);
            } else {
                this.setInput(0, 0);
                this.velocity.multiplyScalar(0.8);
            }
        }

        _applyInterceptionPressure(dt) {
            const ball = this.ballRef;
            if (!ball || !ball.mesh) return;

            if (ball.state !== 'free' || ball.velocity.lengthSq() < 1.0) return;
            if (ball.isInvisible) return;
            if (this.status.nap > 0 || this.stunTimer > 0) return;

            let range = 2.0;
            if (this.techs.passive === 'brawler' || this.techs.passive === 'elite_defense') {
                range += 1.5;
            }

            const dist = this.mesh.position.distanceTo(ball.mesh.position);
            if (dist > range) return;

            _scanToOpp.subVectors(this.mesh.position, ball.mesh.position).normalize();
            _tempVec1.copy(ball.velocity).normalize();
            
            const headingDot = _tempVec1.dot(_scanToOpp);
            if (headingDot < 0.7) return;

            const distFactor = Math.max(0, 1.0 - (dist / range));
            const pressure = 1.5;

            if (ball.power > 0) {
                ball.power -= pressure;
                this._accumulatedBlock = (this._accumulatedBlock || 0) + pressure;
                if (this._accumulatedBlock >= 5.0) { 
                    const val = Math.floor(this._accumulatedBlock);
                    this._accumulatedBlock -= val;
                    if (window.flux.gameInstance.floatingText) { 
                         window.flux.gameInstance.floatingText.spawn(`-${val}`, ball.mesh.position, "block", ball.mesh);
                    }
                }
            }

            if (Math.random() < (distFactor * 0.8)) { 
                _tempVec2.copy(this.mesh.position).lerp(ball.mesh.position, 0.5 + (Math.random()-0.5)*0.2);
                _tempVec2.x += (Math.random()-0.5) * 0.5;
                _tempVec2.y += (Math.random()-0.5) * 0.5;
                _tempVec2.z += (Math.random()-0.5) * 0.5;
                
                if (window.flux.gameInstance.spawnClash) {
                    window.flux.gameInstance.spawnClash(_tempVec2, 0.6);
                }
            }

            if (ball.power <= 0 && ball.powerType === 'SH') {
                ball.powerType = 'none';
                if (window.flux.gameInstance.floatingText) { 
                    window.flux.gameInstance.floatingText.spawn("BLOCKED", this.mesh.position, "comic-impact");
                }
            }

            if (ball.technique && this.techImmunityTimer <= 0) {
                this.techImmunityTimer = 2.0;
                const tech = ball.technique;
                if (tech.type === 'venom') this.applyStatus('venom', 15.0);
                else if (tech.type === 'nap') this.applyStatus('nap', 8.0);
                else if (tech.type === 'wither') this.applyStatus('wither', 15.0, 'BL');
            }
        }

        _calculatePressureOnPlayer(player) {
            if (!player || !player.mesh) return 0;
            const game = window.flux.gameInstance;
            if (!game) return 0;
            
            const oppTeam = (player.team.id === 'home') ? game.teams.away : game.teams.home;
            let pressure = 0;
            
            for (const opp of oppTeam.players) {
                if (!opp.mesh || opp.status.nap > 0 || opp.stunTimer > 0) continue;
                const dist = player.mesh.position.distanceTo(opp.mesh.position);
                if (dist < 10.0) {
                    pressure += (10.0 - dist) / 10.0;
                }
            }
            return pressure;
        }

        _avoidTeammates(targetPos) {
            if (!this.team) return;
            for (const mate of this.team.players) {
                if (mate === this || !mate.mesh) continue;
                if (mate.hasBall) continue;
                
                const dist = targetPos.distanceTo(mate.mesh.position);
                if (dist < 5.0) {
                    _tempVec1.subVectors(targetPos, mate.mesh.position).normalize();
                    targetPos.addScaledVector(_tempVec1, 5.0 - dist);
                }
            }
        }
    }

    window.flux.AIPlayer = AIPlayer;
})();