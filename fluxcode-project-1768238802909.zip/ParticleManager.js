(function() {
    window.flux = window.flux || {};

    // --- TEXTURE GENERATORS ---
    
    // 1. Venom Bubble (Green, shiny, sharp)
    const _venomTex = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        const g = ctx.createRadialGradient(32, 32, 4, 32, 32, 30);
        g.addColorStop(0, 'rgba(150, 255, 100, 0.9)');
        g.addColorStop(0.8, 'rgba(0, 200, 0, 0.5)');
        g.addColorStop(1, 'rgba(0, 50, 0, 0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(32, 32, 30, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.beginPath(); ctx.arc(20, 20, 6, 0, Math.PI*2); ctx.fill();
        return new THREE.CanvasTexture(c);
    })();

    // 2. Sleep Zzz
    const _napTex = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        ctx.font = 'bold italic 48px sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor = '#0000ff';
        ctx.shadowBlur = 4;
        ctx.fillText('Z', 32, 32);
        return new THREE.CanvasTexture(c);
    })();

    // 3. Wither Smoke
// 3. Wither Smoke (Optimized to 32x32)
    const _witherTex = (() => {
        const c = document.createElement('canvas');
        c.width = 32; c.height = 32;
        const ctx = c.getContext('2d');
        const g = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
        g.addColorStop(0, 'rgba(80, 80, 80, 0.8)');
        g.addColorStop(0.5, 'rgba(40, 40, 40, 0.4)');
        g.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 32, 32);
        return new THREE.CanvasTexture(c);
    })();

    // 4. Shockwave Ring (Optimized to 64x64)
    const _shockwaveTex = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        const cx = 32, cy = 32;
        const g = ctx.createRadialGradient(cx, cy, 20, cx, cy, 30);
        g.addColorStop(0, 'rgba(255, 255, 255, 0)');
        g.addColorStop(0.5, 'rgba(255, 255, 255, 1)');
        g.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, 64, 64);
        return new THREE.CanvasTexture(c);
    })();

    // 5. Flash Star (Optimized to 32x32)
    const _flashTex = (() => {
        const c = document.createElement('canvas');
        c.width = 32; c.height = 32;
        const ctx = c.getContext('2d');
        const cx = 16, cy = 16;
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        for(let i=0; i<4; i++) {
            const a = (i * Math.PI / 2);
            ctx.moveTo(cx, cy);
            ctx.lineTo(cx + Math.cos(a)*15, cy + Math.sin(a)*15);
            ctx.lineTo(cx + Math.cos(a + 0.2)*5, cy + Math.sin(a + 0.2)*5);
        }
        ctx.fill();
        const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 10);
        g.addColorStop(0, 'rgba(255, 255, 255, 1)');
        g.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(cx, cy, 10, 0, Math.PI*2); ctx.fill();
        return new THREE.CanvasTexture(c);
    })();

    // 6. Debris Shard (New)
    const _debrisTex = (() => {
        const c = document.createElement('canvas');
        c.width = 32; c.height = 32;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.moveTo(16, 0); ctx.lineTo(32, 16); ctx.lineTo(16, 32); ctx.lineTo(0, 16);
        ctx.fill();
        return new THREE.CanvasTexture(c);
    })();

    // 7. Bubble Texture (New: Aesthetic & Subtle)
// 7. Bubble Texture (New: Aesthetic & Subtle)
    const _bubbleTex = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 64;
        const ctx = c.getContext('2d');
        
        // Clear
        ctx.clearRect(0, 0, 64, 64);

        // Tighter, Shimmery Bubble
        const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 28);
        g.addColorStop(0, 'rgba(255, 255, 255, 0.95)'); // Sharp highlight center
        g.addColorStop(0.3, 'rgba(200, 240, 255, 0.4)');
        g.addColorStop(0.8, 'rgba(100, 200, 255, 0.1)');
        g.addColorStop(1, 'rgba(0, 0, 0, 0)');
        
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(32, 32, 30, 0, Math.PI*2); ctx.fill();
        
        // Sharp Specular Dot
        ctx.fillStyle = 'rgba(255, 255, 255, 1.0)';
        ctx.beginPath(); 
        ctx.arc(20, 20, 4, 0, Math.PI * 2); 
        ctx.fill();
        
        return new THREE.CanvasTexture(c);
    })();

    // 8. Micro Bubble (New: Sharp, high-vis cavitation)
    const _microBubbleTex = (() => {
        const c = document.createElement('canvas');
        c.width = 32; c.height = 32;
        const ctx = c.getContext('2d');
        ctx.clearRect(0, 0, 32, 32);
        
        // Intense bright core
        const g = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
        g.addColorStop(0, 'rgba(255, 255, 255, 1.0)');
        g.addColorStop(0.3, 'rgba(220, 255, 255, 0.8)');
        g.addColorStop(0.6, 'rgba(100, 200, 255, 0.3)');
        g.addColorStop(1.0, 'rgba(0, 0, 0, 0)');
        
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(16, 16, 16, 0, Math.PI*2); ctx.fill();
        return new THREE.CanvasTexture(c);
    })();

    // 9. Dash Stream (New: Speed line)
    const _dashStreamTex = (() => {
        const c = document.createElement('canvas');
        c.width = 64; c.height = 16;
        const ctx = c.getContext('2d');
        
        const g = ctx.createLinearGradient(0, 0, 64, 0);
        g.addColorStop(0, 'rgba(0, 255, 255, 0)');
        g.addColorStop(0.5, 'rgba(200, 255, 255, 0.8)');
        g.addColorStop(1, 'rgba(0, 255, 255, 0)');
        
        ctx.fillStyle = g;
        ctx.fillRect(0, 4, 64, 8);
        
        return new THREE.CanvasTexture(c);
    })();

    class ParticleManager {

        constructor(scene) {
            this.scene = scene;
            this.particles = [];
            
            // Mobile Optimization: Check screen width
            const isMobile = window.innerWidth < 800;
            
            // Shared Materials
            // Note: alphaTest added to NormalBlending materials to help GPU discard transparent pixels
            this.materials = {
                venom: new THREE.SpriteMaterial({ map: _venomTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }),
                nap: new THREE.SpriteMaterial({ map: _napTex, transparent: true, depthWrite: false, blending: THREE.NormalBlending, alphaTest: 0.1 }),
                wither: new THREE.SpriteMaterial({ map: _witherTex, transparent: true, depthWrite: false, blending: THREE.NormalBlending, alphaTest: 0.05 }),
                learned: new THREE.SpriteMaterial({ map: _venomTex, color: 0x00ffff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }),
                shockwave: new THREE.SpriteMaterial({ map: _shockwaveTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }),
                flash: new THREE.SpriteMaterial({ map: _flashTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }),
                debris: new THREE.SpriteMaterial({ map: _debrisTex, transparent: true, depthWrite: false, blending: THREE.NormalBlending, alphaTest: 0.1 }),
                bubble: new THREE.SpriteMaterial({ map: _bubbleTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }),
                bubble_micro: new THREE.SpriteMaterial({ map: _microBubbleTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }),
                dash_stream: new THREE.SpriteMaterial({ map: _dashStreamTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending })
            };

            // Object Pool
            this.pool = [];
            // Reduce pool size on mobile to prevent excessive overdraw
            this.poolSize = isMobile ? 120 : 300;
            
            for(let i=0; i<this.poolSize; i++) {
                // Clone material to allow individual opacity/rotation
                // We clone 'venom' as a placeholder, it gets overwritten in spawn()
                const mat = this.materials.venom.clone();
                const sprite = new THREE.Sprite(mat); 
                sprite.visible = false;
                sprite.scale.set(0,0,0); 
                // Optimization: Disable frustum culling for particles to avoid CPU overhead of bounding box calc
                // since they are always in front of camera usually, or cheap to draw.
                // Actually, keeping culling is better if they go off screen.
                // sprite.frustumCulled = false; 
                this.scene.add(sprite);
                this.pool.push(sprite);
            }
        }

        spawn(type, pos, options = {}) {
            const p = this.pool.find(s => !s.visible);
            if (!p) return;

            p.visible = true;
            
            const template = this.materials[type] || this.materials.venom;
            p.material.map = template.map;
            p.material.blending = template.blending;
            p.material.depthWrite = template.depthWrite;
            p.material.transparent = template.transparent;

            p.position.copy(pos);
            
            p.material.rotation = 0;
            p.material.color.setHex(0xffffff);
            p.material.opacity = 1.0;

            const data = {
                mesh: p,
                type: type,
                age: 0,
                life: options.life || 1.0,
                maxLife: options.life || 1.0,
                velocity: new THREE.Vector3(0, 0, 0),
                startScale: options.scale || 1.0,
                gravity: 0,
                drag: 0
            };

            // Configuration per type
            if (type === 'venom') {
                data.life = 1.0 + Math.random() * 0.5;
                data.velocity.set(0, 1.0 + Math.random(), 0);
                data.startScale = 0.3 + Math.random() * 0.2;
                p.material.opacity = 0.8;
                
            } else if (type === 'nap') {
                data.life = 2.0;
                data.velocity.set((Math.random()-0.5)*0.2, 0.5, (Math.random()-0.5)*0.2);
                data.startScale = 0.4;
                p.material.opacity = 1.0;

            } else if (type === 'wither') {
                data.life = 1.5;
                data.velocity.set((Math.random()-0.5)*0.5, 0.5, (Math.random()-0.5)*0.5);
                p.material.opacity = 0.6;
                p.material.rotation = Math.random() * Math.PI;

            } else if (type === 'shockwave') {
                data.life = options.life || 0.4;
                data.maxLife = data.life;
                data.startScale = options.scale || 2.0;
                p.material.opacity = 1.0;
                
            } else if (type === 'flash') {
                data.life = 0.2;
                data.maxLife = 0.2;
                data.startScale = options.scale || 3.0;
                p.material.opacity = 1.0;
                p.material.rotation = Math.random() * Math.PI;

            } else if (type === 'debris') {
                data.life = 1.5;
                data.maxLife = 1.5;
                const speed = 5.0 + Math.random() * 10.0;
                data.velocity.set(
                    (Math.random()-0.5) * speed,
                    (Math.random() * speed * 0.5) + 2.0,
                    (Math.random()-0.5) * speed
                );
                data.gravity = 20.0;
                data.drag = 1.0;
                data.startScale = (options.scale || 0.3) * (0.5 + Math.random());
                p.material.opacity = 1.0;
                p.material.rotation = Math.random() * Math.PI;

            } else if (type === 'bubble') {
                data.life = 1.0 + Math.random() * 1.0;
                data.maxLife = data.life;
                data.velocity.set(
                    (Math.random() - 0.5) * 0.5,
                    0.5 + Math.random() * 1.0,
                    (Math.random() - 0.5) * 0.5
                );
data.startScale = (options.scale || 0.15) * (0.8 + Math.random() * 0.4); // Smaller, tighter bubbles
                p.material.opacity = 0.9; // More opaque
                p.material.color.setHex(0xaaccff);

            } else if (type === 'bubble_micro') {
                data.life = 0.4 + Math.random() * 0.4;
                data.maxLife = data.life;
                data.velocity.set(
                    (Math.random() - 0.5) * 1.5,
                    1.5 + Math.random() * 2.0,
                    (Math.random() - 0.5) * 1.5
                );
data.startScale = (options.scale || 0.15) * (0.8 + Math.random() * 0.5); // Larger micro bubbles
                p.material.opacity = 1.0;
                p.material.color.setHex(0xffffff);

            } else if (type === 'dash_stream') {
                data.life = 0.3;
                data.maxLife = 0.3;
                data.startScale = options.scale || 2.0;
                p.material.opacity = 0.8;
                p.material.rotation = Math.random() * Math.PI;
            }

            if (type !== 'shockwave') {
                p.scale.setScalar(data.startScale);
            } else {
                p.scale.setScalar(0.1);
            }

            this.particles.push(data);
        }

        update(dt) {
            for (let i = this.particles.length - 1; i >= 0; i--) {
                const p = this.particles[i];
                p.age += dt;

                if (p.age >= p.life) {
                    p.mesh.visible = false;
                    p.mesh.scale.set(0,0,0);
                    this.particles.splice(i, 1);
                    continue;
                }

                const t = p.age / p.life;

                if (p.gravity > 0) p.velocity.y -= p.gravity * dt;
                if (p.drag > 0) p.velocity.multiplyScalar(Math.max(0, 1.0 - (p.drag * dt)));
                p.mesh.position.addScaledVector(p.velocity, dt);

                if (p.type === 'shockwave') {
                    const s = p.startScale * Math.pow(t, 0.5) * 5.0; 
                    p.mesh.scale.setScalar(s);
                    p.mesh.material.opacity = 1.0 - Math.pow(t, 2);
                    
                } else if (p.type === 'flash') {
                    const s = p.startScale * (1.0 - t);
                    p.mesh.scale.setScalar(s);
                    p.mesh.material.rotation += 5.0 * dt;

                } else if (p.type === 'debris') {
                    p.mesh.material.rotation += 10.0 * dt;
                    p.mesh.scale.setScalar(p.startScale * (1.0 - t));
                    
                } else if (p.type === 'venom') {
                    p.mesh.position.x += Math.sin(p.age * 10 + p.mesh.id) * dt * 0.5;
                    p.mesh.material.opacity = 0.8 * (1.0 - Math.pow(t, 3));
                    
                } else if (p.type === 'nap') {
                    const s = p.startScale * (0.5 + t * 1.5);
                    p.mesh.scale.setScalar(s);
                    p.mesh.material.opacity = 1.0 - Math.pow(t, 2);
                    p.mesh.position.x += Math.sin(p.age * 2) * dt * 0.3;

                } else if (p.type === 'bubble') {
                    p.mesh.position.x += Math.sin(p.age * 5.0 + p.mesh.id) * dt * 0.2;
                    p.mesh.position.z += Math.cos(p.age * 4.0 + p.mesh.id) * dt * 0.2;
                    
                    const s = p.startScale * (1.0 + t * 0.2);
                    p.mesh.scale.setScalar(s);
                    p.mesh.material.opacity = 0.6 * (1.0 - Math.pow(t, 2));

                } else if (p.type === 'bubble_micro') {
                    p.mesh.position.x += (Math.random() - 0.5) * dt * 2.0;
                    p.mesh.position.z += (Math.random() - 0.5) * dt * 2.0;
                    
                    const s = p.startScale * (1.0 - t);
                    p.mesh.scale.setScalar(s);
                    p.mesh.material.opacity = 0.9 * (1.0 - t);
                    
                    const s2 = p.startScale;
                    p.mesh.scale.set(s2 * (1.0 + t), s2 * 0.2, 1.0);
                }
            }
        }
    }
    window.flux.ParticleManager = ParticleManager;
})();