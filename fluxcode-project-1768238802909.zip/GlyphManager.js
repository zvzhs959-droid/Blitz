(function() {
    window.flux = window.flux || {};

    // --- TEXTURE GENERATION ---
    const _createGlyphTexture = (colorStr, type) => {
        const size = 256;
        const c = document.createElement('canvas');
        c.width = size; c.height = size;
        const ctx = c.getContext('2d');
        
        ctx.clearRect(0, 0, size, size);
        
        // Glow settings
        ctx.shadowBlur = 15;
        ctx.shadowColor = colorStr;
        ctx.strokeStyle = colorStr;
        ctx.fillStyle = colorStr;
        ctx.lineCap = 'round';

        const cx = size / 2;
        const cy = size / 2;

        if (type === 'ring') {
            // Outer Ring
            ctx.lineWidth = 6;
            ctx.beginPath();
            ctx.arc(cx, cy, 110, 0, Math.PI * 2);
            ctx.stroke();

            // Inner Ring
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(cx, cy, 90, 0, Math.PI * 2);
            ctx.stroke();

            // Runes
ctx.font = '24px Spira, sans-serif';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            for(let i=0; i<8; i++) {
                const angle = (i / 8) * Math.PI * 2;
                const r = 100;
                const x = cx + Math.cos(angle) * r;
                const y = cy + Math.sin(angle) * r;
                
                ctx.save();
                ctx.translate(x, y);
                ctx.rotate(angle + Math.PI/2);
                // Draw a simple rune-like shape
                ctx.beginPath();
                ctx.moveTo(-5, -5); ctx.lineTo(5, 0); ctx.lineTo(-5, 5);
                ctx.stroke();
                ctx.restore();
            }
        } else if (type === 'rune') {
            // Central Complex Rune
            ctx.lineWidth = 5;
            ctx.beginPath();
            ctx.arc(cx, cy, 60, 0, Math.PI * 2);
            ctx.stroke();
            
            ctx.beginPath();
            ctx.moveTo(cx, cy - 60);
            ctx.lineTo(cx, cy + 60);
            ctx.moveTo(cx - 60, cy);
            ctx.lineTo(cx + 60, cy);
            ctx.stroke();

            ctx.beginPath();
            ctx.arc(cx, cy, 20, 0, Math.PI * 2);
            ctx.fill();
        }

        const tex = new THREE.CanvasTexture(c);
        return tex;
    };

    const _techTexture = _createGlyphTexture('#00ffff', 'ring'); // Cyan Ring
    const _statusTexture = _createGlyphTexture('#ff00ff', 'rune'); // Magenta Rune
    const _chargeTexture = _createGlyphTexture('#ffff00', 'ring'); // Gold Ring

    class GlyphManager {
        constructor(scene) {
            this.scene = scene;
            this.glyphs = [];
            
            // Materials
            this.materials = {
                tech: new THREE.MeshBasicMaterial({ 
                    map: _techTexture, 
                    transparent: true, 
                    side: THREE.DoubleSide, 
                    blending: THREE.AdditiveBlending,
                    depthWrite: false,
                    color: 0xffffff
                }),
                status: new THREE.MeshBasicMaterial({ 
                    map: _statusTexture, 
                    transparent: true, 
                    side: THREE.DoubleSide, 
                    blending: THREE.AdditiveBlending,
                    depthWrite: false,
                    color: 0xffffff
                }),
                charge: new THREE.MeshBasicMaterial({ 
                    map: _chargeTexture, 
                    transparent: true, 
                    side: THREE.DoubleSide, 
                    blending: THREE.AdditiveBlending,
                    depthWrite: false,
                    color: 0xffffff
                })
            };

            // Pool
            this.pool = [];
            this.poolSize = 30;
            const geo = new THREE.PlaneGeometry(1, 1);
            
            for(let i=0; i<this.poolSize; i++) {
                const mesh = new THREE.Mesh(geo, this.materials.tech);
                mesh.visible = false;
                mesh.renderOrder = 2000; // Draw on top of water/arena
                this.scene.add(mesh);
                this.pool.push(mesh);
            }
        }

        spawn(type, pos, options = {}) {
            const mesh = this.pool.find(m => !m.visible);
            if (!mesh) return;

            mesh.visible = true;
            mesh.material = this.materials[type] || this.materials.tech;
            mesh.position.copy(pos);
            
            // Reset Material Opacity
            mesh.material.opacity = 1.0;

            // Defaults
            const scale = options.scale || 1.0;
            mesh.scale.set(scale, scale, scale);
            
            // Orientation
            if (options.faceCamera) {
                if (window.flux.gameInstance && window.flux.gameInstance.camera) {
                    mesh.lookAt(window.flux.gameInstance.camera.position);
                }
            } else if (options.orientation === 'vertical') {
                mesh.rotation.set(0, 0, 0);
                // Face camera Y-axis rotation only
                if (window.flux.gameInstance && window.flux.gameInstance.camera) {
                    const camPos = window.flux.gameInstance.camera.position;
                    const angle = Math.atan2(camPos.x - pos.x, camPos.z - pos.z);
                    mesh.rotation.y = angle;
                }
            } else {
                // Horizontal (Ground)
                mesh.rotation.set(-Math.PI / 2, 0, Math.random() * Math.PI);
            }

            if (options.offsetY) {
                mesh.position.y += options.offsetY;
            }

            this.glyphs.push({
                mesh: mesh,
                age: 0,
                life: options.life || 1.0,
                maxLife: options.life || 1.0,
                rotationSpeed: options.rotationSpeed || 1.0,
                scaleSpeed: options.scaleSpeed || 0,
                fade: options.fade !== undefined ? options.fade : true,
                followTarget: options.parent || null,
                offsetY: options.offsetY || 0
            });
        }
update(dt) {
            for (let i = this.glyphs.length - 1; i >= 0; i--) {
                const g = this.glyphs[i];
                g.age += dt;

                if (g.age >= g.life) {
                    g.mesh.visible = false;
                    this.glyphs.splice(i, 1);
                    continue;
                }

                const t = g.age / g.maxLife;

                // Follow target
                if (g.followTarget && g.followTarget.mesh) {
                    g.mesh.position.copy(g.followTarget.mesh.position);
                    g.mesh.position.y += g.offsetY;
                    
                    // If ground oriented, keep near floor
                    if (g.mesh.rotation.x === -Math.PI/2) {
                         g.mesh.position.y = 0.1 + g.offsetY;
                    }
                }

                // Animation
                g.mesh.rotation.z += g.rotationSpeed * dt;
                
                if (g.scaleSpeed !== 0) {
                    const s = g.mesh.scale.x + g.scaleSpeed * dt;
                    g.mesh.scale.set(s, s, s);
                }

                // Fade
                if (g.fade) {
                    let opacity = 1.0;
                    if (t < 0.1) opacity = t / 0.1;
                    else if (t > 0.7) opacity = 1.0 - ((t - 0.7) / 0.3);
                    g.mesh.material.opacity = opacity;
                }
            }
        }

        clear() {
            // Hide all active glyphs and reset list
            for (const g of this.glyphs) {
                if (g.mesh) g.mesh.visible = false;
            }
            this.glyphs = [];
        }
    }

    window.flux.GlyphManager = GlyphManager;
})();