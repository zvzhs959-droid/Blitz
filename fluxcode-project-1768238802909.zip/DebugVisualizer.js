(function() {
    window.flux = window.flux || {};

    class DebugVisualizer {
constructor(scene) {
            this.scene = scene;
            this.enabled = false;
            this.showHitboxes = false;
            this.showVectors = false;
            this.showAI = false;
            this.showGoalVolume = false;

            this.visuals = new Map();
            
            // Materials
            this.matTackle = new THREE.MeshBasicMaterial({ color: 0xff0000, wireframe: true, transparent: true, opacity: 0.2 });
            this.matCatch = new THREE.MeshBasicMaterial({ color: 0x00ff00, wireframe: true, transparent: true, opacity: 0.2 });
            this.matVel = new THREE.LineBasicMaterial({ color: 0xffff00 }); // Yellow Velocity
            this.matInput = new THREE.LineBasicMaterial({ color: 0x00ffff }); // Cyan Input
            this.matAI = new THREE.LineBasicMaterial({ color: 0xff00ff }); // Magenta AI Perception
            
            // Geometries
            this.geoCylinder = new THREE.CylinderGeometry(1, 1, 0.1, 16);
            this.geoCylinder.translate(0, 0.05, 0);

            // Goal Volume Visualization (Red Transparent Box)
            const goalGeo = new THREE.BoxGeometry(22, 18, 10);
            const goalMat = new THREE.MeshBasicMaterial({ 
                color: 0xff0000, 
                transparent: true, 
                opacity: 0.25, 
                side: THREE.DoubleSide, 
                depthWrite: false 
            });

            this.goalVol1 = new THREE.Mesh(goalGeo, goalMat);
            this.goalVol1.position.set(0, -4.5, -50); // Home Goal Zone (-45 to -55)
            this.goalVol1.visible = false;
            this.scene.add(this.goalVol1);

            this.goalVol2 = new THREE.Mesh(goalGeo, goalMat);
            this.goalVol2.position.set(0, -4.5, 50); // Away Goal Zone (45 to 55)
            this.goalVol2.visible = false;
            this.scene.add(this.goalVol2);
        }

update() {
            // Update static debugs
            if (this.goalVol1) this.goalVol1.visible = this.enabled && this.showGoalVolume;
            if (this.goalVol2) this.goalVol2.visible = this.enabled && this.showGoalVolume;

            if (!this.enabled) {
                if (this.visuals.size > 0) this.clear();
                return;
            }

            const game = window.flux.gameInstance;
            if (!game || !game.teams.home) return;

            const entities = [
                ...game.teams.home.players,
                ...game.teams.away.players,
                game.entities.ball
            ];

            entities.forEach(e => {
                if (!e || !e.mesh) return;
                
                let v = this.visuals.get(e);
                if (!v) {
                    v = this.createVisual(e);
                    this.visuals.set(e, v);
                }
                this.updateVisual(e, v);
            });
        }

        createVisual(entity) {
            const group = new THREE.Group();
            this.scene.add(group);

            // Hitboxes
            const tackle = new THREE.Mesh(this.geoCylinder, this.matTackle);
            const catchR = new THREE.Mesh(this.geoCylinder, this.matCatch);
            group.add(tackle);
            group.add(catchR);

            // Lines
            const velLine = this.createLine(this.matVel);
            const inputLine = this.createLine(this.matInput);
            const aiLine = this.createLine(this.matAI); // Line to perceived target
            
            group.add(velLine);
            group.add(inputLine);
            group.add(aiLine);

            return { group, tackle, catchR, velLine, inputLine, aiLine };
        }

        createLine(mat) {
            const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
            return new THREE.Line(geo, mat);
        }

        updateLine(line, start, end) {
            const pos = line.geometry.attributes.position.array;
            pos[0] = start.x; pos[1] = start.y; pos[2] = start.z;
            pos[3] = end.x; pos[4] = end.y; pos[5] = end.z;
            line.geometry.attributes.position.needsUpdate = true;
            line.visible = true;
        }

        updateVisual(e, v) {
            v.group.visible = true;
            
            // Hitboxes (Local to entity position)
            v.tackle.position.copy(e.mesh.position);
            v.catchR.position.copy(e.mesh.position);
            
            if (this.showHitboxes && e.role) {
                v.tackle.visible = true;
                const rT = e.tackleRadius || 2.5;
                v.tackle.scale.set(rT, 1, rT);

                v.catchR.visible = true;
                // Logic from main.js checkBallGrab
                const rC = e.isDashing ? 4.0 : 2.5; 
                v.catchR.scale.set(rC, 1, rC);
                v.catchR.position.y = e.mesh.position.y + 0.1;
            } else {
                v.tackle.visible = false;
                v.catchR.visible = false;
            }

            // Vectors (Global lines)
            const origin = e.mesh.position.clone();
            origin.y += 1.0; // Lift up

            if (this.showVectors) {
                // Velocity
                if (e.velocity) {
                    const end = origin.clone().add(e.velocity);
                    this.updateLine(v.velLine, origin, end);
                }
                // Input
                if (e.inputVector && e.inputVector.lengthSq() > 0) {
                    const end = origin.clone().add(e.inputVector.clone().multiplyScalar(3.0));
                    this.updateLine(v.inputLine, origin, end);
                } else {
                    v.inputLine.visible = false;
                }
            } else {
                v.velLine.visible = false;
                v.inputLine.visible = false;
            }

            // AI
            if (this.showAI && e.perceivedTargetPos) {
                // Draw line to perceived target
                this.updateLine(v.aiLine, origin, e.perceivedTargetPos);
            } else {
                v.aiLine.visible = false;
            }
        }

        clear() {
            this.visuals.forEach(v => {
                this.scene.remove(v.group);
            });
            this.visuals.clear();
        }
    }
    window.flux.DebugVisualizer = DebugVisualizer;
})();