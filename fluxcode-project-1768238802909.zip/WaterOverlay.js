(function() {
    window.flux = window.flux || {};

    // --- High-Quality Noise Texture Generator ---
    window.flux.noiseTexture = (() => {
        const size = 512;
        const c = document.createElement('canvas');
        c.width = size; c.height = size;
        const ctx = c.getContext('2d');
        
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, size, size);
        
        // Generate seamless noise (Perlin-ish via layered random circles/gradients)
        const drawNoiseLayer = (scale, alpha) => {
            ctx.globalAlpha = alpha;
            ctx.globalCompositeOperation = 'lighter'; // Additive
            const count = 300 * scale;
            for(let i=0; i<count; i++) {
                const x = Math.random() * size;
                const y = Math.random() * size;
                const r = (Math.random() * 30 + 10) / scale;
                
                const g = ctx.createRadialGradient(x, y, 0, x, y, r);
                g.addColorStop(0, '#888888');
                g.addColorStop(1, 'transparent');
                
                ctx.fillStyle = g;
                ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI*2); ctx.fill();
                
                // Wrap around for seamless tiling
                [[x-size, y], [x+size, y], [x, y-size], [x, y+size]].forEach(pos => {
                    const g2 = ctx.createRadialGradient(pos[0], pos[1], 0, pos[0], pos[1], r);
                    g2.addColorStop(0, '#888888');
                    g2.addColorStop(1, 'transparent');
                    ctx.fillStyle = g2;
                    ctx.beginPath(); ctx.arc(pos[0], pos[1], r, 0, Math.PI*2); ctx.fill();
                });
            }
        };
        
        drawNoiseLayer(1.0, 0.3);
        drawNoiseLayer(2.0, 0.2);
        drawNoiseLayer(4.0, 0.1);
        
        const tex = new THREE.CanvasTexture(c);
        tex.wrapS = THREE.RepeatWrapping;
        tex.wrapT = THREE.RepeatWrapping;
        return tex;
    })();

    class WaterOverlay {
        constructor(camera) {
            this.camera = camera;
            
            // Fullscreen quad
            const geometry = new THREE.PlaneGeometry(2, 2);
            
const vert = `
                varying vec2 vUv;
                void main() {
                    vUv = uv;
                    gl_Position = vec4(position, 1.0);
                }
            `;

const frag = `
                precision mediump float;
                uniform float uTime;
                uniform float uOpacity;
                uniform sampler2D tNoise;
                varying vec2 vUv;

                // FFX Palette (Additive Friendly)
                const vec3 C_DEEP = vec3(0.0, 0.02, 0.1);     // Subtle Deep Blue Edge
                const vec3 C_GLOW = vec3(0.0, 0.5, 0.8);      // Cyan Glow
                const vec3 C_RAY  = vec3(0.4, 0.7, 1.0);      // Light Shafts
                const vec3 C_PYRE = vec3(1.0, 0.9, 0.6);      // Pyrefly Gold

                // Bayer 4x4 Dithering
                float bayer4x4(vec2 uv) {
                    int x = int(mod(uv.x, 4.0));
                    int y = int(mod(uv.y, 4.0));
                    float v = 0.0;
                    if (y == 0) {
                        if (x == 0) v = 0.0; else if (x == 1) v = 8.0; else if (x == 2) v = 2.0; else v = 10.0;
                    } else if (y == 1) {
                        if (x == 0) v = 12.0; else if (x == 1) v = 4.0; else if (x == 2) v = 14.0; else v = 6.0;
                    } else if (y == 2) {
                        if (x == 0) v = 3.0; else if (x == 1) v = 11.0; else if (x == 2) v = 1.0; else v = 9.0;
                    } else {
                        if (x == 0) v = 15.0; else if (x == 1) v = 7.0; else if (x == 2) v = 13.0; else v = 5.0;
                    }
                    return v / 16.0;
                }

                void main() {
                    vec2 uv = vUv;
                    float t = uTime * 0.1;

                    // 1. Distortion (Lookup 1)
                    float warp = texture2D(tNoise, uv * 0.4 + vec2(t * 0.04, t * 0.02)).r;
                    
                    // 2. Caustics (Lookup 2)
                    vec2 cUV = uv * 2.0 + vec2(warp * 0.5, warp * 0.2) - vec2(t * 0.05);
                    float c = texture2D(tNoise, cUV).r;
                    
                    c = (c - 0.4) * 2.5;
                    c = max(0.0, c);
                    c = c * c;
                    c = c * c;
                    
                    float caustic = c * 12.0;
                    vec3 causticColor = vec3(caustic * 0.8, caustic, caustic * 1.2);

                    // 3. Rays (Lookup 3)
                    vec2 rayUV = vec2(uv.x + warp * 0.1, uv.y * 0.15 - t * 0.05);
                    float rays = texture2D(tNoise, rayUV).r;
                    rays = rays * rays;
                    
                    float rayMask = 1.0 - abs(uv.y * 2.0 - 1.0);
                    rays *= max(0.0, rayMask);

                    // 4. Pyreflies
                    vec2 p = uv * 5.0;
                    vec2 id = floor(p);
                    vec2 sub = fract(p) - 0.5;
                    
                    float n = fract(sin(dot(id, vec2(12.9898, 78.233))) * 43758.5453);
                    
                    float px = fract(n * 13.0 + t * 0.3) - 0.5;
                    float py = fract(n * 7.0 + t * 0.2) - 0.5;
                    
                    vec2 flyPos = vec2(px, py);
                    float d2 = dot(sub - flyPos, sub - flyPos);
                    
                    float fly = 0.0008 / (d2 + 0.0005);
                    fly *= step(0.7, n); 
                    fly *= 0.5 + 0.5 * sin(t * 5.0 + n * 10.0);

                    // Composition
                    vec3 finalCol = vec3(0.0);

                    // Vignette
                    vec2 vd = uv - 0.5;
                    float vSq = dot(vd, vd);
                    float vig = vSq * 1.2; 
                    finalCol += C_DEEP * vig;

                    finalCol += causticColor * C_GLOW * 0.6;
                    finalCol += rays * C_RAY * 0.3;
                    finalCol += fly * C_PYRE;

                    // PSX Dithering
                    float dither = bayer4x4(gl_FragCoord.xy);
                    // Modulate intensity with dither pattern for texture
                    finalCol += (dither - 0.5) * 0.08;

                    gl_FragColor = vec4(finalCol, uOpacity);
                }
            `;

this.material = new THREE.ShaderMaterial({
                uniforms: {
                    uTime: { value: 0 },
                    uOpacity: { value: 0.5 },
                    tNoise: { value: window.flux.noiseTexture }
                },
                vertexShader: vert,
                fragmentShader: frag,
                transparent: true,
                depthTest: false,
                depthWrite: false,
                blending: THREE.AdditiveBlending // Additive blending prevents dark occlusion
            });

            this.mesh = new THREE.Mesh(geometry, this.material);
            this.mesh.frustumCulled = false;
            this.mesh.renderOrder = 9999;
            
            // Add to camera so it stays on screen
            this.camera.add(this.mesh);
        }
        
        update(dt) {
            if (this.material) {
                this.material.uniforms.uTime.value += dt;
            }
        }
    }
    
    window.flux.WaterOverlay = WaterOverlay;
})();